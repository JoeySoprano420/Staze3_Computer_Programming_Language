# Production-readiness controls in Compiler 1.0.4

## Artifact integrity

Compiler-generated files are written completely to a sibling temporary file and
then atomically published. A write failure removes the temporary file. Native PE
linking targets a staging name; the compiler requires a minimum plausible size
and the `MZ` signature before replacing the requested output.

## Automation contracts

`version --json`, `doctor --json`, and `--diagnostic-format=json` emit one compact
JSON object per result using stable schema identifiers. Text remains the default
for people using the command prompt.

## Resource limits

- general driver input: 128 MiB;
- each source module: 16 MiB;
- module dependency graph: 1,024 modules;
- each SDEF module: 1 MiB;
- SDEF pack: 256 modules.

These are explicit rejection limits, not silent truncation points.

## Windows release gate

`build_windows_x64.bat` builds Release, requires `stazec.exe` to exist, runs the
complete CTest suite, checks the exact 1.0.4 JSON version, validates the shipped
definition pack, and only then copies the compiler into the project and release
locations.

## Remaining boundaries

Compiler 1.0.4 is suitable for serious evaluation and controlled experimental
use. It has not yet completed independent security audit, large-scale fuzzing,
multi-vendor bootstrap equivalence, broad platform support, self-hosting, or the
complete standard library required for unrestricted production deployment.
