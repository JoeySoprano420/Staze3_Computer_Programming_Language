# Compiler 1.0.4 release manifest

- Compiler: 1.0.4
- Language: Staze 3
- SABI: 1
- SDEF: 1.1
- SIR-S: 6.x
- SIR-C: 7.0
- Definition modules: 10
- Definition-pack SHA-256: `0a7f8ff1b81fba40796008f5e88e06fa76803543434f941a6d0c9f93c6a69df1`
- Source example validation: 42/42 PASS
- JSON CLI, diagnostic, lock, manifest, detached IR, and atomic-output gates: PASS

The package-level `SHA256SUMS.txt` covers every shipped file except itself.
