# Compiler 1.0.4 validation report

- Optimized C++23 build with `-Wall -Wextra -Wpedantic`: PASS
- Human and JSON version reports: PASS
- Doctor JSON schema/parse and fail-closed missing-tool result: PASS
- Ten-module SDEF pack validation: PASS
- Definition lock creation and verification: PASS
- All top-level `.stz3` examples with definitions: 42/42 PASS
- Versioned JSON compile diagnostic and exit status: PASS
- Source to detached SIR-S validation: PASS
- Source to detached SIR-C validation: PASS
- Definition-bound build manifest verification: PASS
- Atomic output leaves no temporary files after successful operations: PASS

The packaging host does not contain the Windows Clang/LLD toolchain, so native
PE generation was not rerun here. The retained Windows evidence and tests remain
in the repository, and the Windows batch release gate now refuses to stage a
compiler unless its complete native CTest suite passes locally.
