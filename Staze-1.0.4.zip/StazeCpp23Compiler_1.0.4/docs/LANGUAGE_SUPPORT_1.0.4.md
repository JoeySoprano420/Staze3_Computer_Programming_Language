# Staze 1.0.4 language and definition support

Compiler 1.0.4 ships a complete definition catalog for the supplied language
vision and an executable validator/loader for SDEF 1.1. "Catalog complete" means
the concept has facts, constraints, lowering identities, capabilities, and
diagnostics. It does not mean every entry has a native backend in this release.

| Family | Module | Executable compiler status |
|---|---|---|
| Creation, equality, set, revise, control | `staze.core` | Implemented |
| Types, inference, cardinality, aggregates, derivatives, units, ranges | `staze.types` | Partial |
| Nodes, links, children, branches, chains, webs, categories, cascades | `staze.relations` | Core operations implemented |
| Ownership, borrows, lifetimes, pools, labels, directives, provenance | `staze.memory` | Implemented foundation |
| Datasets, rulesets, dictionaries, persistent cross-references | `staze.data` | Partial |
| Typed faults, try, transactions, rollback, savepoints | `staze.faults` | Implemented foundation |
| Structured tasks, capture authority, joins, aggregation | `staze.concurrency` | Windows x64 implemented |
| Files, processes, ABI, modules, network, crypto, OS/embedded | `staze.systems` | Runtime foundation; network/crypto definition-only |
| Documents, sheets, GUI, games, simulation, GPU/SIMD, distributed | `staze.domains` | Definition-only |
| Seed, staged self-hosting, two-generation evolution | `staze.bootstrap` | Fingerprinting implemented; self-hosting not implemented |

The executable surface remains validated through canonical SIR-S 6.x, SIR-C
7.0, independent verification, LLVM emission, and the Windows x86-64 runtime.
