# Staze C++23 Compiler 1.0.4

## 1.0.4 production-readiness release

Version 1.0.4 adds atomic artifact publication, staged and signature-checked PE
output, machine-readable version/doctor/diagnostic contracts, explicit resource
limits, hardened PE flags, and a fail-closed Windows release gate.

```bat
stazec.exe doctor
stazec.exe doctor --json
stazec.exe version --json
stazec.exe check program.stz3 --diagnostic-format=json
```

See `docs/PRODUCTION_READINESS_1.0.4.md` for exact guarantees and remaining
boundaries.

## 1.0.4 definition support

This release adds strict SDEF 1.1 modules, deterministic definition packs,
dependency and trust-boundary validation, pack inspection, canonical SHA-256
identity, and manifest binding. See `docs/SDEF_1.md` and
`docs/LANGUAGE_SUPPORT_1.0.4.md` for the exact format and capability matrix.

```bat
stazec.exe definitions check definitions
stazec.exe definitions inspect definitions
stazec.exe check examples\hello.stz3 --definition-pack definitions
```

### 1.0.4 lock and security hardening

```bat
stazec.exe definitions lock definitions definitions.lock
stazec.exe definitions verify definitions definitions.lock
```

Lock verification binds every canonical module identity, version, and SHA-256.
The loader also rejects malformed UTF-8, forbidden control bytes, symlinks,
oversized modules, and oversized packs before semantic use.

**Milestone:** Stable ABI, Definition Format, Frozen SIR, and Reproducible Toolchain  
**Target:** Windows x86-64, COFF/PE32+  
**Host implementation:** C++23  
**Language mode:** STZ-3 / `staze 3`  
**Semantic IR:** canonical SIR-S 6.x  
**Concrete IR:** canonical SIR-C 7.0

Compiler 1.0.4 stabilizes the complete 0.9 execution surface as the first frozen
toolchain contract. SABI 1 fixes the Windows x86-64 calling/layout/ownership
boundary; SDEF 1 records definition and target identity; canonical SIR-S 6.x and
SIR-C 7.0 remain byte-stable verified interchange formats; and reproducible
build manifests fingerprint every semantic and concrete input. **SIR-S states
semantic meaning; SIR-C states a verified target realization; LLVM only
implements a freshly deserialized and independently verified SIR-C graph.**

Stable command forms are:

```bat
stazec.exe build program.stz3 -o program.exe
stazec.exe check program.stz3
stazec.exe inspect program.sirc
stazec.exe version
```

Legacy option-first invocations remain accepted for 0.9 source compatibility.

Compiler 1.0.4 hardens reproducibility by normalizing manifest input paths and
adding fail-closed verification:

```bat
stazec.exe check program.stz3 --emit-build-manifest program.manifest
stazec.exe check program.stz3 --verify-build-manifest program.manifest
```

## End-to-end architecture

```text
.stz3 roots + imported modules
        |
        v
Module/import loader + dependency graph
        |
        v
Lexer -> Parser -> merged AST
        |
        v
SSL facts -> DLE
        |
        v
canonical SIR-S 6.x
        |
   serialize/reload
        |
independent SIR-S verifier
        |
        v
Target concretizer
        |
        v
canonical SIR-C 7.0
        |
   serialize/reload
        |
independent SIR-C verifier
        |
        v
LLVM IR
        |
        v
Windows x86-64 COFF
        |
        v
lld-link -> standalone PE32+ .exe
```

The `.sirs` and `.sirc` files are real compiler boundaries. `--from-sir-s` performs target concretization without source/AST/SSL. `--from-sir-c` performs LLVM/COFF/PE generation without source, tokens, AST, SSL, DLE, or SIR-S.

## 0.9 milestone features

### Dynamic transactions

0.9 replaces the fixed one-slot-per-statement transaction mechanism with a **bounded execution-occurrence undo log**. Each executed reversible effect pushes its own undo record. This makes repeated mutations in loops representable and gives nested transactions real savepoints into the same log.

Implemented behavior includes:

- bounded dynamic undo records;
- loop/repeated-mutation rollback;
- nested transaction savepoints;
- inner abort to savepoint;
- inner commit composition into the parent transaction;
- root commit log discharge;
- reverse-order rollback;
- field-byte restoration;
- resource-created inverse actions;
- ownership restoration plans;
- shared-retain compensation;
- relation `link`/`unlink` inverse entries;
- explicit `TransactionCapacityExceeded` routing where repeated execution can exhaust the bounded log.

### Native relation storage

Relations now have real Windows-target storage rather than being abstract backend effects. SIR-C 7.0 contains a concrete relation plan with capacity, identity policy, cardinality policy, uniqueness, and synchronization metadata.

The reference provider uses module-scope fixed-capacity tables with:

- `used[]`, `source_id[]`, and `target_id[]` storage;
- atomic `cmpxchg` lock acquisition;
- key-field or address endpoint identity;
- unique-pair enforcement;
- source/target cardinality enforcement;
- capacity faults;
- `link`, `unlink`, `contains`, and `count`;
- transaction-aware inverse mutation.

### Real worker-backed structured concurrency

`parallel { task ... }` is no longer a deterministic in-thread simulation. SIR-C 7.0 defines concrete worker contexts and capture layouts. The Windows backend uses:

- `CreateThread`;
- per-task context storage;
- verified capture copy/share/send/unique-mut rules;
- task result slots;
- task status/cause slots;
- `WaitForSingleObject` joins;
- handle cleanup;
- named `join(task)` results;
- deterministic fault aggregation after all required joins;
- compile-time rejection of conflicting mutable task captures.

### Text, slices, maps, files, processes, and raw memory

The 0.9 systems profile includes executable native operations for:

- dynamic `text` values represented as `{ptr, u64 length}` descriptors;
- text concatenation and length;
- byte slicing and checked byte access;
- `slice<u8>` `{ptr, length}` views with provenance/lifetime semantics;
- bounded dynamically allocated scalar maps (`bool`, `i32`, `i64`, `u32`, `u64` keys/values);
- map insert/get/contains/remove/length;
- owned raw `bytes` allocation and size;
- Win32 file read/write through `CreateFileA`, `ReadFile`, `WriteFile`, `GetFileSizeEx`, and `CloseHandle`;
- process execution through `CreateProcessA`, `WaitForSingleObject`, `GetExitCodeProcess`, and `CloseHandle`;
- explicit allocation and I/O/process faults;
- lifetime/resource cleanup through the existing Staze provenance/ownership model.

No `std::string`, `std::vector`, `std::unordered_map`, C++ exceptions, GC, or C++ smart-pointer model becomes part of Staze semantics.

### Module system and multi-file compilation

`stazec` can compile one or more source roots and recursively resolve `use` dependencies:

```bat
stazec examples\modules\App.stz3 ^
  --module-path examples\modules ^
  --emit-deps modules.txt ^
  -o app.exe
```

The loader provides:

- recursive import discovery;
- module-name-to-file resolution;
- multiple module search paths;
- topological dependency loading;
- cyclic dependency rejection;
- missing import rejection;
- imported module identity validation;
- duplicate top-level declaration rejection;
- multi-root compilation;
- global expression-ID renumbering before SSL/DLE merge;
- dependency graph emission.

`Std.IO` remains a compiler/runtime builtin module in this reference profile.

The versioned `--emit-deps` output format is documented in
[`docs/EMIT_DEPS.md`](docs/EMIT_DEPS.md).

## Optional LLVM-emitter memory profile

The opt-in `memory_profile_emitter` measures LLVM text-emission time, emitted
byte count, and peak resident memory for a representative standalone SIR-C
input. It is excluded from ordinary builds and tests.

```bat
cmake -S . -B build-profile -A x64 -DSTAZE_ENABLE_MEMORY_PROFILE_TEST=ON
cmake --build build-profile --config Release --target memory_profile_emitter
build-profile\Release\memory_profile_emitter.exe path\to\large_fixture.sirc
```

On Windows it reports `PeakWorkingSetSize`; on POSIX it reports `/proc`'s
`VmHWM`. The input is independently deserialized and verified before timing
the SIR-C-to-LLVM emission stage.

## Runtime/startup model

Generated programs are standalone `/NODEFAULTLIB` console PE32+ images with a custom `staze_entry` startup function. The runtime glue is generated from the verified SIR-C program and uses explicit KERNEL32 imports. The backend compiles LLVM with `-mno-stack-arg-probe`; Compiler 1.0 ships **no fake `__chkstk` implementation**.

## Build the compiler on Windows x86-64

From a Visual Studio x64 developer command prompt with CMake, Clang, and `lld-link` available, run the batch file from any directory:

```bat
build_windows_x64.bat
```

or:

```bat
cmake -S . -B build -A x64
cmake --build build --config Release --target stazec
```

Then:

```bat
stazec.exe examples\systems_runtime.stz3 -o systems_runtime.exe
```

The batch file verifies the build and stages the compiler in three places:

```text
build\bin\stazec.exe
release\stazec.exe
stazec.exe
```

If configuration, compilation, or staging fails, the script exits with an error
instead of printing a success message.

## Useful CLI modes

```bat
:: Source/module graph -> native PE
stazec App.stz3 --module-path modules -o App.exe

:: Emit canonical semantic and concrete IR
stazec program.stz3 --check --emit-sir-s program.sirs --emit-sir-c program.sirc

:: Re-concretize with no source/frontend
stazec --from-sir-s program.sirs --emit-sir-c rebuilt.sirc --check

:: Backend-only native compilation
stazec --from-sir-c program.sirc -o program.exe --emit-llvm program.ll
```

## Final 1.0.4 conformance

The exact hardened source tree shipped in the release package was configured and built from a clean external Release directory with C++23 and `-Wall -Wextra -Wpedantic`.

```text
clean compiler build     PASS
C++ warnings             0
C++ errors               0
retained 0.9 CTest        249 / 249 PASS
1.0 host/CLI/manifest     PASS
legacy 0.2-0.8 tests      retained
0.9 dynamic tx tests      PASS
0.9 native relation tests PASS
0.9 worker tests          PASS
0.9 systems tests         PASS
0.9 module graph tests    PASS
source-vs-detached LLVM   PASS for canonical 0.9 evidence set
PE32+ generation          PASS
fake __chkstk check       PASS (not present)
```

Generated native evidence is in `dist/0.9/`. See `docs/TEST_REPORT_1.0.4.md`, `docs/SIR_C_7_FORMAT.md`, `docs/DYNAMIC_TX_RELATIONS_WORKERS.md`, and `docs/SYSTEMS_RUNTIME_MODULES.md`.

## Scope statement

Compiler 1.0.4 is the stable release of the complete executable 0.9 foundation,
with frozen SABI 1, SDEF 1, SIR, CLI, and reproducibility contracts. It does not
claim universal STZ-3 standard-library, self-hosting, or cross-target
conformance. Within its declared Windows x86-64 surface, the source, detached
SIR, verifier, native runtime glue, COFF/PE output, and negative-proof tests are
connected end-to-end.
