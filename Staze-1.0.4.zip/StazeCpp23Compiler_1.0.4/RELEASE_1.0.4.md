# Staze C++23 Compiler 1.0.4

Compiler 1.0.4 is a production-readiness hardening release. It preserves the
Staze 3 language contract, SABI 1, SDEF 1.1, SIR-S 6.x, and SIR-C 7.0.

## Production improvements

- atomic publication for generated text, SIR, manifest, dependency, and lock files;
- staged PE linking followed by size and `MZ` validation before atomic publication;
- previously valid executables remain untouched when compilation or linking fails;
- `/DYNAMICBASE`, `/NXCOMPAT`, and `/HIGHENTROPYVA` PE hardening flags;
- `stazec doctor` and `stazec doctor --json` toolchain readiness checks;
- `stazec version --json` for build systems and editor integration;
- `--diagnostic-format text|json` with versioned `staze-diagnostic-1` records;
- 128 MiB driver-input, 16 MiB source-module, and 1,024-module graph limits;
- explicit stream read/write failure detection;
- Windows release staging now requires the complete CTest suite, correct version,
  and a valid definition pack before publishing `stazec.exe`;
- corrected `compile_examples.bat` compiler location.

This release materially improves automation, failure containment, artifact
integrity, and deployment safety. It does not claim that the remaining
definition-only language domains have become native implementations.
