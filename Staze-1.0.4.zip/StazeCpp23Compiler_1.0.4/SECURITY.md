# Security policy

## Supported release

Compiler 1.0.4 is the supported evaluation release. Security fixes should be
developed against this version without silently changing SABI 1, SDEF 1.1,
SIR-S 6.x, or SIR-C 7.0 compatibility.

## Trust boundary

Treat `.stz3`, `.sirs`, `.sirc`, `.sdef`, lockfiles, and module graphs as
untrusted inputs. The compiler validates SIR independently after serialization,
limits source/definition/driver input sizes, rejects unsafe SDEF capabilities,
and publishes outputs through staged files. SDEF content is declarative and
does not receive permission to execute native callbacks.

The configured Clang and LLD executables are trusted build tools. Environment
variables `STAZE_CLANG` and `STAZE_LLD_LINK` must point to installations the
operator trusts. Generated programs can explicitly perform file, process, raw
memory, and worker operations; Staze source should therefore be reviewed before
compilation and execution.

## Reporting

Do not publish an exploitable sample before a fix is available. Record the
compiler version, command, target profile, minimized input, observed result,
expected result, and whether the problem occurs in source, SIR-S, SIR-C, LLVM,
linking, or generated execution.

This repository does not yet claim completion of an independent security audit
or unrestricted safety-critical certification.
