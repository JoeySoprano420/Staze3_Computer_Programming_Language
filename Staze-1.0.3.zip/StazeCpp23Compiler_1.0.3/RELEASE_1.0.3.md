# Staze C++23 Compiler 1.0.3

Compiler 1.0.3 is a security and reproducibility hardening release over 1.0.2.
It preserves the Staze 3 language contract, SABI 1, SDEF 1.1, SIR-S 6.x, and
SIR-C 7.0.

New in 1.0.3:

- deterministic `definitions lock` and `definitions verify` commands;
- exact lockfile failure when any module identity, version, or content changes;
- strict canonical UTF-8 validation, including rejection of overlong forms,
  surrogate code points, invalid continuation bytes, and truncated sequences;
- rejection of NUL and forbidden control bytes;
- rejection of symlinked and non-regular definition modules;
- 1 MiB per-module and 256-module per-pack resource limits;
- updated definition pack, release manifest, documentation, and checksums;
- all 42 shipped examples and all definition security fixtures validated.

This package does not relabel a legacy Windows executable. Visual Studio builds
the genuine 1.0.3 compiler with `call build_windows_x64.bat`.
