@echo off
setlocal EnableExtensions

rem Resolve the batch-file directory without a trailing slash.
rem %%~dp0 only expands inside a .bat file: run this file; do not paste it line by line.
for %%I in ("%~dp0.") do set "STAZE_ROOT=%%~fI"
set "STAZE_BUILD=%STAZE_ROOT%\build"
set "STAZE_BUILT_COMPILER=%STAZE_BUILD%\bin\stazec.exe"
set "STAZE_RELEASE=%STAZE_ROOT%\release"

where cmake >nul 2>nul
if errorlevel 1 (
    echo ERROR: CMake was not found on PATH.
    echo Install CMake with the Visual Studio C++ tools, then run this file again.
    exit /b 1
)

cmake -S "%STAZE_ROOT%" -B "%STAZE_BUILD%" -A x64
if errorlevel 1 exit /b 1
cmake --build "%STAZE_BUILD%" --config Release --target stazec --verbose
if errorlevel 1 exit /b 1

if not exist "%STAZE_BUILT_COMPILER%" (
    echo ERROR: The build reported success but did not create:
    echo   %STAZE_BUILT_COMPILER%
    exit /b 1
)

if not exist "%STAZE_RELEASE%" mkdir "%STAZE_RELEASE%"
copy /Y "%STAZE_BUILT_COMPILER%" "%STAZE_RELEASE%\stazec.exe" >nul
if errorlevel 1 exit /b 1
copy /Y "%STAZE_BUILT_COMPILER%" "%STAZE_ROOT%stazec.exe" >nul
if errorlevel 1 exit /b 1

echo.
echo Staze C++23 Compiler 1.0.3 built successfully.
echo Build output: %STAZE_BUILT_COMPILER%
echo Release copy: %STAZE_RELEASE%\stazec.exe
echo Project copy: %STAZE_ROOT%stazec.exe
endlocal
