# Compiler 1.0.3 validation report

- Optimized C++23 build with warnings enabled: PASS
- Version/SABI/SDEF/SIR identity: PASS
- Ten-module definition pack validation: PASS
- Definition lock creation and exact verification: PASS
- Tampered lock rejection: PASS
- Malformed control-byte definition rejection: PASS
- Symlinked definition rejection: PASS
- Missing dependency rejection: PASS
- Cyclic dependency rejection: PASS
- Unsafe executable-capability rejection: PASS
- All top-level `.stz3` examples with definition pack: 42/42 PASS
- Definition-bound reproducible build manifest: PASS

The packaging host had no Windows C++ cross-compiler. The package therefore
ships the validated Linux x64 compiler and the Visual Studio/CMake project that
builds the actual 1.0.3 `release\stazec.exe` on Windows.
