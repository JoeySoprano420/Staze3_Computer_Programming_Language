# Compiler 1.0.3 release manifest

- Compiler: 1.0.3
- Language: Staze 3
- SABI: 1
- SDEF: 1.1
- SIR-S: 6.x
- SIR-C: 7.0
- Definition modules: 10
- Definition-pack SHA-256: `01fa773750daa195fdadb77658401a0e487c09234556abd698fe0179f969c15e`
- Example validation: 42/42 PASS
- Lock, tamper, UTF-8/control, symlink, dependency, and capability gates: PASS

`SHA256SUMS.txt` fingerprints every included file except itself. The standalone
ZIP digest is distributed as `StazeCpp23Compiler_1.0.3.zip.sha256`.
