# Build Staze C++23 Compiler 1.0.3 on Windows x86-64

## Prerequisites

Install Visual Studio/Build Tools with C++ development tools, CMake, and LLVM/Clang so `clang.exe` and `lld-link.exe` are available in the x64 developer environment.

Compiler 1.0 does not require MASM. Staze source becomes verified SIR-S/SIR-C, LLVM IR, COFF, and finally PE32+.

## Build

```bat
cmake -S . -B build -A x64
cmake --build build --config Release
```

or run:

```bat
build_windows_x64.bat
```

The compiler is normally:

```text
build\Release\stazec.exe
```

## Compile a single program

```bat
build\Release\stazec.exe examples\systems_runtime.stz3 -o systems_runtime.exe
```

## Compile a module graph

```bat
build\Release\stazec.exe examples\modules\App.stz3 ^
  --module-path examples\modules ^
  --emit-deps modules.txt ^
  -o module_app.exe
```

## Detached backend

```bat
build\Release\stazec.exe examples\task_named_results.stz3 --check --emit-sir-c task.sirc
build\Release\stazec.exe --from-sir-c task.sirc -o task.exe
```

## Tests

```bat
ctest --test-dir build -C Release --output-on-failure
```
