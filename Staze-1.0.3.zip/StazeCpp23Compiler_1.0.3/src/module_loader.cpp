#include "staze/module_loader.hpp"
#include "staze/diagnostic.hpp"
#include "staze/lexer.hpp"
#include "staze/parser.hpp"
#include <algorithm>
#include <fstream>
#include <functional>
#include <map>
#include <set>
#include <sstream>

namespace staze {
namespace fs = std::filesystem;
namespace {
std::string read_all(const fs::path& p){std::ifstream f(p,std::ios::binary);if(!f)throw CompileError({},"module loader: cannot open "+p.string());std::ostringstream s;s<<f.rdbuf();return s.str();}
Program parse_file(const fs::path&p){const auto source=read_all(p);Lexer l(source);Parser parser(l.lex_all());return parser.parse_program();}
std::string import_module(const std::string&s){auto cut=s.find("::");auto as=s.find(" as ");std::size_t n=std::min(cut==std::string::npos?s.size():cut,as==std::string::npos?s.size():as);return s.substr(0,n);}
bool builtin_module(const std::string&name){return name=="Std.IO";}
fs::path module_relpath(const std::string&name){std::string r=name;std::replace(r.begin(),r.end(),'.',fs::path::preferred_separator);return fs::path(r+".stz3");}
void renumber_expr(Expr&e,std::size_t&next){e.id=next++;std::visit([&](auto&n){using T=std::decay_t<decltype(n)>;if constexpr(std::is_same_v<T,UnaryExpr>)renumber_expr(*n.operand,next);else if constexpr(std::is_same_v<T,BinaryExpr>){renumber_expr(*n.lhs,next);renumber_expr(*n.rhs,next);}else if constexpr(std::is_same_v<T,CallExpr>)for(auto&a:n.args)renumber_expr(a,next);},e.node);for(auto&h:e.handlers)if(h.replacement)renumber_expr(*h.replacement,next);}
void renumber_block(Block&b,std::size_t&next){for(auto&st:b)std::visit([&](auto&n){using T=std::decay_t<decltype(n)>;if constexpr(std::is_same_v<T,LocalDecl>)renumber_expr(n.value,next);else if constexpr(std::is_same_v<T,SetStmt>)renumber_expr(n.value,next);else if constexpr(std::is_same_v<T,ReviseStmt>)renumber_expr(n.delta,next);else if constexpr(std::is_same_v<T,IfStmt>){renumber_expr(n.condition,next);renumber_block(n.then_body,next);renumber_block(n.else_body,next);}else if constexpr(std::is_same_v<T,WhileStmt>){renumber_expr(n.condition,next);renumber_block(n.body,next);}else if constexpr(std::is_same_v<T,LoopStmt>||std::is_same_v<T,TransactionStmt>||std::is_same_v<T,ParallelStmt>||std::is_same_v<T,TaskStmt>)renumber_block(n.body,next);else if constexpr(std::is_same_v<T,ReturnStmt>){if(n.value)renumber_expr(*n.value,next);}else if constexpr(std::is_same_v<T,PerformStmt>||std::is_same_v<T,ExprStmt>)renumber_expr(n.value,next);else if constexpr(std::is_same_v<T,FaultStmt>)for(auto&e:n.payload)renumber_expr(e,next);},st.node);}
void renumber_program(Program&p,std::size_t&next){for(auto&d:p.datasets)for(auto&f:d.fields)if(f.default_value)renumber_expr(*f.default_value,next);for(auto&i:p.instructions)renumber_block(i.body,next);}

template<class T> void append_unique(std::vector<T>&out,std::vector<T>&src,const char*kind){std::set<std::string>names;for(const auto&x:out)names.insert(x.name);for(auto&x:src){if(!names.insert(x.name).second)throw CompileError(x.where,std::string("module graph: duplicate ")+kind+" '"+x.name+"'");out.push_back(std::move(x));}}
}

LoadedCompilation ModuleLoader::load(const std::vector<fs::path>&roots,const std::vector<fs::path>&search_paths)const{
    if(roots.empty())throw CompileError({},"module loader: at least one root source is required");
    std::vector<fs::path> paths=search_paths;
    for(const auto&r:roots)paths.push_back(fs::absolute(r).parent_path());
    std::sort(paths.begin(),paths.end());paths.erase(std::unique(paths.begin(),paths.end()),paths.end());

    auto locate=[&](const std::string&name)->fs::path{
        for(const auto&base:paths){
            auto p=base/module_relpath(name);if(fs::exists(p))return fs::canonical(p);
            const auto dot=name.rfind('.');auto leaf=base/(name.substr(dot==std::string::npos?0:dot+1)+".stz3");if(fs::exists(leaf))return fs::canonical(leaf);
        }
        throw CompileError({},"module loader: cannot resolve module '"+name+"'");
    };

    std::map<std::string,Program> modules;std::map<std::string,fs::path> module_paths;
    std::set<std::string> active,done;std::vector<std::string> order;
    std::function<void(const std::string&,const fs::path&)> walk;
    walk=[&](const std::string&expected,const fs::path&path){
        if(done.contains(expected))return;
        if(!active.insert(expected).second)throw CompileError({},"module loader: cyclic dependency involving '"+expected+"'");
        Program q=parse_file(path);
        if(q.module_name!=expected)throw CompileError({},"module loader: expected module '"+expected+"' but file declares '"+q.module_name+"'");
        auto old=module_paths.find(expected);if(old!=module_paths.end()&&old->second!=fs::canonical(path))throw CompileError({},"module loader: module '"+expected+"' resolves to multiple files");
        module_paths[expected]=fs::canonical(path);auto imports=q.imports;modules[expected]=std::move(q);
        for(const auto&spec:imports){const auto dep=import_module(spec);if(builtin_module(dep))continue;walk(dep,locate(dep));}
        active.erase(expected);done.insert(expected);order.push_back(expected);
    };

    std::vector<std::string> root_names;
    for(const auto&r:roots){auto abs=fs::canonical(r);auto p=parse_file(abs);root_names.push_back(p.module_name);walk(p.module_name,abs);}
    if(order.empty())throw CompileError({},"module loader: no modules loaded");

    Program merged;merged.staze_version=3;merged.module_name=root_names.front();
    std::size_t next_expr=1;
    for(const auto&name:order){
        auto&mp=modules.at(name);renumber_program(mp,next_expr);
        append_unique(merged.faults,mp.faults,"fault");append_unique(merged.datasets,mp.datasets,"dataset");append_unique(merged.choices,mp.choices,"choice");append_unique(merged.relations,mp.relations,"relation");append_unique(merged.pools,mp.pools,"pool");append_unique(merged.instructions,mp.instructions,"instruction");
    }
    LoadedCompilation out;out.program=std::move(merged);
    for(const auto&name:order){ModuleGraphNode n;n.name=name;n.path=module_paths.at(name);n.imports=modules.at(name).imports;out.graph.push_back(std::move(n));}
    return out;
}

std::string ModuleLoader::graph_text(const std::vector<ModuleGraphNode>&g){std::ostringstream o;o<<"STAZE-MODULE-GRAPH 1\n";for(const auto&n:g){o<<"module "<<n.name<<" "<<n.path.generic_string()<<"\n";for(const auto&i:n.imports)o<<"  use "<<i<<"\n";}return o.str();}

} // namespace staze
