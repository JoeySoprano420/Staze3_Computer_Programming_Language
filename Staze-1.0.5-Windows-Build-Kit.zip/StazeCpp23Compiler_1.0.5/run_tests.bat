@echo off
setlocal EnableExtensions
set "STAZE_ROOT=%~dp0"
ctest --test-dir "%STAZE_ROOT%build" -C Release --output-on-failure
exit /b %errorlevel%
