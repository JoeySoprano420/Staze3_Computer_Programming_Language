#include "staze/llvm_x64.hpp"
#include "staze/diagnostic.hpp"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <limits>
#include <map>
#include <set>
#include <tuple>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

namespace staze {
namespace {

std::string safe_name(std::string s) {
    for (char& c : s) if (!std::isalnum(static_cast<unsigned char>(c)) && c != '_') c = '_';
    return s;
}

std::string llvm_ty(SirType t) {
    switch (t) {
        case SirType::Bool: return "i1";
        case SirType::I32:
        case SirType::U32: return "i32";
        case SirType::I64:
        case SirType::U64: return "i64";
        case SirType::Unit: return "i8";
        case SirType::Text:
        case SirType::Nominal: return "ptr";
    }
    return "i8";
}

std::string escape_bytes(const std::string& s) {
    std::ostringstream o;
    const char* hex = "0123456789ABCDEF";
    for (unsigned char c : s) {
        if (c >= 32 && c <= 126 && c != '"' && c != '\\') o << static_cast<char>(c);
        else o << '\\' << hex[c >> 4] << hex[c & 15];
    }
    return o.str();
}

struct Def {
    SirType type{SirType::Unit};
    SirCardinality cardinality{SirCardinality::One};
    std::string nominal;
    const SirInstruction* op{nullptr};
    bool parameter{false};
    std::size_t parameter_index{0};
};

const SirConcreteFunction& concrete_function(const SirCProgram& p, const std::string& name) {
    auto it = std::find_if(p.concrete_functions.begin(), p.concrete_functions.end(), [&](const auto& x){ return x.name == name; });
    if (it == p.concrete_functions.end()) throw CompileError({}, "LLVM backend: missing concrete function plan for '" + name + "'");
    return *it;
}

const SirConcreteLayout& concrete_layout(const SirCProgram& p, const std::string& name) {
    auto it = std::find_if(p.concrete_layouts.begin(), p.concrete_layouts.end(), [&](const auto& x){ return x.name == name; });
    if (it == p.concrete_layouts.end()) throw CompileError({}, "LLVM backend: missing concrete layout for '" + name + "'");
    return *it;
}

const SirPoolSchema* pool_schema(const SirCProgram& p, const std::string& name) {
    auto it=std::find_if(p.pools.begin(),p.pools.end(),[&](const auto&x){return x.name==name;});return it==p.pools.end()?nullptr:&*it;
}
const SirFaultIdentity* fault_schema(const SirCProgram& p, const std::string& name) {
    auto it=std::find_if(p.faults.begin(),p.faults.end(),[&](const auto&x){return x.name==name;});return it==p.faults.end()?nullptr:&*it;
}
const SirDatasetSchema* dataset_schema(const SirCProgram& p, const std::string& name) {
    auto it=std::find_if(p.datasets.begin(),p.datasets.end(),[&](const auto&x){return x.name==name;});return it==p.datasets.end()?nullptr:&*it;
}
const SirConcreteRelation& concrete_relation(const SirCProgram& p, const std::string& name) {
    auto it=std::find_if(p.concrete_relations.begin(),p.concrete_relations.end(),[&](const auto&x){return x.name==name;});
    if(it==p.concrete_relations.end())throw CompileError({},"LLVM backend: missing concrete relation plan for '"+name+"'");
    return *it;
}

std::uint32_t align_up(std::uint32_t v, std::uint32_t a) {
    if (a <= 1) return v;
    return (v + a - 1u) & ~(a - 1u);
}

bool region_inside(const SirFunction& fn, SirRegionId child, SirRegionId ancestor) {
    if (!ancestor) return true;
    std::set<SirRegionId> seen;
    while (child && seen.insert(child).second) {
        if (child == ancestor) return true;
        auto it = std::find_if(fn.regions.begin(), fn.regions.end(), [&](const auto& r){ return r.id == child; });
        if (it == fn.regions.end()) break;
        child = it->parent;
    }
    return false;
}

struct TaskSynthetic {
    SirFunction fn;
    SirConcreteFunction concrete;
};

TaskSynthetic make_task_synthetic(const SirFunction& parent, const SirConcreteFunction& parent_cf, const SirConcreteTask& task) {
    auto contract = std::find_if(parent.task_contracts.begin(), parent.task_contracts.end(), [&](const auto& t){ return t.task_region == task.task_region; });
    if (contract == parent.task_contracts.end()) throw CompileError({}, "LLVM backend: task plan lacks semantic task contract");

    const SirBlock* begin_block = nullptr;
    const SirBlock* done_block = nullptr;
    for (const auto& b : parent.blocks) {
        for (const auto& op : b.instructions) {
            if (op.id == task.begin_op) begin_block = &b;
            if (op.id == task.end_op) done_block = &b;
        }
    }
    if (!begin_block || !done_block || begin_block->terminator.kind != SirTerminatorKind::Br)
        throw CompileError({}, "LLVM backend: malformed structured task CFG");

    TaskSynthetic out;
    out.fn.name = "__task_" + safe_name(parent.name) + "_" + std::to_string(task.id);
    out.fn.result_type = task.result_type;
    out.fn.result_cardinality = task.result_cardinality;
    out.fn.result_nominal_type = task.result_nominal_type;
    out.fn.result_ownership = "value";
    out.fn.declared_faults = contract->faults;
    out.fn.effects = parent.effects;
    out.fn.entry = begin_block->terminator.target;
    out.fn.root_region = task.task_region;
    out.fn.effect_root = parent.effect_root;
    out.fn.regions = parent.regions;
    out.fn.provenances = parent.provenances;
    out.fn.borrow_edges = parent.borrow_edges;
    out.fn.ownership_edges = parent.ownership_edges;
    out.fn.values = parent.values;

    std::vector<const SirConcreteTaskCapture*> caps;
    for (const auto& c : parent_cf.task_captures) if (c.task_region == task.task_region) caps.push_back(&c);
    std::sort(caps.begin(), caps.end(), [](auto* a, auto* b){ return a->byte_offset < b->byte_offset; });
    for (const auto* c : caps) {
        auto vs = std::find_if(parent.values.begin(), parent.values.end(), [&](const auto& v){ return v.value == c->value; });
        if (vs == parent.values.end()) throw CompileError({}, "LLVM backend: task capture lacks value semantics");
        SirParameter p;
        p.name = "capture_" + std::to_string(c->id);
        p.authority = c->mode == "unique-mut" ? "borrow_mut" : (c->mode == "shared-read" ? "shared" : (c->mode == "send" ? "send" : "value"));
        p.ownership = vs->ownership;
        p.type = vs->type; p.cardinality = vs->cardinality; p.nominal_type = vs->nominal_type; p.value = vs->value;
        out.fn.parameters.push_back(std::move(p));
    }

    std::set<SirBlockId> task_blocks;
    std::set<SirOpId> task_ops;
    for (const auto& b : parent.blocks) if (region_inside(parent, b.region, task.task_region)) {
        task_blocks.insert(b.id);
        for (const auto& op : b.instructions) task_ops.insert(op.id);
    }

    for (const auto& b0 : parent.blocks) {
        if (!task_blocks.contains(b0.id) || b0.id == done_block->id) continue;
        SirBlock b = b0;
        std::vector<SirInstruction> kept;
        bool terminalized = false;
        for (const auto& op : b0.instructions) {
            if (op.opcode == SirOpcode::TaskReturn) {
                SirTerminator t; t.kind = SirTerminatorKind::Return; t.where = op.where; t.effect_token = op.effect_out;
                if (!op.operands.empty()) t.value = op.operands.front();
                b.terminator = std::move(t); terminalized = true; break;
            }
            if (op.opcode == SirOpcode::TaskFail) {
                SirTerminator t; t.kind = SirTerminatorKind::FaultReturn; t.where = op.where; t.effect_token = op.effect_out; t.fault = op.semantic_name; t.fault_payload = op.operands;
                b.terminator = std::move(t); terminalized = true; break;
            }
            if (op.opcode == SirOpcode::TaskEnd) {
                SirTerminator t; t.kind = SirTerminatorKind::Return; t.where = op.where; t.effect_token = op.effect_out;
                b.terminator = std::move(t); terminalized = true; break;
            }
            kept.push_back(op);
        }
        b.instructions = std::move(kept);
        if (!terminalized) {
            auto outside = [&](SirBlockId id){ return id && !task_blocks.contains(id); };
            if ((b.terminator.kind == SirTerminatorKind::Br && outside(b.terminator.target)) ||
                (b.terminator.kind == SirTerminatorKind::CondBr && (outside(b.terminator.true_target) || outside(b.terminator.false_target)))) {
                if (task.result_type != SirType::Unit) throw CompileError({}, "LLVM backend: non-unit task has path escaping without task.return");
                SirTerminator t; t.kind = SirTerminatorKind::Return; t.where = b.terminator.where; t.effect_token = b.terminator.effect_token; b.terminator = std::move(t);
            }
        }
        out.fn.blocks.push_back(std::move(b));
    }

    if (std::none_of(out.fn.blocks.begin(), out.fn.blocks.end(), [&](const auto& b){ return b.id == out.fn.entry; }))
        throw CompileError({}, "LLVM backend: task entry block disappeared during worker extraction");

    out.concrete = parent_cf;
    out.concrete.name = out.fn.name;
    out.concrete.result_transfer = SirResultTransferKind::None;
    out.concrete.result_storage = SirStorageClass::Register;
    out.concrete.result_kind = SirConcreteKind::Scalar;
    switch (task.result_type) {
        case SirType::Bool: out.concrete.result_size = 1; out.concrete.result_align = 1; break;
        case SirType::I32: case SirType::U32: out.concrete.result_size = 4; out.concrete.result_align = 4; break;
        case SirType::I64: case SirType::U64: out.concrete.result_size = 8; out.concrete.result_align = 8; break;
        case SirType::Unit: out.concrete.result_size = 1; out.concrete.result_align = 1; break;
        default: throw CompileError({}, "LLVM backend: worker task result is not supported by the scalar 0.9 worker ABI");
    }
    auto block_in_task = [&](SirBlockId id){ return task_blocks.contains(id); };
    out.concrete.cleanup_actions.erase(std::remove_if(out.concrete.cleanup_actions.begin(), out.concrete.cleanup_actions.end(), [&](const auto& a){ return !block_in_task(a.from_block); }), out.concrete.cleanup_actions.end());
    out.concrete.rollback_actions.erase(std::remove_if(out.concrete.rollback_actions.begin(), out.concrete.rollback_actions.end(), [&](const auto& a){ return !task_ops.contains(a.source_op); }), out.concrete.rollback_actions.end());
    out.concrete.undo_actions.erase(std::remove_if(out.concrete.undo_actions.begin(), out.concrete.undo_actions.end(), [&](const auto& a){ return !task_ops.contains(a.source_op); }), out.concrete.undo_actions.end());
    out.concrete.transactions.erase(std::remove_if(out.concrete.transactions.begin(), out.concrete.transactions.end(), [&](const auto& t){ return !region_inside(parent, t.region, task.task_region); }), out.concrete.transactions.end());
    out.concrete.tasks.clear();
    out.concrete.task_captures.clear();
    return out;
}

class FunctionEmitter {
public:
    FunctionEmitter(const SirCProgram& program,
                    const SirFunction& fn,
                    const std::map<std::string, std::size_t>& strings,
                    const SirConcreteFunction* concrete_override = nullptr)
        : program_(program), fn_(fn), concrete_(concrete_override ? *concrete_override : concrete_function(program, fn.name)), strings_(strings) {
        for (std::size_t i = 0; i < fn.parameters.size(); ++i)
            defs_[fn.parameters[i].value] = Def{fn.parameters[i].type, fn.parameters[i].cardinality, fn.parameters[i].nominal_type, nullptr, true, i};
        for (const auto& b : fn.blocks)
            for (const auto& op : b.instructions)
                defs_[op.result] = Def{op.type, op.cardinality, op.nominal_type, &op, false, 0};
        for (const auto& cv : concrete_.values) concrete_values_[cv.value] = &cv;
        for (const auto& vs : fn_.values) value_semantics_[vs.value] = &vs;
        for (const auto& pr : fn_.provenances) provenances_[pr.id] = &pr;
        for (const auto& r : concrete_.resources) {
            resources_[r.id] = &r;
            resource_by_value_[r.value] = &r;
            resource_by_provenance_[r.provenance] = &r;
        }
        for (const auto& u : concrete_.undo_actions) {
            undo_by_source_[u.source_op].push_back(&u);
            undo_by_transaction_[u.transaction_region].push_back(&u);
            if (u.kind == SirUndoKind::DestroyResource || u.kind == SirUndoKind::SharedRelease)
                undo_tracked_values_.insert(u.target_value);
        }
    }

    std::string emit() {
        out_ << "define " << function_return_type() << " @stz_" << safe_name(fn_.name) << "(";
        bool first = true;
        if (rich_result()) { out_ << "ptr %result_out"; first = false; }
        if (!first) out_ << ", ";
        out_ << "ptr %fault_out"; first = false;
        for (std::size_t i = 0; i < fn_.parameters.size(); ++i) {
            out_ << ", " << (is_rich(fn_.parameters[i].value) ? "ptr" : "i64") << " %arg" << i;
        }
        out_ << ") {\nprologue:\n";

        // Concrete worker contexts are fixed by SIR-C 7.0 and live for the
        // enclosing function/parallel lifetime.  Handles are separate so a null
        // handle cleanly denotes synchronous fallback execution.
        for(const auto& t:concrete_.tasks){
            out_<<"  "<<task_ctx(t)<<" = alloca ["<<t.context_size<<" x i8], align "<<t.context_align<<"\n";
            out_<<"  call void @llvm.memset.p0.i64(ptr "<<task_ctx(t)<<", i8 0, i64 "<<t.context_size<<", i1 false)\n";
            out_<<"  "<<task_handle(t)<<" = alloca ptr, align 8\n  store ptr null, ptr "<<task_handle(t)<<", align 8\n";
        }

        // Fixed-size stack/caller temporaries are hoisted to the prologue.  This
        // keeps the Windows x64 frame static and avoids backend-invented dynamic
        // alloca/probe behavior for ordinary rich SSA values.
        for (const auto& p : concrete_.values) {
            if (p.scalar_replaced) continue;
            if (p.storage == SirStorageClass::Stack || p.storage == SirStorageClass::PoolArena) {
                out_ << "  " << value_name(p.value) << " = alloca [" << p.size << " x i8], align " << p.align << "\n";
                preallocated_[p.value] = true;
            }
        }

        // Resource ownership slots are the runtime realization of SIR-C cleanup obligations.
        // Null means this static allocation site currently owns no heap buffer.
        for (const auto& r : concrete_.resources) {
            const bool tracked_for_undo = undo_tracked_values_.contains(r.value);
            if (!r.automatic && !tracked_for_undo) continue;
            if (r.cleanup == SirCleanupKind::HeapFree || r.cleanup == SirCleanupKind::ManyBufferFree || r.cleanup == SirCleanupKind::TextBufferFree || r.cleanup == SirCleanupKind::MapBufferFree || r.cleanup == SirCleanupKind::BytesBufferFree || r.cleanup == SirCleanupKind::SharedRelease) {
                out_ << "  " << resource_slot(r.id) << " = alloca ptr, align 8\n";
                out_ << "  store ptr null, ptr " << resource_slot(r.id) << ", align 8\n";
            }
        }

        // SIR-C 7 uses an occurrence log for repeatable field/relation mutation.
        // Other ownership/resource inverse actions retain exact static slots.
        if(dynamic_transactions()){
            const auto cap=tx_log_capacity(),payload=tx_payload_bytes();
            out_<<"  %tx.log.count = alloca i32, align 4\n  store i32 0, ptr %tx.log.count, align 4\n";
            out_<<"  %tx.log.kind = alloca ["<<cap<<" x i32], align 4\n";
            out_<<"  %tx.log.rid = alloca ["<<cap<<" x i32], align 4\n";
            out_<<"  %tx.log.target = alloca ["<<cap<<" x ptr], align 8\n";
            out_<<"  %tx.log.aux0 = alloca ["<<cap<<" x i64], align 8\n";
            out_<<"  %tx.log.aux1 = alloca ["<<cap<<" x i64], align 8\n";
            out_<<"  %tx.log.payload = alloca ["<<(static_cast<std::uint64_t>(cap)*payload)<<" x i8], align 8\n";
            for(const auto&t:concrete_.transactions)out_<<"  "<<tx_savepoint(t.region)<<" = alloca i32, align 4\n  store i32 0, ptr "<<tx_savepoint(t.region)<<", align 4\n";
        }
        for (const auto& u : concrete_.undo_actions) {
            if(dynamic_transactions()&&(u.kind==SirUndoKind::RestoreField||u.kind==SirUndoKind::RelationLink||u.kind==SirUndoKind::RelationUnlink))continue;
            out_ << "  " << undo_active(u.id) << " = alloca i1, align 1\n";
            out_ << "  store i1 false, ptr " << undo_active(u.id) << ", align 1\n";
            if (u.kind == SirUndoKind::RestoreField) out_ << "  " << undo_bytes(u.id) << " = alloca [" << u.size << " x i8], align " << u.align << "\n";
        }

        for (std::size_t i = 0; i < fn_.parameters.size(); ++i) {
            const auto& p = fn_.parameters[i];
            const auto name = value_name(p.value);
            if (is_rich(p.value)) {
                out_ << "  " << name << " = getelementptr i8, ptr %arg" << i << ", i64 0\n";
                continue;
            }
            switch (p.type) {
                case SirType::I64:
                case SirType::U64: out_ << "  " << name << " = add i64 %arg" << i << ", 0\n"; break;
                case SirType::I32:
                case SirType::U32: out_ << "  " << name << " = trunc i64 %arg" << i << " to i32\n"; break;
                case SirType::Bool: out_ << "  " << name << " = trunc i64 %arg" << i << " to i1\n"; break;
                case SirType::Unit: out_ << "  " << name << " = add i8 0, 0\n"; break;
                case SirType::Text:
                case SirType::Nominal: throw CompileError({}, "LLVM backend: concrete plan marked rich parameter as register");
            }
        }
        out_ << "  br label %" << block_name(fn_.entry) << "\n";
        for (const auto& b : fn_.blocks) emit_block(b);
        emit_cleanup_edge_blocks();
        out_ << "}\n\n";
        return out_.str();
    }

private:
    std::string block_name(SirBlockId id) const { return "b" + std::to_string(id); }
    std::string value_name(SirValueId id) const { return "%v" + std::to_string(id); }
    std::string temp(SirOpId id, const std::string& suffix) const { return "%o" + std::to_string(id) + "." + suffix; }
    std::string local_label(SirBlockId bid, SirOpId op, const std::string& suffix) const { return "b" + std::to_string(bid) + ".o" + std::to_string(op) + "." + suffix; }

    bool rich_result() const { return concrete_.result_storage == SirStorageClass::Caller; }
    bool transferred_result() const { return concrete_.result_transfer != SirResultTransferKind::None; }
    std::string function_return_type() const { return rich_result() ? "i32" : "{ i32, i64 }"; }

    const SirConcreteValue& cv(SirValueId id) const {
        auto it = concrete_values_.find(id);
        if (it == concrete_values_.end()) throw CompileError({}, "LLVM backend: missing concrete value plan for %" + std::to_string(id));
        return *it->second;
    }
    bool is_rich(SirValueId id) const { return cv(id).storage != SirStorageClass::Register; }
    SirType value_type(SirValueId id) const {
        auto it=defs_.find(id);if(it==defs_.end())throw CompileError({},"LLVM backend: undefined SIR SSA value");return it->second.type;
    }

    int fault_code(const std::string& name) const {
        for (const auto& f : program_.faults) if (f.name == name) return f.code;
        throw CompileError({}, "LLVM backend: missing fault code for '" + name + "'");
    }
    SirBlockId fault_target(const SirInstruction& op, const std::string& name) const {
        for (const auto& e : op.fault_edges) if (e.fault == name) return e.target;
        throw CompileError({}, "LLVM backend: SIR operation lacks explicit fault edge for '" + name + "'");
    }

    std::string scalar(SirValueId id) const {
        auto it = defs_.find(id);
        if (it == defs_.end()) throw CompileError({}, "LLVM backend: undefined SIR SSA value");
        if (is_rich(id)) throw CompileError({}, "LLVM backend: rich SSA value requested as scalar");
        const auto& d = it->second;
        if (d.parameter) return value_name(id);
        const auto& op = *d.op;
        switch (op.opcode) {
            case SirOpcode::ConstUnit: return "0";
            case SirOpcode::ConstInt: return std::to_string(op.int_value);
            case SirOpcode::ConstBool: return op.bool_value ? "1" : "0";
            case SirOpcode::RevisionMarker:
            case SirOpcode::MoveValue:
            case SirOpcode::SendValue:
            case SirOpcode::Borrow:
            case SirOpcode::BorrowMut: return scalar(op.operands.at(0));
            case SirOpcode::ConstText: throw CompileError({}, "LLVM backend: text value requested as scalar");
            default: return value_name(id);
        }
    }

    std::string static_name(SirValueId id) const { return "@.stz.static." + safe_name(fn_.name) + ".v" + std::to_string(id); }
    std::string resource_slot(std::uint32_t id) const { return "%resource." + std::to_string(id) + ".slot"; }
    std::string undo_active(std::uint32_t id) const { return "%undo." + std::to_string(id) + ".active"; }
    std::string undo_bytes(std::uint32_t id) const { return "%undo." + std::to_string(id) + ".bytes"; }
    std::string undo_label(SirOpId abort_op,std::uint32_t id,const std::string& suffix) const { return "undo.o"+std::to_string(abort_op)+".u"+std::to_string(id)+"."+suffix; }
    bool dynamic_transactions() const { return program_.format_major>=7 && !concrete_.transactions.empty(); }
    std::uint32_t tx_log_capacity() const { std::uint32_t c=0;for(const auto&t:concrete_.transactions)c=std::max(c,t.log_capacity);return c; }
    std::uint32_t tx_payload_bytes() const { std::uint32_t c=32;for(const auto&t:concrete_.transactions)c=std::max(c,t.payload_bytes);return c; }
    std::string tx_savepoint(SirRegionId r) const { return "%tx.save."+std::to_string(r); }
    std::string cleanup_label(SirBlockId from, SirBlockId to, SirOpId source) const {
        return "cleanup.b" + std::to_string(from) + ".to" + std::to_string(to) + ".op" + std::to_string(source);
    }
    std::string rich_ptr(SirValueId id) const {
        const auto& p=cv(id);
        if(p.scalar_replaced) return "null";
        if(p.storage==SirStorageClass::Static) return static_name(id);
        return value_name(id);
    }

    std::pair<std::size_t, std::size_t> text_constant(SirValueId id) const {
        auto it = defs_.find(id);
        if (it == defs_.end() || !it->second.op) throw CompileError({}, "LLVM backend: write_text operand is not a constant text SIR value");
        const auto* op = it->second.op;
        if (op->opcode == SirOpcode::RevisionMarker) return text_constant(op->operands.at(0));
        if (op->opcode != SirOpcode::ConstText) throw CompileError({}, "LLVM backend: write_text requires a constant text value in Compiler 0.9");
        auto si = strings_.find(op->text_value);
        if (si == strings_.end()) throw CompileError({}, "LLVM backend: text constant was not interned");
        return {si->second, op->text_value.size()};
    }

    std::string box(SirValueId id) {
        const auto t = value_type(id);
        const auto v = scalar(id);
        if (t == SirType::I64 || t == SirType::U64) return v;
        if (t == SirType::Unit) return "0";
        const auto r = "%box" + std::to_string(box_counter_++);
        if (t == SirType::I32) out_ << "  " << r << " = sext i32 " << v << " to i64\n";
        else if (t == SirType::U32 || t == SirType::Bool) out_ << "  " << r << " = zext " << llvm_ty(t) << " " << v << " to i64\n";
        else throw CompileError({}, "LLVM backend: scalar ABI cannot box rich/text values");
        return r;
    }

    void unbox_to(SirValueId result, SirType t, const std::string& payload) {
        if (t == SirType::Unit) return;
        if (t == SirType::I64 || t == SirType::U64) out_ << "  " << value_name(result) << " = add i64 " << payload << ", 0\n";
        else if (t == SirType::I32 || t == SirType::U32) out_ << "  " << value_name(result) << " = trunc i64 " << payload << " to i32\n";
        else if (t == SirType::Bool) out_ << "  " << value_name(result) << " = trunc i64 " << payload << " to i1\n";
        else throw CompileError({}, "LLVM backend: scalar ABI cannot unbox rich/text values");
    }

    void emit_alloca(SirValueId id) {
        const auto& p=cv(id); if(p.scalar_replaced) return;
        if (preallocated_.contains(id)) return;
        out_ << "  " << value_name(id) << " = alloca [" << p.size << " x i8], align " << p.align << "\n";
        preallocated_[id] = true;
    }
    std::string byte_ptr(const std::string& base, std::uint32_t offset, const std::string& name) {
        if(offset==0) return base;
        out_ << "  " << name << " = getelementptr i8, ptr " << base << ", i64 " << offset << "\n";
        return name;
    }
    void emit_memcpy(const std::string& dst, const std::string& src, std::uint32_t bytes) {
        if(bytes==0 || dst=="null" || src=="null") return;
        out_ << "  call void @llvm.memcpy.p0.p0.i64(ptr " << dst << ", ptr " << src << ", i64 " << bytes << ", i1 false)\n";
    }
    void store_value(const std::string& base, std::uint32_t offset, SirValueId value, std::uint32_t bytes, std::uint32_t align, const std::string& stem) {
        auto ptr=byte_ptr(base,offset,stem+".ptr");
        if(is_rich(value)) { emit_memcpy(ptr,rich_ptr(value),std::min(bytes,cv(value).size)); return; }
        const auto t=value_type(value);
        out_ << "  store " << llvm_ty(t) << ' ' << scalar(value) << ", ptr " << ptr << ", align " << std::max<std::uint32_t>(1,std::min<std::uint32_t>(align,8)) << "\n";
    }

    const SirConcreteResource* resource_for_value(SirValueId id) const {
        auto si=value_semantics_.find(id); if(si==value_semantics_.end()) return nullptr;
        auto prov=si->second->provenance;
        std::set<SirProvenanceId> seen;
        while(prov && seen.insert(prov).second){
            auto ri=resource_by_provenance_.find(prov); if(ri!=resource_by_provenance_.end()) return ri->second;
            auto pi=provenances_.find(prov); if(pi==provenances_.end()) break; prov=pi->second->parent;
        }
        return nullptr;
    }
    std::vector<const SirCleanupAction*> cleanup_actions(SirBlockId from, SirBlockId to, SirOpId source, bool fault_exit=false) const {
        std::vector<const SirCleanupAction*> out;
        for(const auto& a:concrete_.cleanup_actions) if(a.from_block==from&&a.to_block==to&&a.source_op==source&&a.fault_exit==fault_exit) out.push_back(&a);
        return out;
    }
    std::string edge_label(SirBlockId from, SirBlockId to, SirOpId source=0) const {
        return cleanup_actions(from,to,source).empty()?block_name(to):cleanup_label(from,to,source);
    }
    std::string fault_edge_label(const SirBlock& b,const SirInstruction& op,const std::string& fault) const {
        return edge_label(b.id,fault_target(op,fault),op.id);
    }
    void emit_cleanup_action(const SirCleanupAction& a) {
        auto ri=resources_.find(a.resource_id);if(ri==resources_.end())throw CompileError({},"LLVM backend: cleanup action names unknown resource");
        const auto& r=*ri->second;
        if(r.cleanup==SirCleanupKind::HeapFree||r.cleanup==SirCleanupKind::ManyBufferFree||r.cleanup==SirCleanupKind::TextBufferFree||r.cleanup==SirCleanupKind::MapBufferFree||r.cleanup==SirCleanupKind::BytesBufferFree){
            out_<<"  %cleanup.r"<<r.id<<".p."<<cleanup_counter_<<" = load ptr, ptr "<<resource_slot(r.id)<<", align 8\n";
            if(!a.transfer) out_<<"  call void @staze_heap_free_if_nonnull(ptr %cleanup.r"<<r.id<<".p."<<cleanup_counter_<<")\n";
            out_<<"  store ptr null, ptr "<<resource_slot(r.id)<<", align 8\n";
            ++cleanup_counter_;
        }else if(r.cleanup==SirCleanupKind::SharedRelease){
            out_<<"  %cleanup.r"<<r.id<<".p."<<cleanup_counter_<<" = load ptr, ptr "<<resource_slot(r.id)<<", align 8\n";
            if(!a.transfer) out_<<"  call void @staze_shared_release_if_nonnull(ptr %cleanup.r"<<r.id<<".p."<<cleanup_counter_<<")\n";
            out_<<"  store ptr null, ptr "<<resource_slot(r.id)<<", align 8\n";
            ++cleanup_counter_;
        }else if(r.cleanup==SirCleanupKind::LifetimeEnd){
            if(a.transfer)throw CompileError({},"LLVM backend: stack/arena lifetime cannot be transferred across instruction boundary");
            const auto p=rich_ptr(r.value);
            if(p!="null") out_<<"  call void @llvm.lifetime.end.p0(i64 "<<r.size<<", ptr "<<p<<")\n";
        }
    }
    void emit_cleanup_list(const std::vector<const SirCleanupAction*>& actions){for(const auto* a:actions)emit_cleanup_action(*a);}
    void emit_cleanup_edge_blocks(){
        std::set<std::tuple<SirBlockId,SirBlockId,SirOpId>> done;
        for(const auto& a:concrete_.cleanup_actions){
            auto fbi=std::find_if(fn_.blocks.begin(),fn_.blocks.end(),[&](const auto&b){return b.id==a.from_block;});
            if(fbi!=fn_.blocks.end()&&block_in_task_region(*fbi))continue;
            if(a.to_block==0xffffffffu)continue;
            auto key=std::make_tuple(a.from_block,a.to_block,a.source_op);if(!done.insert(key).second)continue;
            out_<<cleanup_label(a.from_block,a.to_block,a.source_op)<<":\n";
            emit_cleanup_list(cleanup_actions(a.from_block,a.to_block,a.source_op));
            out_<<"  br label %"<<block_name(a.to_block)<<"\n";
        }
    }

    std::string normal_exit_label(const SirBlock& b) const {
        for (auto it = b.instructions.rbegin(); it != b.instructions.rend(); ++it)
            if (!it->fault_edges.empty()) return local_label(b.id, it->id, "after");
        return block_name(b.id);
    }

    std::string phi_pred_label(SirBlockId pred,SirBlockId target) const {
        if(!cleanup_actions(pred,target,0).empty()) return cleanup_label(pred,target,0);
        return normal_exit_label(fn_.blocks.at(pred));
    }
    void emit_phi(const SirBlock& current,const SirInstruction& op) {
        if(is_rich(op.result)) {
            out_ << "  " << value_name(op.result) << " = phi ptr ";
            for(std::size_t i=0;i<op.phi_inputs.size();++i){if(i)out_<<", ";const auto&in=op.phi_inputs[i];out_<<"[ "<<rich_ptr(in.value)<<", %"<<phi_pred_label(in.predecessor,current.id)<<" ]";}out_<<"\n";
            return;
        }
        out_ << "  " << value_name(op.result) << " = phi " << llvm_ty(op.type) << ' ';
        for (std::size_t i = 0; i < op.phi_inputs.size(); ++i) {
            if (i) out_ << ", ";
            const auto& in = op.phi_inputs[i];
            out_ << "[ " << scalar(in.value) << ", %" << phi_pred_label(in.predecessor,current.id) << " ]";
        }
        out_ << "\n";
    }

    void emit_faulting_overflow(const SirBlock& b, const SirInstruction& op, const char* stem) {
        const auto ty = llvm_ty(op.type); const auto sign = sir_is_signed_integer(op.type) ? "s" : "u";
        const auto intr = std::string("@llvm.") + sign + stem + ".with.overflow.i" + std::to_string(sir_integer_bits(op.type));
        out_ << "  " << temp(op.id,"pair") << " = call { " << ty << ", i1 } " << intr << "(" << ty << ' ' << scalar(op.operands[0]);
        if(op.opcode==SirOpcode::CheckedNeg) out_ << ")\n"; else out_ << ", " << ty << ' ' << scalar(op.operands[1]) << ")\n";
        out_ << "  " << value_name(op.result) << " = extractvalue { " << ty << ", i1 } " << temp(op.id,"pair") << ", 0\n";
        out_ << "  " << temp(op.id,"overflow") << " = extractvalue { " << ty << ", i1 } " << temp(op.id,"pair") << ", 1\n";
        out_ << "  br i1 " << temp(op.id,"overflow") << ", label %" << fault_edge_label(b,op,"ArithmeticOverflow") << ", label %" << local_label(b.id,op.id,"after") << "\n";
        out_ << local_label(b.id,op.id,"after") << ":\n";
    }

    void emit_checked_neg(const SirBlock& b, const SirInstruction& op) {
        const auto ty=llvm_ty(op.type); const auto intr=std::string("@llvm.ssub.with.overflow.i")+std::to_string(sir_integer_bits(op.type));
        out_<<"  "<<temp(op.id,"pair")<<" = call { "<<ty<<", i1 } "<<intr<<"("<<ty<<" 0, "<<ty<<' '<<scalar(op.operands[0])<<")\n";
        out_<<"  "<<value_name(op.result)<<" = extractvalue { "<<ty<<", i1 } "<<temp(op.id,"pair")<<", 0\n";
        out_<<"  "<<temp(op.id,"overflow")<<" = extractvalue { "<<ty<<", i1 } "<<temp(op.id,"pair")<<", 1\n";
        out_<<"  br i1 "<<temp(op.id,"overflow")<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<local_label(b.id,op.id,"after")<<"\n";
        out_<<local_label(b.id,op.id,"after")<<":\n";
    }

    void emit_divmod(const SirBlock& b, const SirInstruction& op, bool mod) {
        const auto ty=llvm_ty(op.type);const auto zero=temp(op.id,"zero"),nonzero=local_label(b.id,op.id,"nonzero"),after=local_label(b.id,op.id,"after");
        out_<<"  "<<zero<<" = icmp eq "<<ty<<' '<<scalar(op.operands[1])<<", 0\n";
        out_<<"  br i1 "<<zero<<", label %"<<fault_edge_label(b,op,"DivideByZero")<<", label %"<<nonzero<<"\n";
        out_<<nonzero<<":\n";
        if(sir_is_signed_integer(op.type)){
            const std::string minv=sir_integer_bits(op.type)==32?std::to_string(std::numeric_limits<std::int32_t>::min()):std::to_string(std::numeric_limits<std::int64_t>::min());
            out_<<"  "<<temp(op.id,"ismin")<<" = icmp eq "<<ty<<' '<<scalar(op.operands[0])<<", "<<minv<<"\n";
            out_<<"  "<<temp(op.id,"isneg1")<<" = icmp eq "<<ty<<' '<<scalar(op.operands[1])<<", -1\n";
            out_<<"  "<<temp(op.id,"bad")<<" = and i1 "<<temp(op.id,"ismin")<<", "<<temp(op.id,"isneg1")<<"\n";
            out_<<"  br i1 "<<temp(op.id,"bad")<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<after<<"\n";
        }else out_<<"  br label %"<<after<<"\n";
        out_<<after<<":\n";const char*inst=sir_is_signed_integer(op.type)?(mod?"srem":"sdiv"):(mod?"urem":"udiv");
        out_<<"  "<<value_name(op.result)<<" = "<<inst<<' '<<ty<<' '<<scalar(op.operands[0])<<", "<<scalar(op.operands[1])<<"\n";
    }

    void emit_optional(const SirInstruction& op, bool some) {
        emit_alloca(op.result); const auto& p=cv(op.result); if(p.scalar_replaced)return;
        out_<<"  store i8 "<<(some?1:0)<<", ptr "<<rich_ptr(op.result)<<", align 1\n";
        if(some) store_value(rich_ptr(op.result),p.payload_offset,op.operands.at(0),p.element_size,cv(op.operands.at(0)).align,temp(op.id,"optional.payload"));
    }

    void emit_many(const SirInstruction& op) {
        emit_alloca(op.result); const auto&p=cv(op.result); if(p.scalar_replaced)return;
        out_<<"  store i64 "<<op.operands.size()<<", ptr "<<rich_ptr(op.result)<<", align 8\n";
        for(std::size_t i=0;i<op.operands.size();++i) store_value(rich_ptr(op.result),p.payload_offset+static_cast<std::uint32_t>(i)*p.element_size,op.operands[i],p.element_size,cv(op.operands[i]).align,temp(op.id,"many."+std::to_string(i)));
    }

    void emit_record_fields(const SirInstruction& op, const std::vector<std::uint32_t>& offsets) {
        const auto&p=cv(op.result); if(p.scalar_replaced)return; emit_alloca(op.result);
        if(offsets.size()!=op.operands.size())throw CompileError({},"LLVM backend: concrete field-offset arity mismatch");
        for(std::size_t i=0;i<op.operands.size();++i)store_value(rich_ptr(op.result),offsets[i],op.operands[i],cv(op.operands[i]).size,cv(op.operands[i]).align,temp(op.id,"field."+std::to_string(i)));
    }

    void emit_aggregate(const SirInstruction& op) {
        const auto&l=concrete_layout(program_,op.semantic_name);emit_record_fields(op,l.field_offsets);
    }

    void emit_choice(const SirInstruction& op) {
        const auto&p=cv(op.result);if(p.scalar_replaced)return;emit_alloca(op.result);
        out_<<"  store i32 "<<op.tag<<", ptr "<<rich_ptr(op.result)<<", align 4\n";
        std::uint32_t off=p.payload_offset;
        for(std::size_t i=0;i<op.operands.size();++i){const auto&ov=cv(op.operands[i]);off=align_up(off,ov.align);store_value(rich_ptr(op.result),off,op.operands[i],ov.size,ov.align,temp(op.id,"choice."+std::to_string(i)));off+=ov.size;}
    }

    void mark_resource_pointer(SirValueId value,const std::string& ptr) {
        const auto* r=resource_for_value(value);if(!r||(!r->automatic&&!undo_tracked_values_.contains(r->value)))return;
        if(r->cleanup==SirCleanupKind::HeapFree||r->cleanup==SirCleanupKind::ManyBufferFree||r->cleanup==SirCleanupKind::SharedRelease)
            out_<<"  store ptr "<<ptr<<", ptr "<<resource_slot(r->id)<<", align 8\n";
    }
    std::vector<const SirConcreteUndo*> undo_for_source(SirOpId op) const {
        auto it=undo_by_source_.find(op);if(it==undo_by_source_.end())return {};return it->second;
    }
    void activate_simple_undo(SirOpId source) {
        for(const auto* u:undo_for_source(source)) if(u->kind!=SirUndoKind::RestoreField){
            if(dynamic_transactions()&&(u->kind==SirUndoKind::RelationLink||u->kind==SirUndoKind::RelationUnlink))continue;
            out_<<"  store i1 true, ptr "<<undo_active(u->id)<<", align 1\n";
        }
    }
    bool has_tx_capacity_edge(const SirInstruction& op) const {return std::any_of(op.fault_edges.begin(),op.fault_edges.end(),[](const auto&e){return e.fault=="TransactionCapacityExceeded";});}
    void emit_tx_push(const SirBlock& b,const SirInstruction& op,int kind,int rid,const std::string& target,const std::string& aux0,const std::string& aux1,const std::string& payload,const std::string& payload_len,const std::string& condition,const std::string& suffix){
        const auto effective=temp(op.id,"tx.kind."+suffix);out_<<"  "<<effective<<" = select i1 "<<condition<<", i32 "<<kind<<", i32 0\n";
        const auto ok=temp(op.id,"tx.ok."+suffix);out_<<"  "<<ok<<" = call i1 @staze_tx_push(ptr %tx.log.count, ptr %tx.log.kind, ptr %tx.log.rid, ptr %tx.log.target, ptr %tx.log.aux0, ptr %tx.log.aux1, ptr %tx.log.payload, i32 "<<tx_log_capacity()<<", i32 "<<tx_payload_bytes()<<", i32 "<<effective<<", i32 "<<rid<<", ptr "<<target<<", i64 "<<aux0<<", i64 "<<aux1<<", ptr "<<payload<<", i32 "<<payload_len<<")\n";
        const auto cont=local_label(b.id,op.id,"tx."+suffix);
        if(has_tx_capacity_edge(op))out_<<"  br i1 "<<ok<<", label %"<<cont<<", label %"<<fault_edge_label(b,op,"TransactionCapacityExceeded")<<"\n";
        else {const auto impossible=local_label(b.id,op.id,"txfull."+suffix);out_<<"  br i1 "<<ok<<", label %"<<cont<<", label %"<<impossible<<"\n"<<impossible<<":\n  unreachable\n";}
        out_<<cont<<":\n";
    }
    void snapshot_field_undo(const SirBlock& b,const SirInstruction& op,const std::string& root,std::uint32_t off) {
        for(const auto* u:undo_for_source(op.id)) if(u->kind==SirUndoKind::RestoreField){
            const auto src=byte_ptr(root,off,"%undo."+std::to_string(u->id)+".src");
            if(dynamic_transactions())emit_tx_push(b,op,1,0,src,std::to_string(u->size),"0",src,std::to_string(u->size),"true","field");
            else {emit_memcpy(undo_bytes(u->id),src,u->size);out_<<"  store i1 true, ptr "<<undo_active(u->id)<<", align 1\n";}
        }
    }
    const SirConcreteTransaction* tx_plan(SirRegionId region) const {auto it=std::find_if(concrete_.transactions.begin(),concrete_.transactions.end(),[&](const auto&t){return t.region==region;});return it==concrete_.transactions.end()?nullptr:&*it;}
    void begin_transaction(SirRegionId region){if(dynamic_transactions()){out_<<"  %tx.begin."<<region<<".count = load i32, ptr %tx.log.count, align 4\n  store i32 %tx.begin."<<region<<".count, ptr "<<tx_savepoint(region)<<", align 4\n";}}
    void clear_transaction_undo(SirRegionId region) {
        if(dynamic_transactions()){const auto*t=tx_plan(region);if(t&&!t->parent_transaction){out_<<"  %tx.commit."<<region<<".save = load i32, ptr "<<tx_savepoint(region)<<", align 4\n  store i32 %tx.commit."<<region<<".save, ptr %tx.log.count, align 4\n";}}
        auto it=undo_by_transaction_.find(region);if(it==undo_by_transaction_.end())return;
        for(const auto* u:it->second){if(dynamic_transactions()&&(u->kind==SirUndoKind::RestoreField||u->kind==SirUndoKind::RelationLink||u->kind==SirUndoKind::RelationUnlink))continue;out_<<"  store i1 false, ptr "<<undo_active(u->id)<<", align 1\n";}
    }
    void emit_undo_action(const SirConcreteUndo& u,SirOpId abort_op) {
        const auto active="%undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".isactive";
        const auto doit=undo_label(abort_op,u.id,"do"),done=undo_label(abort_op,u.id,"done");
        out_<<"  "<<active<<" = load i1, ptr "<<undo_active(u.id)<<", align 1\n";
        out_<<"  br i1 "<<active<<", label %"<<doit<<", label %"<<done<<"\n"<<doit<<":\n";
        if(u.kind==SirUndoKind::RestoreField){
            auto dst=byte_ptr(rich_ptr(u.target_value),u.byte_offset,"%undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".dst");
            emit_memcpy(dst,undo_bytes(u.id),u.size);
        }else if(u.kind==SirUndoKind::DestroyResource||u.kind==SirUndoKind::SharedRelease){
            const auto* r=resource_for_value(u.target_value);if(!r)throw CompileError({},"LLVM backend: transaction undo resource lacks concrete resource obligation");
            const auto pv="%undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".p";
            out_<<"  "<<pv<<" = load ptr, ptr "<<resource_slot(r->id)<<", align 8\n";
            if(r->cleanup==SirCleanupKind::SharedRelease||u.kind==SirUndoKind::SharedRelease)out_<<"  call void @staze_shared_release_if_nonnull(ptr "<<pv<<")\n";
            else out_<<"  call void @staze_heap_free_if_nonnull(ptr "<<pv<<")\n";
            out_<<"  store ptr null, ptr "<<resource_slot(r->id)<<", align 8\n";
        }else if(u.kind==SirUndoKind::RestoreOwner){
            auto oi=defs_.find(u.aux_value);
            if(u.aux_value&&oi!=defs_.end()&&oi->second.op&&oi->second.op->opcode==SirOpcode::FieldMove){
                const auto fp=byte_ptr(rich_ptr(u.target_value),u.byte_offset,"%undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".field");
                out_<<"  store ptr "<<rich_ptr(u.aux_value)<<", ptr "<<fp<<", align 8\n";
            }
            // Whole-value move/send are representation aliases in the reference
            // backend, so restoring semantic ownership requires no byte mutation.
        }else if(u.kind==SirUndoKind::RelationLink||u.kind==SirUndoKind::RelationUnlink){
            const auto& rp=concrete_relation(program_,u.semantic_name);
            const auto sid=relation_identity(u.target_value,rp.source_identity,"undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".src");
            const auto tid=relation_identity(u.aux_value,rp.target_identity,"undo.o"+std::to_string(abort_op)+".u"+std::to_string(u.id)+".tgt");
            const auto args="ptr "+rel_global(rp.name,"lock")+", ptr "+rel_global(rp.name,"count")+", ptr "+rel_global(rp.name,"used")+", ptr "+rel_global(rp.name,"src")+", ptr "+rel_global(rp.name,"tgt")+", i64 "+std::to_string(rp.capacity)+", i64 "+sid+", i64 "+tid;
            if(u.kind==SirUndoKind::RelationUnlink)
                out_<<"  %undo.o"<<abort_op<<".u"<<u.id<<".removed = call i1 @staze_relation_unlink("<<args<<")\n";
            else
                out_<<"  %undo.o"<<abort_op<<".u"<<u.id<<".relinked = call i32 @staze_relation_link("<<args<<", i1 "<<(rp.source_many?"true":"false")<<", i1 "<<(rp.target_many?"true":"false")<<", i1 "<<(rp.unique_pair?"true":"false")<<")\n";
        }
        out_<<"  store i1 false, ptr "<<undo_active(u.id)<<", align 1\n";
        out_<<"  br label %"<<done<<"\n"<<done<<":\n";
    }
    void emit_dynamic_transaction_abort(const SirInstruction& op){
        if (!dynamic_transactions()) return;
        const auto save = "%tx.abort." + std::to_string(op.id) + ".save";
        out_ << "  " << save << " = load i32, ptr " << tx_savepoint(op.region) << ", align 4\n";
        const auto loop="tx.abort."+std::to_string(op.id)+".loop",body="tx.abort."+std::to_string(op.id)+".body",done="tx.abort."+std::to_string(op.id)+".done";out_<<"  br label %"<<loop<<"\n"<<loop<<":\n";
        out_<<"  %tx.abort."<<op.id<<".count = load i32, ptr %tx.log.count, align 4\n  %tx.abort."<<op.id<<".more = icmp ugt i32 %tx.abort."<<op.id<<".count, "<<save<<"\n  br i1 %tx.abort."<<op.id<<".more, label %"<<body<<", label %"<<done<<"\n"<<body<<":\n";
        out_<<"  %tx.abort."<<op.id<<".idx = sub i32 %tx.abort."<<op.id<<".count, 1\n  %tx.abort."<<op.id<<".idx64 = zext i32 %tx.abort."<<op.id<<".idx to i64\n";
        out_<<"  %tx.abort."<<op.id<<".kp = getelementptr i32, ptr %tx.log.kind, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".kind = load i32, ptr %tx.abort."<<op.id<<".kp, align 4\n";
        out_<<"  switch i32 %tx.abort."<<op.id<<".kind, label %tx.abort."<<op.id<<".next [ i32 1, label %tx.abort."<<op.id<<".field i32 2, label %tx.abort."<<op.id<<".relunlink i32 3, label %tx.abort."<<op.id<<".rellink ]\n";
        out_<<"tx.abort."<<op.id<<".field:\n  %tx.abort."<<op.id<<".tp = getelementptr ptr, ptr %tx.log.target, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".target = load ptr, ptr %tx.abort."<<op.id<<".tp, align 8\n  %tx.abort."<<op.id<<".a0p = getelementptr i64, ptr %tx.log.aux0, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".size = load i64, ptr %tx.abort."<<op.id<<".a0p, align 8\n  %tx.abort."<<op.id<<".poff = mul i64 %tx.abort."<<op.id<<".idx64, "<<tx_payload_bytes()<<"\n  %tx.abort."<<op.id<<".payload = getelementptr i8, ptr %tx.log.payload, i64 %tx.abort."<<op.id<<".poff\n  call void @llvm.memcpy.p0.p0.i64(ptr %tx.abort."<<op.id<<".target, ptr %tx.abort."<<op.id<<".payload, i64 %tx.abort."<<op.id<<".size, i1 false)\n  br label %tx.abort."<<op.id<<".next\n";
        auto relcase=[&](int kind,const char* label){out_<<"tx.abort."<<op.id<<"."<<label<<":\n  %tx.abort."<<op.id<<".ridp."<<label<<" = getelementptr i32, ptr %tx.log.rid, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".rid."<<label<<" = load i32, ptr %tx.abort."<<op.id<<".ridp."<<label<<", align 4\n  %tx.abort."<<op.id<<".a0p."<<label<<" = getelementptr i64, ptr %tx.log.aux0, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".src."<<label<<" = load i64, ptr %tx.abort."<<op.id<<".a0p."<<label<<", align 8\n  %tx.abort."<<op.id<<".a1p."<<label<<" = getelementptr i64, ptr %tx.log.aux1, i64 %tx.abort."<<op.id<<".idx64\n  %tx.abort."<<op.id<<".tgt."<<label<<" = load i64, ptr %tx.abort."<<op.id<<".a1p."<<label<<", align 8\n  call void @staze_relation_undo(i32 %tx.abort."<<op.id<<".rid."<<label<<", i32 "<<kind<<", i64 %tx.abort."<<op.id<<".src."<<label<<", i64 %tx.abort."<<op.id<<".tgt."<<label<<")\n  br label %tx.abort."<<op.id<<".next\n";};relcase(2,"relunlink");relcase(3,"rellink");
        out_<<"tx.abort."<<op.id<<".next:\n  store i32 %tx.abort."<<op.id<<".idx, ptr %tx.log.count, align 4\n  br label %"<<loop<<"\n"<<done<<":\n";
    }
    void emit_transaction_abort(const SirInstruction& op) {
        emit_dynamic_transaction_abort(op);
        auto it=undo_by_transaction_.find(op.region);if(it==undo_by_transaction_.end())return;
        auto actions=it->second;std::sort(actions.begin(),actions.end(),[](const auto*a,const auto*b){return std::tie(a->source_op,a->id)>std::tie(b->source_op,b->id);});
        for(const auto* u:actions){if(dynamic_transactions()&&(u->kind==SirUndoKind::RestoreField||u->kind==SirUndoKind::RelationLink||u->kind==SirUndoKind::RelationUnlink))continue;emit_undo_action(*u,op.id);}
    }

    void activate_simple_undo_if(SirOpId source,const std::string& condition) {
        for(const auto* u:undo_for_source(source)) if(u->kind!=SirUndoKind::RestoreField){
            if(dynamic_transactions()&&(u->kind==SirUndoKind::RelationLink||u->kind==SirUndoKind::RelationUnlink))continue;
            out_<<"  store i1 "<<condition<<", ptr "<<undo_active(u->id)<<", align 1\n";
        }
    }

    std::string relation_identity(SirValueId value,const std::string& policy,const std::string& stem) {
        if(policy=="address"){
            const auto r="%"+stem+".addr";
            out_<<"  "<<r<<" = ptrtoint ptr "<<rich_ptr(value)<<" to i64\n";
            return r;
        }
        constexpr const char* prefix="key:";
        if(policy.rfind(prefix,0)!=0)throw CompileError({},"LLVM backend: unsupported relation identity policy '"+policy+"'");
        auto di=defs_.find(value);if(di==defs_.end()||di->second.nominal.empty())throw CompileError({},"LLVM backend: keyed relation endpoint lacks nominal type");
        const auto* ds=dataset_schema(program_,di->second.nominal);if(!ds)throw CompileError({},"LLVM backend: keyed relation endpoint is not a dataset");
        const auto key=policy.substr(4);
        auto fi=std::find_if(ds->fields.begin(),ds->fields.end(),[&](const auto&f){return f.name==key;});
        if(fi==ds->fields.end())throw CompileError({},"LLVM backend: relation key field is missing");
        const auto ordinal=static_cast<std::size_t>(std::distance(ds->fields.begin(),fi));
        const auto& layout=concrete_layout(program_,di->second.nominal);
        if(ordinal>=layout.field_offsets.size())throw CompileError({},"LLVM backend: relation key field lacks concrete offset");
        const auto ptr=byte_ptr(rich_ptr(value),layout.field_offsets[ordinal],"%"+stem+".key.ptr");
        const auto raw="%"+stem+".key";
        out_<<"  "<<raw<<" = load "<<llvm_ty(fi->type)<<", ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,std::min<std::uint32_t>(8,layout.align))<<"\n";
        if(fi->type==SirType::I64||fi->type==SirType::U64)return raw;
        const auto ext="%"+stem+".id";
        if(fi->type==SirType::I32)out_<<"  "<<ext<<" = sext i32 "<<raw<<" to i64\n";
        else if(fi->type==SirType::U32)out_<<"  "<<ext<<" = zext i32 "<<raw<<" to i64\n";
        else if(fi->type==SirType::Bool)out_<<"  "<<ext<<" = zext i1 "<<raw<<" to i64\n";
        else throw CompileError({},"LLVM backend: native relation key must be scalar integer/bool");
        return ext;
    }

    std::string rel_global(const std::string& rel,const char* part) const { return "@.stz.rel."+safe_name(rel)+"."+part; }

    void emit_relation_op(const SirBlock& b,const SirInstruction& op) {
        const auto& rp=concrete_relation(program_,op.semantic_name);
        const auto cap=std::to_string(rp.capacity);
        if(op.opcode==SirOpcode::RelationCount){
            out_<<"  "<<value_name(op.result)<<" = call i64 @staze_relation_count(ptr "<<rel_global(rp.name,"lock")<<", ptr "<<rel_global(rp.name,"count")<<")\n";
            return;
        }
        const auto sid=relation_identity(op.operands.at(0),rp.source_identity,"o"+std::to_string(op.id)+".src");
        const auto tid=relation_identity(op.operands.at(1),rp.target_identity,"o"+std::to_string(op.id)+".tgt");
        const auto args="ptr "+rel_global(rp.name,"lock")+", ptr "+rel_global(rp.name,"count")+", ptr "+rel_global(rp.name,"used")+", ptr "+rel_global(rp.name,"src")+", ptr "+rel_global(rp.name,"tgt")+", i64 "+cap+", i64 "+sid+", i64 "+tid;
        if(op.opcode==SirOpcode::RelationContains){
            out_<<"  "<<value_name(op.result)<<" = call i1 @staze_relation_contains("<<args<<")\n";
            return;
        }
        auto dynamic_log=[&](const std::string& changed,int inverse_kind,bool inverse_is_unlink){
            bool needs=false;for(const auto*u:undo_for_source(op.id))if(u->kind==SirUndoKind::RelationLink||u->kind==SirUndoKind::RelationUnlink)needs=true;
            if(!dynamic_transactions()||!needs)return;
            const auto effective=temp(op.id,"tx.rel.kind");
            const auto ok=temp(op.id,"tx.rel.ok");
            const auto success=local_label(b.id,op.id,"tx.rel.logged");
            const auto repair=local_label(b.id,op.id,"tx.rel.repair");
            out_<<"  "<<effective<<" = select i1 "<<changed<<", i32 "<<inverse_kind<<", i32 0\n";
            out_<<"  "<<ok<<" = call i1 @staze_tx_push(ptr %tx.log.count, ptr %tx.log.kind, ptr %tx.log.rid, ptr %tx.log.target, ptr %tx.log.aux0, ptr %tx.log.aux1, ptr %tx.log.payload, i32 "<<tx_log_capacity()<<", i32 "<<tx_payload_bytes()<<", i32 "<<effective<<", i32 "<<rp.id<<", ptr null, i64 "<<sid<<", i64 "<<tid<<", ptr null, i32 0)\n";
            out_<<"  br i1 "<<ok<<", label %"<<success<<", label %"<<repair<<"\n"<<repair<<":\n";
            // The relation mutation has already happened.  If the bounded undo log
            // cannot record its inverse, repair this occurrence immediately before
            // surfacing TransactionCapacityExceeded; no unlogged mutation escapes.
            if(inverse_is_unlink)out_<<"  "<<temp(op.id,"tx.rel.repaired.unlink")<<" = call i1 @staze_relation_unlink("<<args<<")\n";
            else out_<<"  "<<temp(op.id,"tx.rel.repaired.link")<<" = call i32 @staze_relation_link("<<args<<", i1 "<<(rp.source_many?"true":"false")<<", i1 "<<(rp.target_many?"true":"false")<<", i1 "<<(rp.unique_pair?"true":"false")<<")\n";
            if(has_tx_capacity_edge(op))out_<<"  br label %"<<fault_edge_label(b,op,"TransactionCapacityExceeded")<<"\n";
            else out_<<"  unreachable\n";
            out_<<success<<":\n";
        };
        if(op.opcode==SirOpcode::RelationUnlink){
            out_<<"  "<<temp(op.id,"removed")<<" = call i1 @staze_relation_unlink("<<args<<")\n";
            dynamic_log(temp(op.id,"removed"),3,false);
            out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";
            if(!dynamic_transactions())activate_simple_undo_if(op.id,temp(op.id,"removed"));
            return;
        }
        if(op.opcode==SirOpcode::RelationLink){
            out_<<"  "<<temp(op.id,"relcode")<<" = call i32 @staze_relation_link("<<args<<", i1 "<<(rp.source_many?"true":"false")<<", i1 "<<(rp.target_many?"true":"false")<<", i1 "<<(rp.unique_pair?"true":"false")<<")\n";
            out_<<"  "<<temp(op.id,"relbad")<<" = icmp eq i32 "<<temp(op.id,"relcode")<<", 2\n";
            const auto after=local_label(b.id,op.id,"after");
            out_<<"  br i1 "<<temp(op.id,"relbad")<<", label %"<<fault_edge_label(b,op,"RelationCapacityExceeded")<<", label %"<<after<<"\n";
            out_<<after<<":\n";
            out_<<"  "<<temp(op.id,"inserted")<<" = icmp eq i32 "<<temp(op.id,"relcode")<<", 0\n";
            dynamic_log(temp(op.id,"inserted"),2,true);
            out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";
            if(!dynamic_transactions())activate_simple_undo_if(op.id,temp(op.id,"inserted"));
            return;
        }
    }

    const SirConcreteTask* task_for_begin(SirOpId op) const {
        auto it=std::find_if(concrete_.tasks.begin(),concrete_.tasks.end(),[&](const auto&t){return t.begin_op==op;});
        return it==concrete_.tasks.end()?nullptr:&*it;
    }
    const SirConcreteTask* task_for_name(const std::string& name) const {
        auto it=std::find_if(concrete_.tasks.begin(),concrete_.tasks.end(),[&](const auto&t){return t.name==name;});
        return it==concrete_.tasks.end()?nullptr:&*it;
    }
    std::string task_ctx(const SirConcreteTask& t) const {return "%task."+std::to_string(t.id)+".ctx";}
    std::string task_handle(const SirConcreteTask& t) const {return "%task."+std::to_string(t.id)+".handle";}
    std::string task_worker_symbol(const SirConcreteTask& t) const {return "@staze_worker_"+safe_name(fn_.name)+"_"+std::to_string(t.id);}
    bool block_in_task_region(const SirBlock& b) const {
        for(const auto&t:concrete_.tasks)if(region_inside(fn_,b.region,t.task_region))return true;
        return false;
    }
    SirBlockId task_continuation(const SirConcreteTask& t) const {
        for(const auto&b:fn_.blocks)for(const auto&op:b.instructions)if(op.id==t.end_op){
            if(b.terminator.kind!=SirTerminatorKind::Br)throw CompileError({},"LLVM backend: TaskEnd block must branch to parent continuation");
            return b.terminator.target;
        }
        throw CompileError({},"LLVM backend: task plan names missing TaskEnd operation");
    }
    std::vector<const SirConcreteTaskCapture*> captures_for_task(const SirConcreteTask& t) const {
        std::vector<const SirConcreteTaskCapture*> v;
        for(const auto&c:concrete_.task_captures)if(c.task_region==t.task_region)v.push_back(&c);
        std::sort(v.begin(),v.end(),[](auto*a,auto*b){return a->byte_offset<b->byte_offset;});
        return v;
    }
    std::vector<const SirConcreteTask*> tasks_for_parallel(SirRegionId r) const {
        std::vector<const SirConcreteTask*> v;
        for(const auto&t:concrete_.tasks)if(t.parallel_region==r)v.push_back(&t);
        std::sort(v.begin(),v.end(),[](auto*a,auto*b){return a->id<b->id;});
        return v;
    }
    std::string task_field_ptr(const SirConcreteTask& t,std::uint32_t off,const std::string& suffix) {
        if(off==0)return task_ctx(t);
        const auto n="%task."+std::to_string(t.id)+"."+suffix+".ptr";
        out_<<"  "<<n<<" = getelementptr i8, ptr "<<task_ctx(t)<<", i64 "<<off<<"\n";
        return n;
    }
    void emit_task_begin(const SirBlock& b,const SirInstruction& op) {
        const auto*t=task_for_begin(op.id);if(!t)throw CompileError({},"LLVM backend: TaskBegin lacks concrete task plan");
        for(const auto*c:captures_for_task(*t)){
            const auto ptr=task_field_ptr(*t,c->byte_offset,"cap"+std::to_string(c->id));
            if(c->mode=="shared-read"||c->mode=="send"||c->mode=="unique-mut"){
                const auto src=rich_ptr(c->value);
                if(c->mode=="shared-read")out_<<"  call void @staze_shared_retain_if_nonnull(ptr "<<src<<")\n";
                out_<<"  store ptr "<<src<<", ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,c->align)<<"\n";
            }else if(is_rich(c->value)){
                emit_memcpy(ptr,rich_ptr(c->value),std::min(c->size,cv(c->value).size));
            }else{
                const auto ty=llvm_ty(value_type(c->value));
                out_<<"  store "<<ty<<" "<<scalar(c->value)<<", ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,c->align)<<"\n";
            }
        }
        const auto sp=task_field_ptr(*t,t->status_offset,"status");
        const auto cp=task_field_ptr(*t,t->cause_offset,"cause");
        out_<<"  store i32 0, ptr "<<sp<<", align 4\n  store i32 0, ptr "<<cp<<", align 4\n";
        const auto h=temp(op.id,"thread");
        out_<<"  "<<h<<" = call ptr @CreateThread(ptr null, i64 0, ptr "<<task_worker_symbol(*t)<<", ptr "<<task_ctx(*t)<<", i32 0, ptr null)\n";
        const auto isnull=temp(op.id,"thread.null"),async=local_label(b.id,op.id,"thread.async"),sync=local_label(b.id,op.id,"thread.sync"),after=local_label(b.id,op.id,"thread.after");
        out_<<"  "<<isnull<<" = icmp eq ptr "<<h<<", null\n  br i1 "<<isnull<<", label %"<<sync<<", label %"<<async<<"\n";
        out_<<async<<":\n  store ptr "<<h<<", ptr "<<task_handle(*t)<<", align 8\n  br label %"<<after<<"\n";
        out_<<sync<<":\n  %task."<<t->id<<".sync.code = call i32 "<<task_worker_symbol(*t)<<"(ptr "<<task_ctx(*t)<<")\n  store ptr null, ptr "<<task_handle(*t)<<", align 8\n  br label %"<<after<<"\n";
        out_<<after<<":\n  "<<value_name(op.result)<<" = add i8 0, 0\n";
    }
    void emit_parallel_end(const SirBlock& b,const SirInstruction& op) {
        const auto tasks=tasks_for_parallel(op.region);
        if(tasks.empty()){out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";return;}
        const bool can_fail=std::any_of(op.fault_edges.begin(),op.fault_edges.end(),[](const auto&e){return e.fault=="TaskFailure";});
        // First join every asynchronously-created worker.  Fault inspection happens only
        // after all workers have completed, giving deterministic aggregation semantics.
        for(const auto*t:tasks){
            const auto h="%task."+std::to_string(t->id)+".join.handle";
            const auto isnull="%task."+std::to_string(t->id)+".join.null";
            const auto wait=local_label(b.id,op.id,"wait."+std::to_string(t->id));
            const auto next=local_label(b.id,op.id,"waited."+std::to_string(t->id));
            out_<<"  "<<h<<" = load ptr, ptr "<<task_handle(*t)<<", align 8\n  "<<isnull<<" = icmp eq ptr "<<h<<", null\n  br i1 "<<isnull<<", label %"<<next<<", label %"<<wait<<"\n";
            out_<<wait<<":\n  %task."<<t->id<<".wait.code = call i32 @WaitForSingleObject(ptr "<<h<<", i32 -1)\n  %task."<<t->id<<".close.code = call i32 @CloseHandle(ptr "<<h<<")\n  store ptr null, ptr "<<task_handle(*t)<<", align 8\n  br label %"<<next<<"\n"<<next<<":\n";
        }
        if(!can_fail){out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";return;}
        const auto done=local_label(b.id,op.id,"tasks.ok");
        for(std::size_t i=0;i<tasks.size();++i){
            const auto*t=tasks[i];
            const auto sp=task_field_ptr(*t,t->status_offset,"join.status"),cp=task_field_ptr(*t,t->cause_offset,"join.cause");
            const auto status="%task."+std::to_string(t->id)+".join.status";
            const auto bad="%task."+std::to_string(t->id)+".join.bad";
            const auto fail=local_label(b.id,op.id,"taskfail."+std::to_string(t->id));
            const auto next=i+1<tasks.size()?local_label(b.id,op.id,"taskscan."+std::to_string(i+1)):done;
            out_<<"  "<<status<<" = load i32, ptr "<<sp<<", align 4\n  "<<bad<<" = icmp ne i32 "<<status<<", 0\n  br i1 "<<bad<<", label %"<<fail<<", label %"<<next<<"\n";
            out_<<fail<<":\n";
            auto taskid=byte_ptr("%fault_out",0,"%taskfail."+std::to_string(t->id)+".id.ptr");
            auto cause=byte_ptr("%fault_out",4,"%taskfail."+std::to_string(t->id)+".cause.ptr");
            out_<<"  store i32 "<<t->id<<", ptr "<<taskid<<", align 4\n";
            const auto cv="%task."+std::to_string(t->id)+".cause.value";
            out_<<"  "<<cv<<" = load i32, ptr "<<cp<<", align 4\n  store i32 "<<cv<<", ptr "<<cause<<", align 4\n";
            out_<<"  br label %"<<fault_edge_label(b,op,"TaskFailure")<<"\n";
            if(i+1<tasks.size())out_<<next<<":\n";
        }
        out_<<done<<":\n  "<<value_name(op.result)<<" = add i8 0, 0\n";
    }
    void emit_task_join(const SirInstruction& op) {
        const auto*t=task_for_name(op.semantic_name);if(!t)throw CompileError({},"LLVM backend: TaskJoin names unknown task '"+op.semantic_name+"'");
        if(op.type==SirType::Unit){out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";return;}
        const auto ptr=task_field_ptr(*t,t->result_offset,"result");
        out_<<"  "<<value_name(op.result)<<" = load "<<llvm_ty(op.type)<<", ptr "<<ptr<<", align "<<std::min<std::uint32_t>(8,std::max<std::uint32_t>(1,t->context_align))<<"\n";
    }

    void emit_pool_alloc(const SirBlock& b, const SirInstruction& op) {
        const auto&l=concrete_layout(program_,op.semantic_name);const auto&p=cv(op.result);const auto*ps=pool_schema(program_,op.semantic_name);if(!ps)throw CompileError({},"LLVM backend: missing pool schema");
        if(p.storage==SirStorageClass::Heap){
            out_<<"  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n";
            const bool shared = ps->ownership == "shared";
            const auto alloc_bytes = static_cast<std::uint64_t>(p.size) + (shared ? 8u : 0u);
            out_<<"  "<<temp(op.id,"base")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 0, i64 "<<alloc_bytes<<")\n";
            out_<<"  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"base")<<", null\n";
            const auto after=local_label(b.id,op.id,"after");
            out_<<"  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<after<<"\n";
            out_<<after<<":\n";
            if(shared){
                out_<<"  store i64 1, ptr "<<temp(op.id,"base")<<", align 8\n";
                out_<<"  "<<value_name(op.result)<<" = getelementptr i8, ptr "<<temp(op.id,"base")<<", i64 8\n";
            }else{
                out_<<"  "<<value_name(op.result)<<" = getelementptr i8, ptr "<<temp(op.id,"base")<<", i64 0\n";
            }
            mark_resource_pointer(op.result,rich_ptr(op.result));
        }else if(p.storage==SirStorageClass::Static){
            // Static storage is emitted at module scope; the allocation operation initializes it.
        }else{
            emit_alloca(op.result);
            if(const auto* r=resource_for_value(op.result);r&&r->automatic&&r->cleanup==SirCleanupKind::LifetimeEnd)
                out_<<"  call void @llvm.lifetime.start.p0(i64 "<<r->size<<", ptr "<<rich_ptr(op.result)<<")\n";
        }
        for(std::size_t i=0;i<op.operands.size();++i)store_value(rich_ptr(op.result),l.field_offsets.at(i),op.operands[i],cv(op.operands[i]).size,cv(op.operands[i]).align,temp(op.id,"pool."+std::to_string(i)));
        activate_simple_undo(op.id);
    }

    std::uint32_t field_offset(const SirInstruction& op) const {
        auto pos=op.semantic_name.find('.');if(pos==std::string::npos)throw CompileError({},"LLVM backend: field op lacks owner.field identity");
        const auto owner=op.semantic_name.substr(0,pos);const auto& l=concrete_layout(program_,owner);if(op.tag>=l.field_offsets.size())throw CompileError({},"LLVM backend: field ordinal outside concrete layout");return l.field_offsets[op.tag];
    }
    void emit_field_load(const SirInstruction& op) {
        const auto root=rich_ptr(op.operands.at(0));const auto off=cv(op.result).byte_offset;
        const auto ptr=temp(op.id,"field.ptr");out_<<"  "<<ptr<<" = getelementptr i8, ptr "<<root<<", i64 "<<off<<"\n";
        if(is_rich(op.result)) out_<<"  "<<value_name(op.result)<<" = getelementptr i8, ptr "<<ptr<<", i64 0\n";
        else out_<<"  "<<value_name(op.result)<<" = load "<<llvm_ty(op.type)<<", ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,std::min<std::uint32_t>(cv(op.result).align,8))<<"\n";
    }
    void emit_field_address(const SirInstruction& op) {
        const auto root=rich_ptr(op.operands.at(0));out_<<"  "<<value_name(op.result)<<" = getelementptr i8, ptr "<<root<<", i64 "<<cv(op.result).byte_offset<<"\n";
    }
    void emit_field_store(const SirBlock& b,const SirInstruction& op) {
        const auto root=rich_ptr(op.operands.at(0));const auto off=field_offset(op);const auto value=op.operands.at(1);
        snapshot_field_undo(b,op,root,off);
        store_value(root,off,value,cv(value).size,cv(value).align,temp(op.id,"field.store"));
        out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";
    }

    void emit_field_move(const SirInstruction& op) {
        const auto root = rich_ptr(op.operands.at(0));
        const auto off = field_offset(op);
        const auto fieldp = temp(op.id, "field.ptr");
        out_ << "  " << fieldp << " = getelementptr i8, ptr " << root << ", i64 " << off << "\n";
        const auto& plan = cv(op.result);
        if (plan.kind == SirConcreteKind::BorrowRef && plan.size == 8) {
            out_ << "  " << value_name(op.result) << " = load ptr, ptr " << fieldp << ", align 8\n";
            out_ << "  store ptr null, ptr " << fieldp << ", align 8\n";
            mark_resource_pointer(op.result, value_name(op.result));
            activate_simple_undo(op.id);
            return;
        }
        throw CompileError({}, "LLVM backend: Compiler 0.9 partial field move currently requires a pointer-bearing resource field");
    }

    void emit_shared_retain(const SirInstruction& op) {
        const auto src = rich_ptr(op.operands.at(0));
        out_ << "  call void @staze_shared_retain_if_nonnull(ptr " << src << ")\n";
        out_ << "  " << value_name(op.result) << " = getelementptr i8, ptr " << src << ", i64 0\n";
        mark_resource_pointer(op.result, value_name(op.result));
        activate_simple_undo(op.id);
    }

    void clear_resource_slot_for_value(SirValueId value) {
        const auto* r = resource_for_value(value);
        if (r && (r->automatic || undo_tracked_values_.contains(r->value)) && (r->cleanup == SirCleanupKind::HeapFree || r->cleanup == SirCleanupKind::ManyBufferFree || r->cleanup == SirCleanupKind::SharedRelease))
            out_ << "  store ptr null, ptr " << resource_slot(r->id) << ", align 8\n";
    }

    void emit_resource_release(const SirInstruction& op) {
        const auto source = op.operands.at(0);
        const auto* sem = value_semantics_.at(source);
        if (sem->borrow_mode != "none" || sem->ownership == "borrow" || sem->ownership == "borrow-shared" || sem->ownership == "borrow-mut") {
            out_ << "  " << value_name(op.result) << " = add i8 0, 0\n";
            return;
        }
        const auto ptr = rich_ptr(source);
        if (sem->ownership == "shared" || sem->resource_family.rfind("shared-pool:", 0) == 0)
            out_ << "  call void @staze_shared_release_if_nonnull(ptr " << ptr << ")\n";
        else if (sem->resource_family.rfind("heap-pool:", 0) == 0)
            out_ << "  call void @staze_heap_free_if_nonnull(ptr " << ptr << ")\n";
        else if (sem->resource_family == "dynamic-many" || sem->resource_family == "dynamic-text" || sem->resource_family == "dynamic-map" || sem->resource_family == "dynamic-bytes") {
            const auto data = "%release.data." + std::to_string(op.id);
            out_ << "  " << data << " = load ptr, ptr " << ptr << ", align 8\n";
            out_ << "  call void @staze_heap_free_if_nonnull(ptr " << data << ")\n";
        } else
            throw CompileError({}, "LLVM backend: resource.release has no supported native resource family");
        clear_resource_slot_for_value(source);
        out_ << "  " << value_name(op.result) << " = add i8 0, 0\n";
    }

    void emit_many_dynamic(const SirBlock& b,const SirInstruction& op) {
        emit_alloca(op.result);const auto&p=cv(op.result);const auto cap=scalar(op.operands.at(0));
        const auto pair=temp(op.id,"bytes.pair"),bytes=temp(op.id,"bytes"),ov=temp(op.id,"bytes.ov"),alloc=local_label(b.id,op.id,"alloc"),after=local_label(b.id,op.id,"after");
        out_<<"  "<<pair<<" = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 "<<cap<<", i64 "<<p.element_size<<")\n";
        out_<<"  "<<bytes<<" = extractvalue { i64, i1 } "<<pair<<", 0\n";
        out_<<"  "<<ov<<" = extractvalue { i64, i1 } "<<pair<<", 1\n";
        out_<<"  br i1 "<<ov<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<alloc<<"\n"<<alloc<<":\n";
        out_<<"  "<<temp(op.id,"cap.zero")<<" = icmp eq i64 "<<cap<<", 0\n";
        out_<<"  "<<temp(op.id,"alloc.bytes")<<" = select i1 "<<temp(op.id,"cap.zero")<<", i64 "<<std::max<std::uint32_t>(1,p.element_size)<<", i64 "<<bytes<<"\n";
        out_<<"  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n";
        out_<<"  "<<temp(op.id,"data")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 0, i64 "<<temp(op.id,"alloc.bytes")<<")\n";
        out_<<"  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"data")<<", null\n";
        out_<<"  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<after<<"\n"<<after<<":\n";
        out_<<"  store ptr "<<temp(op.id,"data")<<", ptr "<<rich_ptr(op.result)<<", align 8\n";
        auto lp=byte_ptr(rich_ptr(op.result),8,temp(op.id,"len.ptr"));out_<<"  store i64 0, ptr "<<lp<<", align 8\n";
        auto cp=byte_ptr(rich_ptr(op.result),16,temp(op.id,"cap.ptr"));out_<<"  store i64 "<<cap<<", ptr "<<cp<<", align 8\n";
        mark_resource_pointer(op.result,temp(op.id,"data"));
    }
    void emit_many_length(const SirInstruction& op){auto lp=byte_ptr(rich_ptr(op.operands.at(0)),8,temp(op.id,"len.ptr"));out_<<"  "<<value_name(op.result)<<" = load i64, ptr "<<lp<<", align 8\n";}
    void emit_many_push(const SirBlock& b,const SirInstruction& op){
        const auto list=op.operands.at(0),item=op.operands.at(1);const auto& p=cv(list);const auto base=rich_ptr(list);
        auto lp=byte_ptr(base,8,temp(op.id,"len.ptr")),cp=byte_ptr(base,16,temp(op.id,"cap.ptr"));
        out_<<"  "<<temp(op.id,"data")<<" = load ptr, ptr "<<base<<", align 8\n";
        out_<<"  "<<temp(op.id,"len")<<" = load i64, ptr "<<lp<<", align 8\n";
        out_<<"  "<<temp(op.id,"cap")<<" = load i64, ptr "<<cp<<", align 8\n";
        out_<<"  "<<temp(op.id,"room")<<" = icmp ult i64 "<<temp(op.id,"len")<<", "<<temp(op.id,"cap")<<"\n";
        const auto grow=local_label(b.id,op.id,"grow"),append=local_label(b.id,op.id,"append"),after=local_label(b.id,op.id,"after");
        out_<<"  br i1 "<<temp(op.id,"room")<<", label %"<<append<<", label %"<<grow<<"\n"<<grow<<":\n";
        out_<<"  "<<temp(op.id,"cap.zero")<<" = icmp eq i64 "<<temp(op.id,"cap")<<", 0\n";
        out_<<"  "<<temp(op.id,"grow.pair")<<" = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 "<<temp(op.id,"cap")<<", i64 2)\n";
        out_<<"  "<<temp(op.id,"grow.double")<<" = extractvalue { i64, i1 } "<<temp(op.id,"grow.pair")<<", 0\n";
        out_<<"  "<<temp(op.id,"grow.ov0")<<" = extractvalue { i64, i1 } "<<temp(op.id,"grow.pair")<<", 1\n";
        out_<<"  "<<temp(op.id,"newcap")<<" = select i1 "<<temp(op.id,"cap.zero")<<", i64 4, i64 "<<temp(op.id,"grow.double")<<"\n";
        out_<<"  "<<temp(op.id,"grow.ov")<<" = select i1 "<<temp(op.id,"cap.zero")<<", i1 false, i1 "<<temp(op.id,"grow.ov0")<<"\n";
        const auto bytescheck=local_label(b.id,op.id,"bytescheck");out_<<"  br i1 "<<temp(op.id,"grow.ov")<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<bytescheck<<"\n"<<bytescheck<<":\n";
        out_<<"  "<<temp(op.id,"bytes.pair")<<" = call { i64, i1 } @llvm.umul.with.overflow.i64(i64 "<<temp(op.id,"newcap")<<", i64 "<<p.element_size<<")\n";
        out_<<"  "<<temp(op.id,"bytes")<<" = extractvalue { i64, i1 } "<<temp(op.id,"bytes.pair")<<", 0\n";
        out_<<"  "<<temp(op.id,"bytes.ov")<<" = extractvalue { i64, i1 } "<<temp(op.id,"bytes.pair")<<", 1\n";
        const auto allocate=local_label(b.id,op.id,"allocate");out_<<"  br i1 "<<temp(op.id,"bytes.ov")<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<allocate<<"\n"<<allocate<<":\n";
        out_<<"  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n";
        out_<<"  "<<temp(op.id,"newdata")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 0, i64 "<<temp(op.id,"bytes")<<")\n";
        out_<<"  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"newdata")<<", null\n";
        const auto copy=local_label(b.id,op.id,"copy");out_<<"  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<copy<<"\n"<<copy<<":\n";
        out_<<"  "<<temp(op.id,"used.bytes")<<" = mul i64 "<<temp(op.id,"len")<<", "<<p.element_size<<"\n";
        out_<<"  call void @llvm.memcpy.p0.p0.i64(ptr "<<temp(op.id,"newdata")<<", ptr "<<temp(op.id,"data")<<", i64 "<<temp(op.id,"used.bytes")<<", i1 false)\n";
        out_<<"  call void @staze_heap_free_if_nonnull(ptr "<<temp(op.id,"data")<<")\n";
        out_<<"  store ptr "<<temp(op.id,"newdata")<<", ptr "<<base<<", align 8\n";
        out_<<"  store i64 "<<temp(op.id,"newcap")<<", ptr "<<cp<<", align 8\n";
        mark_resource_pointer(list,temp(op.id,"newdata"));
        out_<<"  br label %"<<append<<"\n"<<append<<":\n";
        out_<<"  "<<temp(op.id,"append.data")<<" = load ptr, ptr "<<base<<", align 8\n";
        out_<<"  "<<temp(op.id,"append.len")<<" = load i64, ptr "<<lp<<", align 8\n";
        out_<<"  "<<temp(op.id,"append.off")<<" = mul i64 "<<temp(op.id,"append.len")<<", "<<p.element_size<<"\n";
        out_<<"  "<<temp(op.id,"append.ptr")<<" = getelementptr i8, ptr "<<temp(op.id,"append.data")<<", i64 "<<temp(op.id,"append.off")<<"\n";
        store_value(temp(op.id,"append.ptr"),0,item,p.element_size,cv(item).align,temp(op.id,"append.value"));
        out_<<"  "<<temp(op.id,"nextlen")<<" = add i64 "<<temp(op.id,"append.len")<<", 1\n";
        out_<<"  store i64 "<<temp(op.id,"nextlen")<<", ptr "<<lp<<", align 8\n";
        out_<<"  "<<value_name(op.result)<<" = add i8 0, 0\n";
        out_<<"  br label %"<<after<<"\n"<<after<<":\n";
    }

    void emit_alias(const SirInstruction& op) {
        if(!is_rich(op.result)) { activate_simple_undo(op.id); return; }
        const auto src=rich_ptr(op.operands.at(0));const auto off=cv(op.result).byte_offset;
        if(src=="null") out_<<"  "<<value_name(op.result)<<" = inttoptr i64 0 to ptr\n";
        else out_<<"  "<<value_name(op.result)<<" = getelementptr i8, ptr "<<src<<", i64 "<<off<<"\n";
        activate_simple_undo(op.id);
    }

    void emit_call(const SirBlock& b, const SirInstruction& op) {
        const auto& callee=concrete_function(program_,op.callee);const bool rr=callee.result_storage==SirStorageClass::Caller;
        std::string transfer_slot;
        if(rr){
            if(callee.result_transfer==SirResultTransferKind::HeapObject || callee.result_transfer==SirResultTransferKind::BorrowRef || callee.result_transfer==SirResultTransferKind::SharedRef){transfer_slot=temp(op.id,"transfer.slot");out_<<"  "<<transfer_slot<<" = alloca ptr, align 8\n  store ptr null, ptr "<<transfer_slot<<", align 8\n";}
            else emit_alloca(op.result);
        }
        std::vector<std::string> args;
        for(auto v:op.operands) args.push_back(is_rich(v)?rich_ptr(v):box(v));
        if(rr){
            const bool pointer_transfer = callee.result_transfer==SirResultTransferKind::HeapObject || callee.result_transfer==SirResultTransferKind::BorrowRef || callee.result_transfer==SirResultTransferKind::SharedRef;
            const auto outptr=pointer_transfer?transfer_slot:rich_ptr(op.result);
            out_<<"  "<<temp(op.id,"status")<<" = call i32 @stz_"<<safe_name(op.callee)<<"(ptr "<<outptr<<", ptr %fault_out";
            for (std::size_t i = 0; i < args.size(); ++i) out_ << ", " << (is_rich(op.operands[i]) ? "ptr " : "i64 ") << args[i];
            out_ << ")\n";
        }else{
            out_<<"  "<<temp(op.id,"call")<<" = call { i32, i64 } @stz_"<<safe_name(op.callee)<<"(ptr %fault_out";
            for (std::size_t i = 0; i < args.size(); ++i) out_ << ", " << (is_rich(op.operands[i]) ? "ptr " : "i64 ") << args[i];
            out_ << ")\n";
            out_<<"  "<<temp(op.id,"status")<<" = extractvalue { i32, i64 } "<<temp(op.id,"call")<<", 0\n";
            out_<<"  "<<temp(op.id,"payload")<<" = extractvalue { i32, i64 } "<<temp(op.id,"call")<<", 1\n";
        }
        auto materialize_transfer=[&](){
            if(!rr)return;
            if(callee.result_transfer==SirResultTransferKind::HeapObject || callee.result_transfer==SirResultTransferKind::BorrowRef || callee.result_transfer==SirResultTransferKind::SharedRef){out_<<"  "<<value_name(op.result)<<" = load ptr, ptr "<<transfer_slot<<", align 8\n";mark_resource_pointer(op.result,value_name(op.result));}
            else if(callee.result_transfer==SirResultTransferKind::DynamicMany || callee.result_transfer==SirResultTransferKind::DynamicText || callee.result_transfer==SirResultTransferKind::DynamicMap || callee.result_transfer==SirResultTransferKind::DynamicBytes){auto dp=rich_ptr(op.result);out_<<"  "<<temp(op.id,"transfer.data")<<" = load ptr, ptr "<<dp<<", align 8\n";mark_resource_pointer(op.result,temp(op.id,"transfer.data"));}
        };
        if(op.fault_edges.empty()){if(!rr)unbox_to(op.result,op.type,temp(op.id,"payload"));else materialize_transfer();return;}
        const auto after=local_label(b.id,op.id,"after"),invalid=local_label(b.id,op.id,"invalid_status");
        out_<<"  switch i32 "<<temp(op.id,"status")<<", label %"<<invalid<<" [\n    i32 0, label %"<<after<<"\n";
        for (const auto& e : op.fault_edges) out_ << "    i32 " << fault_code(e.fault) << ", label %" << edge_label(b.id,e.target,op.id) << "\n";
        out_ << "  ]\n" << invalid << ":\n  unreachable\n" << after << ":\n";
        if(!rr)unbox_to(op.result,op.type,temp(op.id,"payload"));else materialize_transfer();
    }

    std::string descriptor_data(SirValueId id,const std::string& stem) {
        const auto p=rich_ptr(id);const auto n="%"+stem+".data";out_<<"  "<<n<<" = load ptr, ptr "<<p<<", align 8\n";return n;
    }
    std::string descriptor_length(SirValueId id,const std::string& stem) {
        const auto p=byte_ptr(rich_ptr(id),8,"%"+stem+".lenptr");const auto n="%"+stem+".len";out_<<"  "<<n<<" = load i64, ptr "<<p<<", align 8\n";return n;
    }
    void store_descriptor16(SirValueId id,const std::string& data,const std::string& len,const std::string& stem) {
        emit_alloca(id);auto base=rich_ptr(id);out_<<"  store ptr "<<data<<", ptr "<<base<<", align 8\n";auto lp=byte_ptr(base,8,"%"+stem+".lenptr.out");out_<<"  store i64 "<<len<<", ptr "<<lp<<", align 8\n";
    }
    void emit_const_text(const SirInstruction& op) {
        emit_alloca(op.result);auto si=strings_.find(op.text_value);if(si==strings_.end())throw CompileError({},"LLVM backend: text constant missing intern table");
        const auto ptr=temp(op.id,"text.ptr");out_<<"  "<<ptr<<" = getelementptr ["<<(op.text_value.size()+1)<<" x i8], ptr @.str"<<si->second<<", i64 0, i64 0\n";store_descriptor16(op.result,ptr,std::to_string(op.text_value.size()),"o"+std::to_string(op.id)+".text");
    }
    void emit_text_length(const SirInstruction& op){auto l=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".text");out_<<"  "<<value_name(op.result)<<" = add i64 "<<l<<", 0\n";}
    void emit_text_concat(const SirBlock& b,const SirInstruction& op){
        const auto a=descriptor_data(op.operands[0],"o"+std::to_string(op.id)+".a"), al=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".a");
        const auto c=descriptor_data(op.operands[1],"o"+std::to_string(op.id)+".b"), bl=descriptor_length(op.operands[1],"o"+std::to_string(op.id)+".b");
        const auto pair=temp(op.id,"len.pair"),len=temp(op.id,"len"),ov=temp(op.id,"len.ov"),alloc=local_label(b.id,op.id,"alloc"),ok=local_label(b.id,op.id,"after");
        out_<<"  "<<pair<<" = call { i64, i1 } @llvm.uadd.with.overflow.i64(i64 "<<al<<", i64 "<<bl<<")\n  "<<len<<" = extractvalue { i64, i1 } "<<pair<<", 0\n  "<<ov<<" = extractvalue { i64, i1 } "<<pair<<", 1\n  br i1 "<<ov<<", label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<", label %"<<alloc<<"\n"<<alloc<<":\n";
        out_<<"  "<<temp(op.id,"alloclen")<<" = add i64 "<<len<<", 1\n  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n  "<<temp(op.id,"data")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 0, i64 "<<temp(op.id,"alloclen")<<")\n  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"data")<<", null\n  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<ok<<"\n"<<ok<<":\n";
        out_<<"  call void @llvm.memcpy.p0.p0.i64(ptr "<<temp(op.id,"data")<<", ptr "<<a<<", i64 "<<al<<", i1 false)\n  "<<temp(op.id,"bptr")<<" = getelementptr i8, ptr "<<temp(op.id,"data")<<", i64 "<<al<<"\n  call void @llvm.memcpy.p0.p0.i64(ptr "<<temp(op.id,"bptr")<<", ptr "<<c<<", i64 "<<bl<<", i1 false)\n  "<<temp(op.id,"nulptr")<<" = getelementptr i8, ptr "<<temp(op.id,"data")<<", i64 "<<len<<"\n  store i8 0, ptr "<<temp(op.id,"nulptr")<<", align 1\n";
        store_descriptor16(op.result,temp(op.id,"data"),len,"o"+std::to_string(op.id)+".concat");mark_resource_pointer(op.result,temp(op.id,"data"));
    }
    void emit_text_slice(const SirBlock& b,const SirInstruction& op){
        const auto src=descriptor_data(op.operands[0],"o"+std::to_string(op.id)+".src"),total=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".src"),startv=scalar(op.operands[1]),len=scalar(op.operands[2]);
        const auto chk2=local_label(b.id,op.id,"bounds2"),checked=local_label(b.id,op.id,"checked"),after=local_label(b.id,op.id,"after");
        out_<<"  "<<temp(op.id,"start.bad")<<" = icmp ugt i64 "<<startv<<", "<<total<<"\n  br i1 "<<temp(op.id,"start.bad")<<", label %"<<fault_edge_label(b,op,"BoundsFailure")<<", label %"<<chk2<<"\n"<<chk2<<":\n  "<<temp(op.id,"remaining")<<" = sub i64 "<<total<<", "<<startv<<"\n  "<<temp(op.id,"len.bad")<<" = icmp ugt i64 "<<len<<", "<<temp(op.id,"remaining")<<"\n  br i1 "<<temp(op.id,"len.bad")<<", label %"<<fault_edge_label(b,op,"BoundsFailure")<<", label %"<<checked<<"\n"<<checked<<":\n  "<<temp(op.id,"view")<<" = getelementptr i8, ptr "<<src<<", i64 "<<startv<<"\n";
        if(op.tag==1){store_descriptor16(op.result,temp(op.id,"view"),len,"o"+std::to_string(op.id)+".sliceview");out_<<"  br label %"<<after<<"\n"<<after<<":\n";return;}
        const auto ok=local_label(b.id,op.id,"alloc.ok");out_<<"  "<<temp(op.id,"alloclen")<<" = add i64 "<<len<<", 1\n  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n  "<<temp(op.id,"data")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 0, i64 "<<temp(op.id,"alloclen")<<")\n  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"data")<<", null\n  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<ok<<"\n"<<ok<<":\n  call void @llvm.memcpy.p0.p0.i64(ptr "<<temp(op.id,"data")<<", ptr "<<temp(op.id,"view")<<", i64 "<<len<<", i1 false)\n  "<<temp(op.id,"nul")<<" = getelementptr i8, ptr "<<temp(op.id,"data")<<", i64 "<<len<<"\n  store i8 0, ptr "<<temp(op.id,"nul")<<", align 1\n";
        store_descriptor16(op.result,temp(op.id,"data"),len,"o"+std::to_string(op.id)+".textslice");mark_resource_pointer(op.result,temp(op.id,"data"));out_<<"  br label %"<<after<<"\n"<<after<<":\n";
    }

    void emit_slice_length(const SirInstruction& op){auto l=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".slice");out_<<"  "<<value_name(op.result)<<" = add i64 "<<l<<", 0\n";}
    void emit_slice_byte_at(const SirBlock& b,const SirInstruction& op){auto data=descriptor_data(op.operands[0],"o"+std::to_string(op.id)+".slice"),len=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".slice"),idx=scalar(op.operands[1]);auto ok=local_label(b.id,op.id,"after");out_<<"  "<<temp(op.id,"bad")<<" = icmp uge i64 "<<idx<<", "<<len<<"\n  br i1 "<<temp(op.id,"bad")<<", label %"<<fault_edge_label(b,op,"BoundsFailure")<<", label %"<<ok<<"\n"<<ok<<":\n  "<<temp(op.id,"p")<<" = getelementptr i8, ptr "<<data<<", i64 "<<idx<<"\n  "<<temp(op.id,"byte")<<" = load i8, ptr "<<temp(op.id,"p")<<", align 1\n  "<<value_name(op.result)<<" = zext i8 "<<temp(op.id,"byte")<<" to i32\n";}

    void emit_map_new(const SirBlock& b,const SirInstruction& op){
        emit_alloca(op.result);const auto cap=scalar(op.operands[0]),after=local_label(b.id,op.id,"after"),bad=local_label(b.id,op.id,"bad");
        out_<<"  "<<temp(op.id,"status")<<" = call i32 @staze_map_new(ptr "<<rich_ptr(op.result)<<", i64 "<<cap<<")\n  switch i32 "<<temp(op.id,"status")<<", label %"<<bad<<" [\n    i32 0, label %"<<after<<"\n    i32 1, label %"<<fault_edge_label(b,op,"ArithmeticOverflow")<<"\n    i32 2, label %"<<fault_edge_label(b,op,"AllocationFailure")<<"\n  ]\n"<<bad<<":\n  unreachable\n"<<after<<":\n";
        auto data=descriptor_data(op.result,"o"+std::to_string(op.id)+".map");mark_resource_pointer(op.result,data);
    }
    void emit_map_op(const SirBlock& b,const SirInstruction& op){
        const auto map=rich_ptr(op.operands[0]);
        if(op.opcode==SirOpcode::MapLength){out_<<"  "<<value_name(op.result)<<" = call i64 @staze_map_length(ptr "<<map<<")\n";return;}
        const auto key=box(op.operands[1]);
        if(op.opcode==SirOpcode::MapInsert){const auto val=box(op.operands[2]),ok=local_label(b.id,op.id,"after");out_<<"  "<<temp(op.id,"ok")<<" = call i1 @staze_map_insert(ptr "<<map<<", i64 "<<key<<", i64 "<<val<<")\n  br i1 "<<temp(op.id,"ok")<<", label %"<<ok<<", label %"<<fault_edge_label(b,op,"MapCapacityExceeded")<<"\n"<<ok<<":\n  "<<value_name(op.result)<<" = add i8 0, 0\n";return;}
        if(op.opcode==SirOpcode::MapContains){out_<<"  "<<value_name(op.result)<<" = call i1 @staze_map_contains(ptr "<<map<<", i64 "<<key<<")\n";return;}
        if(op.opcode==SirOpcode::MapRemove){out_<<"  "<<value_name(op.result)<<" = call i1 @staze_map_remove(ptr "<<map<<", i64 "<<key<<")\n";return;}
        if(op.opcode==SirOpcode::MapGet){emit_alloca(op.result);out_<<"  "<<temp(op.id,"pair")<<" = call { i1, i64 } @staze_map_get(ptr "<<map<<", i64 "<<key<<")\n  "<<temp(op.id,"present")<<" = extractvalue { i1, i64 } "<<temp(op.id,"pair")<<", 0\n  "<<temp(op.id,"payload")<<" = extractvalue { i1, i64 } "<<temp(op.id,"pair")<<", 1\n  store i1 "<<temp(op.id,"present")<<", ptr "<<rich_ptr(op.result)<<", align 1\n";const auto pp=byte_ptr(rich_ptr(op.result),cv(op.result).payload_offset,temp(op.id,"payload.ptr"));const auto t=value_type(op.result);(void)t; // value descriptor is optional; derive scalar from map nominal below.
            // Map values in the 0.9 native profile are POD scalars. Store the boxed payload using element size.
            const auto bytes=cv(op.result).element_size; if(bytes==8)out_<<"  store i64 "<<temp(op.id,"payload")<<", ptr "<<pp<<", align "<<cv(op.result).align<<"\n";else if(bytes==4){out_<<"  "<<temp(op.id,"v32")<<" = trunc i64 "<<temp(op.id,"payload")<<" to i32\n  store i32 "<<temp(op.id,"v32")<<", ptr "<<pp<<", align 4\n";}else if(bytes==1){out_<<"  "<<temp(op.id,"v1")<<" = trunc i64 "<<temp(op.id,"payload")<<" to i1\n  store i1 "<<temp(op.id,"v1")<<", ptr "<<pp<<", align 1\n";}else throw CompileError({},"LLVM backend: unsupported map optional payload width");return;}
    }
    void emit_memory_alloc(const SirBlock& b,const SirInstruction& op){
        emit_alloca(op.result);const auto sz=scalar(op.operands[0]),ok=local_label(b.id,op.id,"after");out_<<"  "<<temp(op.id,"zero")<<" = icmp eq i64 "<<sz<<", 0\n  "<<temp(op.id,"asz")<<" = select i1 "<<temp(op.id,"zero")<<", i64 1, i64 "<<sz<<"\n  "<<temp(op.id,"heap")<<" = call ptr @GetProcessHeap()\n  "<<temp(op.id,"data")<<" = call ptr @HeapAlloc(ptr "<<temp(op.id,"heap")<<", i32 8, i64 "<<temp(op.id,"asz")<<")\n  "<<temp(op.id,"null")<<" = icmp eq ptr "<<temp(op.id,"data")<<", null\n  br i1 "<<temp(op.id,"null")<<", label %"<<fault_edge_label(b,op,"AllocationFailure")<<", label %"<<ok<<"\n"<<ok<<":\n  store ptr "<<temp(op.id,"data")<<", ptr "<<rich_ptr(op.result)<<", align 8\n";auto lp=byte_ptr(rich_ptr(op.result),8,temp(op.id,"len.ptr")),cp=byte_ptr(rich_ptr(op.result),16,temp(op.id,"cap.ptr"));out_<<"  store i64 "<<sz<<", ptr "<<lp<<", align 8\n  store i64 "<<sz<<", ptr "<<cp<<", align 8\n";mark_resource_pointer(op.result,temp(op.id,"data"));
    }
    void emit_memory_size(const SirInstruction& op){auto l=descriptor_length(op.operands[0],"o"+std::to_string(op.id)+".bytes");out_<<"  "<<value_name(op.result)<<" = add i64 "<<l<<", 0\n";}
    void emit_file_read_text(const SirBlock& b,const SirInstruction& op){emit_alloca(op.result);const auto ok=local_label(b.id,op.id,"after"),bad=local_label(b.id,op.id,"bad");out_<<"  "<<temp(op.id,"status")<<" = call i32 @staze_file_read_text(ptr "<<rich_ptr(op.operands[0])<<", ptr "<<rich_ptr(op.result)<<")\n  switch i32 "<<temp(op.id,"status")<<", label %"<<bad<<" [\n    i32 0, label %"<<ok<<"\n    i32 1, label %"<<fault_edge_label(b,op,"IoFailure")<<"\n    i32 2, label %"<<fault_edge_label(b,op,"AllocationFailure")<<"\n  ]\n"<<bad<<":\n  unreachable\n"<<ok<<":\n";auto data=descriptor_data(op.result,"o"+std::to_string(op.id)+".read");mark_resource_pointer(op.result,data);}
    void emit_file_write_text(const SirBlock& b,const SirInstruction& op){const auto ok=local_label(b.id,op.id,"after"),bad=local_label(b.id,op.id,"bad");out_<<"  "<<temp(op.id,"status")<<" = call i32 @staze_file_write_text(ptr "<<rich_ptr(op.operands[0])<<", ptr "<<rich_ptr(op.operands[1])<<")\n  switch i32 "<<temp(op.id,"status")<<", label %"<<bad<<" [\n    i32 0, label %"<<ok<<"\n    i32 1, label %"<<fault_edge_label(b,op,"IoFailure")<<"\n";if(std::any_of(op.fault_edges.begin(),op.fault_edges.end(),[](const auto&e){return e.fault=="AllocationFailure";}))out_<<"    i32 2, label %"<<fault_edge_label(b,op,"AllocationFailure")<<"\n";else out_<<"    i32 2, label %"<<fault_edge_label(b,op,"IoFailure")<<"\n";out_<<"  ]\n"<<bad<<":\n  unreachable\n"<<ok<<":\n  "<<value_name(op.result)<<" = add i8 0, 0\n";}
    void emit_process_run(const SirBlock& b,const SirInstruction& op){const auto ok=local_label(b.id,op.id,"after"),bad=local_label(b.id,op.id,"bad");out_<<"  "<<temp(op.id,"r")<<" = call { i32, i32 } @staze_process_run(ptr "<<rich_ptr(op.operands[0])<<")\n  "<<temp(op.id,"status")<<" = extractvalue { i32, i32 } "<<temp(op.id,"r")<<", 0\n  "<<temp(op.id,"exit")<<" = extractvalue { i32, i32 } "<<temp(op.id,"r")<<", 1\n  switch i32 "<<temp(op.id,"status")<<", label %"<<bad<<" [\n    i32 0, label %"<<ok<<"\n    i32 1, label %"<<fault_edge_label(b,op,"ProcessFailure")<<"\n    i32 2, label %"<<fault_edge_label(b,op,"AllocationFailure")<<"\n  ]\n"<<bad<<":\n  unreachable\n"<<ok<<":\n  "<<value_name(op.result)<<" = add i32 "<<temp(op.id,"exit")<<", 0\n";}

    void emit_write_text(const SirBlock& b, const SirInstruction& op) {
        const auto data=descriptor_data(op.operands.at(0),"o"+std::to_string(op.id)+".write"),len=descriptor_length(op.operands.at(0),"o"+std::to_string(op.id)+".write");
        const auto fault=fault_edge_label(b,op,"IoFailure"),handle_ok=local_label(b.id,op.id,"handle_ok"),size_ok=local_label(b.id,op.id,"size_ok"),after=local_label(b.id,op.id,"after");
        out_<<"  "<<temp(op.id,"handle")<<" = call ptr @GetStdHandle(i32 -11)\n  "<<temp(op.id,"handle_i")<<" = ptrtoint ptr "<<temp(op.id,"handle")<<" to i64\n  "<<temp(op.id,"bad_minus1")<<" = icmp eq i64 "<<temp(op.id,"handle_i")<<", -1\n  "<<temp(op.id,"bad_zero")<<" = icmp eq i64 "<<temp(op.id,"handle_i")<<", 0\n  "<<temp(op.id,"bad_handle")<<" = or i1 "<<temp(op.id,"bad_minus1")<<", "<<temp(op.id,"bad_zero")<<"\n  br i1 "<<temp(op.id,"bad_handle")<<", label %"<<fault<<", label %"<<handle_ok<<"\n"<<handle_ok<<":\n";
        out_<<"  "<<temp(op.id,"too_big")<<" = icmp ugt i64 "<<len<<", 4294967295\n  br i1 "<<temp(op.id,"too_big")<<", label %"<<fault<<", label %"<<size_ok<<"\n"<<size_ok<<":\n  "<<temp(op.id,"len32")<<" = trunc i64 "<<len<<" to i32\n  "<<temp(op.id,"ok")<<" = call i32 @WriteFile(ptr "<<temp(op.id,"handle")<<", ptr "<<data<<", i32 "<<temp(op.id,"len32")<<", ptr @.staze_io_bytes, ptr null)\n  "<<temp(op.id,"failed")<<" = icmp eq i32 "<<temp(op.id,"ok")<<", 0\n  br i1 "<<temp(op.id,"failed")<<", label %"<<fault<<", label %"<<after<<"\n"<<after<<":\n";
    }

    void emit_instruction(const SirBlock& b, const SirInstruction& op) {
        switch(op.opcode){
            case SirOpcode::Phi: emit_phi(b,op); break;
            case SirOpcode::ConstUnit:case SirOpcode::ConstInt:case SirOpcode::ConstBool: break;
            case SirOpcode::ConstText: emit_const_text(op); break;
            case SirOpcode::RevisionMarker:case SirOpcode::MoveValue:case SirOpcode::SendValue:case SirOpcode::Borrow:case SirOpcode::BorrowMut: emit_alias(op); break;
            case SirOpcode::OptionalSome: emit_optional(op,true); break;
            case SirOpcode::OptionalNone: emit_optional(op,false); break;
            case SirOpcode::ManyMake: emit_many(op); break;
            case SirOpcode::AggregateMake: emit_aggregate(op); break;
            case SirOpcode::ChoiceMake: emit_choice(op); break;
            case SirOpcode::PoolAlloc: emit_pool_alloc(b,op); break;
            case SirOpcode::FieldLoad: emit_field_load(op); break;
            case SirOpcode::FieldAddress: emit_field_address(op); break;
            case SirOpcode::FieldStore: emit_field_store(b,op); break;
            case SirOpcode::FieldMove: emit_field_move(op); break;
            case SirOpcode::ManyDynamic: emit_many_dynamic(b,op); break;
            case SirOpcode::ManyPush: emit_many_push(b,op); break;
            case SirOpcode::ManyLength: emit_many_length(op); break;
            case SirOpcode::TextConcat: emit_text_concat(b,op); break;
            case SirOpcode::TextLength: emit_text_length(op); break;
            case SirOpcode::TextSlice: emit_text_slice(b,op); break;
            case SirOpcode::SliceLength: emit_slice_length(op); break;
            case SirOpcode::SliceByteAt: emit_slice_byte_at(b,op); break;
            case SirOpcode::MapNew: emit_map_new(b,op); break;
            case SirOpcode::MapInsert:case SirOpcode::MapGet:case SirOpcode::MapContains:case SirOpcode::MapRemove:case SirOpcode::MapLength: emit_map_op(b,op); break;
            case SirOpcode::FileReadText: emit_file_read_text(b,op); break;
            case SirOpcode::FileWriteText: emit_file_write_text(b,op); break;
            case SirOpcode::ProcessRun: emit_process_run(b,op); break;
            case SirOpcode::MemoryAlloc: emit_memory_alloc(b,op); break;
            case SirOpcode::MemorySize: emit_memory_size(op); break;
            case SirOpcode::ResourceRelease: emit_resource_release(op); break;
            case SirOpcode::SharedRetain: emit_shared_retain(op); break;
            case SirOpcode::RelationLink:case SirOpcode::RelationUnlink:case SirOpcode::RelationContains:case SirOpcode::RelationCount: emit_relation_op(b,op); break;
            case SirOpcode::TransactionBegin: begin_transaction(op.region); break;
            case SirOpcode::TransactionCommit: clear_transaction_undo(op.region); break;
            case SirOpcode::TransactionAbort: emit_transaction_abort(op); break;
            case SirOpcode::ParallelBegin: break;
            case SirOpcode::ParallelEnd: emit_parallel_end(b,op); break;
            case SirOpcode::TaskBegin: emit_task_begin(b,op); break;
            case SirOpcode::TaskJoin: emit_task_join(op); break;
            case SirOpcode::TaskReturn:case SirOpcode::TaskFail:case SirOpcode::TaskEnd: break;
            case SirOpcode::Not: out_<<"  "<<value_name(op.result)<<" = xor i1 "<<scalar(op.operands[0])<<", true\n"; break;
            case SirOpcode::CheckedNeg: emit_checked_neg(b,op); break;
            case SirOpcode::CheckedAdd: emit_faulting_overflow(b,op,"add"); break;
            case SirOpcode::CheckedSub: emit_faulting_overflow(b,op,"sub"); break;
            case SirOpcode::CheckedMul: emit_faulting_overflow(b,op,"mul"); break;
            case SirOpcode::CheckedDiv: emit_divmod(b,op,false); break;
            case SirOpcode::CheckedMod: emit_divmod(b,op,true); break;
            case SirOpcode::CompareEq:case SirOpcode::CompareNe:case SirOpcode::CompareLt:case SirOpcode::CompareLe:case SirOpcode::CompareGt:case SirOpcode::CompareGe:{
                const auto ot=value_type(op.operands[0]);std::string pred;if(op.opcode==SirOpcode::CompareEq)pred="eq";else if(op.opcode==SirOpcode::CompareNe)pred="ne";else if(op.opcode==SirOpcode::CompareLt)pred=sir_is_signed_integer(ot)?"slt":"ult";else if(op.opcode==SirOpcode::CompareLe)pred=sir_is_signed_integer(ot)?"sle":"ule";else if(op.opcode==SirOpcode::CompareGt)pred=sir_is_signed_integer(ot)?"sgt":"ugt";else pred=sir_is_signed_integer(ot)?"sge":"uge";
                out_<<"  "<<value_name(op.result)<<" = icmp "<<pred<<' '<<llvm_ty(ot)<<' '<<scalar(op.operands[0])<<", "<<scalar(op.operands[1])<<"\n";break;}
            case SirOpcode::Call: emit_call(b,op); break;
            case SirOpcode::WriteText: emit_write_text(b,op); break;
        }
    }

    void write_fault_payload(const SirTerminator& t) {
        if(t.fault_payload_passthrough||t.fault_payload.empty())return;
        const auto*fs=fault_schema(program_,t.fault);if(!fs)throw CompileError({},"LLVM backend: missing fault schema");
        std::uint32_t off=0;
        for(std::size_t i=0;i<t.fault_payload.size();++i){const auto v=t.fault_payload[i];const auto&p=cv(v);off=align_up(off,p.align);store_value("%fault_out",off,v,p.size,p.align,"%fault.store."+std::to_string(fault_store_counter_++));off+=p.size;}
    }

    void emit_return(const SirBlock& b,const SirTerminator& t) {
        if(rich_result()){
            if (!t.value) throw CompileError({}, "LLVM backend: rich result missing return value");
            const auto src = rich_ptr(*t.value);
            if(concrete_.result_transfer==SirResultTransferKind::HeapObject || concrete_.result_transfer==SirResultTransferKind::BorrowRef || concrete_.result_transfer==SirResultTransferKind::SharedRef) out_<<"  store ptr "<<src<<", ptr %result_out, align 8\n";
            else emit_memcpy("%result_out", src, std::min(concrete_.result_size, cv(*t.value).size));
            emit_cleanup_list(cleanup_actions(b.id,0xffffffffu,0,false));
            out_ << "  ret i32 0\n";
            return;
        }
        std::string payload="0";if(t.value)payload=box(*t.value);
        emit_cleanup_list(cleanup_actions(b.id,0xffffffffu,0,false));
        const auto a="%ret.status."+std::to_string(return_counter_),bb="%ret.value."+std::to_string(return_counter_++);
        out_<<"  "<<a<<" = insertvalue { i32, i64 } poison, i32 0, 0\n"<<"  "<<bb<<" = insertvalue { i32, i64 } "<<a<<", i64 "<<payload<<", 1\n"<<"  ret { i32, i64 } "<<bb<<"\n";
    }
    void emit_fault_return(const SirBlock& b,const SirTerminator& t) {
        write_fault_payload(t);
        emit_cleanup_list(cleanup_actions(b.id,0xffffffffu,0,true));
        if(rich_result()){out_<<"  ret i32 "<<fault_code(t.fault)<<"\n";return;}
        const auto a="%fault.status."+std::to_string(return_counter_),bb="%fault.value."+std::to_string(return_counter_++);
        out_<<"  "<<a<<" = insertvalue { i32, i64 } poison, i32 "<<fault_code(t.fault)<<", 0\n"<<"  "<<bb<<" = insertvalue { i32, i64 } "<<a<<", i64 0, 1\n"<<"  ret { i32, i64 } "<<bb<<"\n";
    }

    void emit_block(const SirBlock& b) {
        if(block_in_task_region(b))return;
        out_<<block_name(b.id)<<":\n";
        const SirConcreteTask* begun=nullptr;
        for(const auto&op:b.instructions){emit_instruction(b,op);if(op.opcode==SirOpcode::TaskBegin)begun=task_for_begin(op.id);}
        const auto&t=b.terminator;
        switch(t.kind){
            case SirTerminatorKind::Br:
                if(begun)out_<<"  br label %"<<edge_label(b.id,task_continuation(*begun),0)<<"\n";
                else out_<<"  br label %"<<edge_label(b.id,t.target,0)<<"\n";
                break;
            case SirTerminatorKind::CondBr:out_<<"  br i1 "<<scalar(t.condition)<<", label %"<<edge_label(b.id,t.true_target,0)<<", label %"<<edge_label(b.id,t.false_target,0)<<"\n";break;
            case SirTerminatorKind::Return:emit_return(b,t);break;
            case SirTerminatorKind::FaultReturn:emit_fault_return(b,t);break;
            case SirTerminatorKind::Unreachable:out_<<"  unreachable\n";break;
        }
    }

    const SirCProgram& program_; const SirFunction& fn_; const SirConcreteFunction& concrete_; const std::map<std::string,std::size_t>& strings_;
    std::unordered_map<SirValueId,Def> defs_;
    std::unordered_map<SirValueId,const SirConcreteValue*> concrete_values_;
    std::unordered_map<SirValueId,const SirValueSemantics*> value_semantics_;
    std::unordered_map<SirProvenanceId,const SirProvenance*> provenances_;
    std::unordered_map<std::uint32_t,const SirConcreteResource*> resources_;
    std::unordered_map<SirValueId,const SirConcreteResource*> resource_by_value_;
    std::unordered_map<SirProvenanceId,const SirConcreteResource*> resource_by_provenance_;
    std::unordered_map<SirOpId,std::vector<const SirConcreteUndo*>> undo_by_source_;
    std::unordered_map<SirRegionId,std::vector<const SirConcreteUndo*>> undo_by_transaction_;
    std::set<SirValueId> undo_tracked_values_;
    std::unordered_map<SirValueId,bool> preallocated_; std::ostringstream out_;
    std::size_t box_counter_{0},return_counter_{0},fault_store_counter_{0},cleanup_counter_{0};
};

std::string emit_task_worker_thunk(const SirFunction& parent,
                                   const SirConcreteFunction& parent_cf,
                                   const SirConcreteTask& task) {
    auto contract=std::find_if(parent.task_contracts.begin(),parent.task_contracts.end(),[&](const auto&t){return t.task_region==task.task_region;});
    if(contract==parent.task_contracts.end())throw CompileError({},"LLVM backend: worker thunk lacks task contract");
    auto sem=[&](SirValueId id)->const SirValueSemantics&{auto it=std::find_if(parent.values.begin(),parent.values.end(),[&](const auto&v){return v.value==id;});if(it==parent.values.end())throw CompileError({},"LLVM backend: task capture lacks value semantics");return *it;};
    auto cv=[&](SirValueId id)->const SirConcreteValue&{auto it=std::find_if(parent_cf.values.begin(),parent_cf.values.end(),[&](const auto&v){return v.value==id;});if(it==parent_cf.values.end())throw CompileError({},"LLVM backend: task capture lacks concrete value");return *it;};
    auto field=[&](std::ostringstream&o,std::uint32_t off,const std::string& name)->std::string{if(!off)return "%ctx";const auto n="%"+name;o<<"  "<<n<<" = getelementptr i8, ptr %ctx, i64 "<<off<<"\n";return n;};
    std::vector<const SirConcreteTaskCapture*> caps;for(const auto&c:parent_cf.task_captures)if(c.task_region==task.task_region)caps.push_back(&c);
    std::sort(caps.begin(),caps.end(),[](auto*a,auto*b){return a->byte_offset<b->byte_offset;});
    const auto helper="@stz___task_"+safe_name(parent.name)+"_"+std::to_string(task.id);
    const auto worker="@staze_worker_"+safe_name(parent.name)+"_"+std::to_string(task.id);
    std::ostringstream o;o<<"define internal i32 "<<worker<<"(ptr %ctx) {\nentry:\n";
    const auto fault_bytes=std::max<std::uint32_t>(1,parent_cf.fault_payload_size);
    const auto fault_align=std::max<std::uint32_t>(1,parent_cf.fault_payload_align);
    o<<"  %task.fault = alloca ["<<fault_bytes<<" x i8], align "<<fault_align<<"\n";
    std::vector<std::string> args;
    for(const auto*c:caps){
        const auto&vs=sem(c->value);const auto&cp=cv(c->value);const auto ptr=field(o,c->byte_offset,"cap."+std::to_string(c->id)+".ptr");
        const bool pointer_mode=c->mode=="shared-read"||c->mode=="send"||c->mode=="unique-mut";
        if(pointer_mode){const auto n="%cap."+std::to_string(c->id)+".p";o<<"  "<<n<<" = load ptr, ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,c->align)<<"\n";args.push_back("ptr "+n);continue;}
        if(cp.storage!=SirStorageClass::Register){args.push_back("ptr "+ptr);continue;}
        const auto ty=llvm_ty(vs.type),raw="%cap."+std::to_string(c->id)+".v";o<<"  "<<raw<<" = load "<<ty<<", ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,c->align)<<"\n";
        if(vs.type==SirType::I64||vs.type==SirType::U64)args.push_back("i64 "+raw);
        else if(vs.type==SirType::I32){const auto n=raw+".box";o<<"  "<<n<<" = sext i32 "<<raw<<" to i64\n";args.push_back("i64 "+n);}
        else if(vs.type==SirType::U32||vs.type==SirType::Bool){const auto n=raw+".box";o<<"  "<<n<<" = zext "<<ty<<" "<<raw<<" to i64\n";args.push_back("i64 "+n);}
        else if(vs.type==SirType::Unit)args.push_back("i64 0");
        else throw CompileError({},"LLVM backend: unsupported scalar worker capture");
    }
    o<<"  %task.call = call { i32, i64 } "<<helper<<"(ptr %task.fault";for(const auto&a:args)o<<", "<<a;o<<")\n";
    o<<"  %task.status = extractvalue { i32, i64 } %task.call, 0\n  %task.payload = extractvalue { i32, i64 } %task.call, 1\n";
    const auto sp=field(o,task.status_offset,"status.ptr"),causep=field(o,task.cause_offset,"cause.ptr");
    o<<"  store i32 %task.status, ptr "<<sp<<", align 4\n  store i32 %task.status, ptr "<<causep<<", align 4\n";
    if(task.result_type!=SirType::Unit){const auto rp=field(o,task.result_offset,"result.ptr");
        if(task.result_type==SirType::I64||task.result_type==SirType::U64)o<<"  store i64 %task.payload, ptr "<<rp<<", align 8\n";
        else if(task.result_type==SirType::I32||task.result_type==SirType::U32){o<<"  %task.result32 = trunc i64 %task.payload to i32\n  store i32 %task.result32, ptr "<<rp<<", align 4\n";}
        else if(task.result_type==SirType::Bool){o<<"  %task.result1 = trunc i64 %task.payload to i1\n  store i1 %task.result1, ptr "<<rp<<", align 1\n";}
        else throw CompileError({},"LLVM backend: unsupported worker result type");
    }
    for(const auto*c:caps)if(c->mode=="shared-read"){const auto ptr=field(o,c->byte_offset,"release."+std::to_string(c->id)+".ptr"),n="%release."+std::to_string(c->id);o<<"  "<<n<<" = load ptr, ptr "<<ptr<<", align "<<std::max<std::uint32_t>(1,c->align)<<"\n  call void @staze_shared_release_if_nonnull(ptr "<<n<<")\n";}
    o<<"  ret i32 0\n}\n\n";return o.str();
}

} // namespace

std::string LlvmWindowsX64Emitter::emit(const SirCProgram& p) const {
    SirVerifier{}.verify(p);
    std::map<std::string,std::size_t> strings;for(const auto&fn:p.functions)for(const auto&b:fn.blocks)for(const auto&op:b.instructions)if(op.opcode==SirOpcode::ConstText)strings.emplace(op.text_value,0);std::size_t si=0;for(auto&[_,id]:strings)id=si++;
    std::ostringstream o;o<<"; Generated from standalone SIR-C 7.x by Staze C++23 Compiler 0.9\n; AST/SSL/SIR-S are not visible to this backend. Concrete storage/layout decisions came from serialized SIR-C.\n";
    o<<"target triple = \""<<p.target_triple<<"\"\n\n";
    for(const auto&[s,id]:strings)o<<"@.str"<<id<<" = private unnamed_addr constant ["<<(s.size()+1)<<" x i8] c\""<<escape_bytes(s)<<"\\00\", align 1\n";
    for(const auto& cf:p.concrete_functions)for(const auto& v:cf.values)if(v.storage==SirStorageClass::Static&&!v.scalar_replaced)
        o<<"@.stz.static."<<safe_name(cf.name)<<".v"<<v.value<<" = internal global ["<<v.size<<" x i8] zeroinitializer, align "<<v.align<<"\n";
    for(const auto& r:p.concrete_relations){const auto n=safe_name(r.name);
        o<<"@.stz.rel."<<n<<".lock = internal global i32 0, align 4\n";
        o<<"@.stz.rel."<<n<<".count = internal global i64 0, align 8\n";
        o<<"@.stz.rel."<<n<<".used = internal global ["<<r.capacity<<" x i8] zeroinitializer, align 1\n";
        o<<"@.stz.rel."<<n<<".src = internal global ["<<r.capacity<<" x i64] zeroinitializer, align 8\n";
        o<<"@.stz.rel."<<n<<".tgt = internal global ["<<r.capacity<<" x i64] zeroinitializer, align 8\n";
    }
    o<<"@.staze_io_bytes = internal global i32 0, align 4\n\n";
    o<<"declare dllimport ptr @GetStdHandle(i32)\ndeclare dllimport i32 @WriteFile(ptr, ptr, i32, ptr, ptr)\ndeclare dllimport void @ExitProcess(i32)\n";
    o<<"declare dllimport ptr @GetProcessHeap()\ndeclare dllimport ptr @HeapAlloc(ptr, i32, i64)\ndeclare dllimport i32 @HeapFree(ptr, i32, ptr)\n";
    o<<"declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)\ndeclare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)\ndeclare dllimport i32 @GetFileSizeEx(ptr, ptr)\ndeclare dllimport i32 @CloseHandle(ptr)\n";
    o<<"declare dllimport i32 @CreateProcessA(ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr)\ndeclare dllimport i32 @WaitForSingleObject(ptr, i32)\ndeclare dllimport i32 @GetExitCodeProcess(ptr, ptr)\ndeclare dllimport ptr @CreateThread(ptr, i64, ptr, ptr, i32, ptr)\n";
    o<<"declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)\ndeclare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)\n";
    o<<"declare void @llvm.lifetime.start.p0(i64, ptr nocapture)\n";
    o<<"declare void @llvm.lifetime.end.p0(i64, ptr nocapture)\n";
    o<<"declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)\ndeclare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)\ndeclare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)\n";
    o<<"declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)\ndeclare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)\ndeclare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)\n";
    o<<"declare { i32, i1 } @llvm.uadd.with.overflow.i32(i32, i32)\ndeclare { i32, i1 } @llvm.usub.with.overflow.i32(i32, i32)\ndeclare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32)\n";
    o<<"declare { i64, i1 } @llvm.uadd.with.overflow.i64(i64, i64)\ndeclare { i64, i1 } @llvm.usub.with.overflow.i64(i64, i64)\ndeclare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64)\n\n";
    o<<"define internal void @staze_heap_free_if_nonnull(ptr %p) {\nentry:\n  %isnull = icmp eq ptr %p, null\n  br i1 %isnull, label %done, label %free\nfree:\n  %heap = call ptr @GetProcessHeap()\n  %ok = call i32 @HeapFree(ptr %heap, i32 0, ptr %p)\n  br label %done\ndone:\n  ret void\n}\n\n";
    o<<R"LLVM(define ptr @memcpy(ptr %dst, ptr %src, i64 %n) {
entry:
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %ni, %body ]
  %done = icmp uge i64 %i, %n
  br i1 %done, label %exit, label %body
body:
  %sp = getelementptr i8, ptr %src, i64 %i
  %b = load i8, ptr %sp, align 1
  %dp = getelementptr i8, ptr %dst, i64 %i
  store i8 %b, ptr %dp, align 1
  %ni = add i64 %i, 1
  br label %loop
exit:
  ret ptr %dst
}

define ptr @memset(ptr %dst, i32 %c, i64 %n) {
entry:
  %byte = trunc i32 %c to i8
  br label %loop
loop:
  %i = phi i64 [ 0, %entry ], [ %ni, %body ]
  %done = icmp uge i64 %i, %n
  br i1 %done, label %exit, label %body
body:
  %dp = getelementptr i8, ptr %dst, i64 %i
  store i8 %byte, ptr %dp, align 1
  %ni = add i64 %i, 1
  br label %loop
exit:
  ret ptr %dst
}

define internal i32 @staze_map_new(ptr %d, i64 %cap) {
entry:
  %too = icmp ugt i64 %cap, 768614336404564650
  br i1 %too, label %overflow, label %size
 overflow:
  ret i32 1
 size:
  %bytes = mul i64 %cap, 24
  %zero = icmp eq i64 %cap, 0
  %allocbytes = select i1 %zero, i64 1, i64 %bytes
  %heap = call ptr @GetProcessHeap()
  %p = call ptr @HeapAlloc(ptr %heap, i32 8, i64 %allocbytes)
  %null = icmp eq ptr %p, null
  br i1 %null, label %oom, label %ok
 oom:
  ret i32 2
 ok:
  store ptr %p, ptr %d, align 8
  %lp = getelementptr i8, ptr %d, i64 8
  store i64 0, ptr %lp, align 8
  %cp = getelementptr i8, ptr %d, i64 16
  store i64 %cap, ptr %cp, align 8
  %sp = getelementptr i8, ptr %d, i64 24
  store i64 24, ptr %sp, align 8
  ret i32 0
}

define internal i1 @staze_map_insert(ptr %d, i64 %key, i64 %value) {
entry:
  %slots = load ptr, ptr %d, align 8
  %cp = getelementptr i8, ptr %d, i64 16
  %cap = load i64, ptr %cp, align 8
  %free = alloca i64, align 8
  store i64 -1, ptr %free, align 8
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %nexti, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %finish, label %slot
slot:
  %off = mul i64 %i, 24
  %s = getelementptr i8, ptr %slots, i64 %off
  %used8 = load i8, ptr %s, align 1
  %used = icmp ne i8 %used8, 0
  br i1 %used, label %check, label %remember
remember:
  %oldfree = load i64, ptr %free, align 8
  %unset = icmp eq i64 %oldfree, -1
  br i1 %unset, label %setfree, label %next
setfree:
  store i64 %i, ptr %free, align 8
  br label %next
check:
  %kp = getelementptr i8, ptr %s, i64 8
  %k = load i64, ptr %kp, align 8
  %eq = icmp eq i64 %k, %key
  br i1 %eq, label %update, label %next
update:
  %vp = getelementptr i8, ptr %s, i64 16
  store i64 %value, ptr %vp, align 8
  ret i1 true
next:
  %nexti = add i64 %i, 1
  br label %scan
finish:
  %fi = load i64, ptr %free, align 8
  %none = icmp eq i64 %fi, -1
  br i1 %none, label %full, label %insert
full:
  ret i1 false
insert:
  %foff = mul i64 %fi, 24
  %fs = getelementptr i8, ptr %slots, i64 %foff
  store i8 1, ptr %fs, align 1
  %fkp = getelementptr i8, ptr %fs, i64 8
  store i64 %key, ptr %fkp, align 8
  %fvp = getelementptr i8, ptr %fs, i64 16
  store i64 %value, ptr %fvp, align 8
  %lp = getelementptr i8, ptr %d, i64 8
  %len = load i64, ptr %lp, align 8
  %nlen = add i64 %len, 1
  store i64 %nlen, ptr %lp, align 8
  ret i1 true
}

define internal { i1, i64 } @staze_map_get(ptr %d, i64 %key) {
entry:
  %slots = load ptr, ptr %d, align 8
  %cp = getelementptr i8, ptr %d, i64 16
  %cap = load i64, ptr %cp, align 8
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %ni, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %miss, label %slot
slot:
  %off = mul i64 %i, 24
  %s = getelementptr i8, ptr %slots, i64 %off
  %u8 = load i8, ptr %s, align 1
  %used = icmp ne i8 %u8, 0
  br i1 %used, label %check, label %next
check:
  %kp = getelementptr i8, ptr %s, i64 8
  %k = load i64, ptr %kp, align 8
  %eq = icmp eq i64 %k, %key
  br i1 %eq, label %hit, label %next
hit:
  %vp = getelementptr i8, ptr %s, i64 16
  %v = load i64, ptr %vp, align 8
  %a = insertvalue { i1, i64 } poison, i1 true, 0
  %r = insertvalue { i1, i64 } %a, i64 %v, 1
  ret { i1, i64 } %r
next:
  %ni = add i64 %i, 1
  br label %scan
miss:
  %a0 = insertvalue { i1, i64 } poison, i1 false, 0
  %r0 = insertvalue { i1, i64 } %a0, i64 0, 1
  ret { i1, i64 } %r0
}

define internal i1 @staze_map_contains(ptr %d, i64 %key) {
entry:
  %r = call { i1, i64 } @staze_map_get(ptr %d, i64 %key)
  %p = extractvalue { i1, i64 } %r, 0
  ret i1 %p
}

define internal i1 @staze_map_remove(ptr %d, i64 %key) {
entry:
  %slots = load ptr, ptr %d, align 8
  %cp = getelementptr i8, ptr %d, i64 16
  %cap = load i64, ptr %cp, align 8
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %ni, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %miss, label %slot
slot:
  %off = mul i64 %i, 24
  %s = getelementptr i8, ptr %slots, i64 %off
  %u8 = load i8, ptr %s, align 1
  %used = icmp ne i8 %u8, 0
  br i1 %used, label %check, label %next
check:
  %kp = getelementptr i8, ptr %s, i64 8
  %k = load i64, ptr %kp, align 8
  %eq = icmp eq i64 %k, %key
  br i1 %eq, label %hit, label %next
hit:
  store i8 0, ptr %s, align 1
  %lp = getelementptr i8, ptr %d, i64 8
  %len = load i64, ptr %lp, align 8
  %nlen = sub i64 %len, 1
  store i64 %nlen, ptr %lp, align 8
  ret i1 true
next:
  %ni = add i64 %i, 1
  br label %scan
miss:
  ret i1 false
}

define internal i64 @staze_map_length(ptr %d) {
entry:
  %lp = getelementptr i8, ptr %d, i64 8
  %len = load i64, ptr %lp, align 8
  ret i64 %len
}

define internal ptr @staze_text_to_cstr(ptr %d) {
entry:
  %data = load ptr, ptr %d, align 8
  %lp = getelementptr i8, ptr %d, i64 8
  %len = load i64, ptr %lp, align 8
  %max = icmp eq i64 %len, -1
  br i1 %max, label %fail, label %alloc
alloc:
  %n = add i64 %len, 1
  %heap = call ptr @GetProcessHeap()
  %p = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %n)
  %null = icmp eq ptr %p, null
  br i1 %null, label %fail, label %copy
copy:
  call void @llvm.memcpy.p0.p0.i64(ptr %p, ptr %data, i64 %len, i1 false)
  %z = getelementptr i8, ptr %p, i64 %len
  store i8 0, ptr %z, align 1
  ret ptr %p
fail:
  ret ptr null
}

define internal i32 @staze_file_read_text(ptr %path, ptr %out) {
entry:
  %gotp = alloca i32, align 4
  %szp = alloca i64, align 8
  %cpath = call ptr @staze_text_to_cstr(ptr %path)
  %oompath = icmp eq ptr %cpath, null
  br i1 %oompath, label %oom, label %open
open:
  %h = call ptr @CreateFileA(ptr %cpath, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  call void @staze_heap_free_if_nonnull(ptr %cpath)
  %hi = ptrtoint ptr %h to i64
  %bad = icmp eq i64 %hi, -1
  br i1 %bad, label %io, label %size
size:
  %szok = call i32 @GetFileSizeEx(ptr %h, ptr %szp)
  %szfail = icmp eq i32 %szok, 0
  br i1 %szfail, label %closeio, label %allocdata
allocdata:
  %sz = load i64, ptr %szp, align 8
  %neg = icmp slt i64 %sz, 0
  br i1 %neg, label %closeio, label %allocgood
allocgood:
  %asz = add i64 %sz, 1
  %heap = call ptr @GetProcessHeap()
  %data = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %asz)
  %null = icmp eq ptr %data, null
  br i1 %null, label %closeoom, label %readloop
readloop:
  %off = phi i64 [ 0, %allocgood ], [ %next, %readok ]
  %rem = sub i64 %sz, %off
  %done = icmp eq i64 %rem, 0
  br i1 %done, label %readfinish, label %readchunk
readchunk:
  %big = icmp ugt i64 %rem, 4294967295
  %chunk64 = select i1 %big, i64 4294967295, i64 %rem
  %chunk = trunc i64 %chunk64 to i32
  %dst = getelementptr i8, ptr %data, i64 %off
  %rok = call i32 @ReadFile(ptr %h, ptr %dst, i32 %chunk, ptr %gotp, ptr null)
  %rfail = icmp eq i32 %rok, 0
  br i1 %rfail, label %readfail, label %readcount
readcount:
  %got = load i32, ptr %gotp, align 4
  %same = icmp eq i32 %got, %chunk
  br i1 %same, label %readok, label %readfail
readok:
  %got64 = zext i32 %got to i64
  %next = add i64 %off, %got64
  br label %readloop
readfail:
  call void @staze_heap_free_if_nonnull(ptr %data)
  %c0 = call i32 @CloseHandle(ptr %h)
  ret i32 1
readfinish:
  %nul = getelementptr i8, ptr %data, i64 %sz
  store i8 0, ptr %nul, align 1
  %c1 = call i32 @CloseHandle(ptr %h)
  store ptr %data, ptr %out, align 8
  %olp = getelementptr i8, ptr %out, i64 8
  store i64 %sz, ptr %olp, align 8
  ret i32 0
closeio:
  %c2 = call i32 @CloseHandle(ptr %h)
  ret i32 1
closeoom:
  %c3 = call i32 @CloseHandle(ptr %h)
  ret i32 2
io:
  ret i32 1
oom:
  ret i32 2
}

define internal i32 @staze_file_write_text(ptr %path, ptr %dataDesc) {
entry:
  %putp = alloca i32, align 4
  %cpath = call ptr @staze_text_to_cstr(ptr %path)
  %oom = icmp eq ptr %cpath, null
  br i1 %oom, label %oomret, label %open
open:
  %h = call ptr @CreateFileA(ptr %cpath, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  call void @staze_heap_free_if_nonnull(ptr %cpath)
  %hi = ptrtoint ptr %h to i64
  %bad = icmp eq i64 %hi, -1
  br i1 %bad, label %io, label %loop.pre
loop.pre:
  %data = load ptr, ptr %dataDesc, align 8
  %lp = getelementptr i8, ptr %dataDesc, i64 8
  %len = load i64, ptr %lp, align 8
  br label %loop
loop:
  %off = phi i64 [ 0, %loop.pre ], [ %next, %writeok ]
  %rem = sub i64 %len, %off
  %done = icmp eq i64 %rem, 0
  br i1 %done, label %finish, label %chunk
chunk:
  %big = icmp ugt i64 %rem, 4294967295
  %n64 = select i1 %big, i64 4294967295, i64 %rem
  %n = trunc i64 %n64 to i32
  %src = getelementptr i8, ptr %data, i64 %off
  %wok = call i32 @WriteFile(ptr %h, ptr %src, i32 %n, ptr %putp, ptr null)
  %wfail = icmp eq i32 %wok, 0
  br i1 %wfail, label %writefail, label %writecount
writecount:
  %put = load i32, ptr %putp, align 4
  %same = icmp eq i32 %put, %n
  br i1 %same, label %writeok, label %writefail
writeok:
  %put64 = zext i32 %put to i64
  %next = add i64 %off, %put64
  br label %loop
writefail:
  %c0 = call i32 @CloseHandle(ptr %h)
  ret i32 1
finish:
  %c1 = call i32 @CloseHandle(ptr %h)
  ret i32 0
io:
  ret i32 1
oomret:
  ret i32 2
}

define internal { i32, i32 } @staze_process_run(ptr %cmd) {
entry:
  %si = alloca [104 x i8], align 8
  %pi = alloca [24 x i8], align 8
  %ep = alloca i32, align 4
  %line = call ptr @staze_text_to_cstr(ptr %cmd)
  %oom = icmp eq ptr %line, null
  br i1 %oom, label %oomret, label %prepare
prepare:
  call void @llvm.memset.p0.i64(ptr %si, i8 0, i64 104, i1 false)
  call void @llvm.memset.p0.i64(ptr %pi, i8 0, i64 24, i1 false)
  store i32 104, ptr %si, align 4
  %ok = call i32 @CreateProcessA(ptr null, ptr %line, ptr null, ptr null, i32 0, i32 0, ptr null, ptr null, ptr %si, ptr %pi)
  call void @staze_heap_free_if_nonnull(ptr %line)
  %fail = icmp eq i32 %ok, 0
  br i1 %fail, label %procfail, label %wait
wait:
  %ph = load ptr, ptr %pi, align 8
  %thp = getelementptr i8, ptr %pi, i64 8
  %th = load ptr, ptr %thp, align 8
  %wr = call i32 @WaitForSingleObject(ptr %ph, i32 -1)
  %waitbad = icmp eq i32 %wr, -1
  br i1 %waitbad, label %closefail, label %exit
exit:
  %eok = call i32 @GetExitCodeProcess(ptr %ph, ptr %ep)
  %efail = icmp eq i32 %eok, 0
  br i1 %efail, label %closefail, label %success
success:
  %ec = load i32, ptr %ep, align 4
  %c0 = call i32 @CloseHandle(ptr %th)
  %c1 = call i32 @CloseHandle(ptr %ph)
  %a = insertvalue { i32, i32 } poison, i32 0, 0
  %r = insertvalue { i32, i32 } %a, i32 %ec, 1
  ret { i32, i32 } %r
closefail:
  %cf0 = call i32 @CloseHandle(ptr %th)
  %cf1 = call i32 @CloseHandle(ptr %ph)
  br label %procfail
procfail:
  %a1 = insertvalue { i32, i32 } poison, i32 1, 0
  %r1 = insertvalue { i32, i32 } %a1, i32 0, 1
  ret { i32, i32 } %r1
oomret:
  %a2 = insertvalue { i32, i32 } poison, i32 2, 0
  %r2 = insertvalue { i32, i32 } %a2, i32 0, 1
  ret { i32, i32 } %r2
}

)LLVM";
    o<<R"LLVM(
define internal void @staze_relation_lock(ptr %lock) {
entry:
  br label %spin
spin:
  %r = cmpxchg ptr %lock, i32 0, i32 1 acquire monotonic
  %ok = extractvalue { i32, i1 } %r, 1
  br i1 %ok, label %done, label %spin
done:
  ret void
}

define internal void @staze_relation_unlock(ptr %lock) {
entry:
  store atomic i32 0, ptr %lock release, align 4
  ret void
}

define internal i32 @staze_relation_link(ptr %lock, ptr %countp, ptr %used, ptr %srcs, ptr %tgts, i64 %cap, i64 %src, i64 %tgt, i1 %sourceMany, i1 %targetMany, i1 %uniquePair) {
entry:
  call void @staze_relation_lock(ptr %lock)
  %free = alloca i64, align 8
  store i64 -1, ptr %free, align 8
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %ni, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %finish, label %slot
slot:
  %up = getelementptr i8, ptr %used, i64 %i
  %u8 = load i8, ptr %up, align 1
  %isused = icmp ne i8 %u8, 0
  br i1 %isused, label %occupied, label %remember
remember:
  %oldfree = load i64, ptr %free, align 8
  %unset = icmp eq i64 %oldfree, -1
  br i1 %unset, label %setfree, label %next
setfree:
  store i64 %i, ptr %free, align 8
  br label %next
occupied:
  %sp = getelementptr i64, ptr %srcs, i64 %i
  %tp = getelementptr i64, ptr %tgts, i64 %i
  %s = load i64, ptr %sp, align 8
  %t = load i64, ptr %tp, align 8
  %se = icmp eq i64 %s, %src
  %te = icmp eq i64 %t, %tgt
  %pair = and i1 %se, %te
  %dupe = and i1 %pair, %uniquePair
  br i1 %dupe, label %exists, label %card.source
card.source:
  %srcsingle = xor i1 %sourceMany, true
  %srcconflict = and i1 %srcsingle, %se
  br i1 %srcconflict, label %violation, label %card.target
card.target:
  %tgtsingle = xor i1 %targetMany, true
  %tgtconflict = and i1 %tgtsingle, %te
  br i1 %tgtconflict, label %violation, label %next
next:
  %ni = add i64 %i, 1
  br label %scan
finish:
  %fi = load i64, ptr %free, align 8
  %none = icmp eq i64 %fi, -1
  br i1 %none, label %violation, label %insert
insert:
  %iup = getelementptr i8, ptr %used, i64 %fi
  %isp = getelementptr i64, ptr %srcs, i64 %fi
  %itp = getelementptr i64, ptr %tgts, i64 %fi
  store i64 %src, ptr %isp, align 8
  store i64 %tgt, ptr %itp, align 8
  store i8 1, ptr %iup, align 1
  %cnt = load i64, ptr %countp, align 8
  %ncnt = add i64 %cnt, 1
  store i64 %ncnt, ptr %countp, align 8
  call void @staze_relation_unlock(ptr %lock)
  ret i32 0
exists:
  call void @staze_relation_unlock(ptr %lock)
  ret i32 1
violation:
  call void @staze_relation_unlock(ptr %lock)
  ret i32 2
}

define internal i1 @staze_relation_unlink(ptr %lock, ptr %countp, ptr %used, ptr %srcs, ptr %tgts, i64 %cap, i64 %src, i64 %tgt) {
entry:
  call void @staze_relation_lock(ptr %lock)
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %ni, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %miss, label %slot
slot:
  %up = getelementptr i8, ptr %used, i64 %i
  %u8 = load i8, ptr %up, align 1
  %isused = icmp ne i8 %u8, 0
  br i1 %isused, label %check, label %next
check:
  %sp = getelementptr i64, ptr %srcs, i64 %i
  %tp = getelementptr i64, ptr %tgts, i64 %i
  %s = load i64, ptr %sp, align 8
  %t = load i64, ptr %tp, align 8
  %se = icmp eq i64 %s, %src
  %te = icmp eq i64 %t, %tgt
  %pair = and i1 %se, %te
  br i1 %pair, label %hit, label %next
hit:
  store i8 0, ptr %up, align 1
  %cnt = load i64, ptr %countp, align 8
  %ncnt = sub i64 %cnt, 1
  store i64 %ncnt, ptr %countp, align 8
  call void @staze_relation_unlock(ptr %lock)
  ret i1 true
next:
  %ni = add i64 %i, 1
  br label %scan
miss:
  call void @staze_relation_unlock(ptr %lock)
  ret i1 false
}

define internal i1 @staze_relation_contains(ptr %lock, ptr %countp, ptr %used, ptr %srcs, ptr %tgts, i64 %cap, i64 %src, i64 %tgt) {
entry:
  call void @staze_relation_lock(ptr %lock)
  br label %scan
scan:
  %i = phi i64 [ 0, %entry ], [ %ni, %next ]
  %end = icmp uge i64 %i, %cap
  br i1 %end, label %miss, label %slot
slot:
  %up = getelementptr i8, ptr %used, i64 %i
  %u8 = load i8, ptr %up, align 1
  %isused = icmp ne i8 %u8, 0
  br i1 %isused, label %check, label %next
check:
  %sp = getelementptr i64, ptr %srcs, i64 %i
  %tp = getelementptr i64, ptr %tgts, i64 %i
  %s = load i64, ptr %sp, align 8
  %t = load i64, ptr %tp, align 8
  %se = icmp eq i64 %s, %src
  %te = icmp eq i64 %t, %tgt
  %pair = and i1 %se, %te
  br i1 %pair, label %hit, label %next
hit:
  call void @staze_relation_unlock(ptr %lock)
  ret i1 true
next:
  %ni = add i64 %i, 1
  br label %scan
miss:
  call void @staze_relation_unlock(ptr %lock)
  ret i1 false
}

define internal i64 @staze_relation_count(ptr %lock, ptr %countp) {
entry:
  call void @staze_relation_lock(ptr %lock)
  %n = load i64, ptr %countp, align 8
  call void @staze_relation_unlock(ptr %lock)
  ret i64 %n
}
)LLVM";
    o<<R"LLVM(
define internal i1 @staze_tx_push(ptr %countp, ptr %kinds, ptr %rids, ptr %targets, ptr %aux0s, ptr %aux1s, ptr %payloads, i32 %cap, i32 %payloadBytes, i32 %kind, i32 %rid, ptr %target, i64 %aux0, i64 %aux1, ptr %payload, i32 %payloadLen) {
entry:
  %noop = icmp eq i32 %kind, 0
  br i1 %noop, label %ok, label %check
check:
  %count = load i32, ptr %countp, align 4
  %full = icmp uge i32 %count, %cap
  %payloadTooBig = icmp ugt i32 %payloadLen, %payloadBytes
  %bad = or i1 %full, %payloadTooBig
  br i1 %bad, label %fail, label %store
store:
  %idx = zext i32 %count to i64
  %kp = getelementptr i32, ptr %kinds, i64 %idx
  store i32 %kind, ptr %kp, align 4
  %rp = getelementptr i32, ptr %rids, i64 %idx
  store i32 %rid, ptr %rp, align 4
  %tp = getelementptr ptr, ptr %targets, i64 %idx
  store ptr %target, ptr %tp, align 8
  %a0p = getelementptr i64, ptr %aux0s, i64 %idx
  store i64 %aux0, ptr %a0p, align 8
  %a1p = getelementptr i64, ptr %aux1s, i64 %idx
  store i64 %aux1, ptr %a1p, align 8
  %pbs64 = zext i32 %payloadBytes to i64
  %poff = mul i64 %idx, %pbs64
  %pdst = getelementptr i8, ptr %payloads, i64 %poff
  %plen64 = zext i32 %payloadLen to i64
  %hasPayload = icmp ne i32 %payloadLen, 0
  br i1 %hasPayload, label %copy, label %finish
copy:
  call void @llvm.memcpy.p0.p0.i64(ptr %pdst, ptr %payload, i64 %plen64, i1 false)
  br label %finish
finish:
  %next = add i32 %count, 1
  store i32 %next, ptr %countp, align 4
  br label %ok
ok:
  ret i1 true
fail:
  ret i1 false
}
)LLVM";
    o<<"define internal void @staze_relation_undo(i32 %rid, i32 %kind, i64 %src, i64 %tgt) {\nentry:\n  switch i32 %rid, label %done [\n";
    for(const auto&r:p.concrete_relations)o<<"    i32 "<<r.id<<", label %rel."<<r.id<<"\n";
    o<<"  ]\n";
    for(const auto&r:p.concrete_relations){const auto n=safe_name(r.name);o<<"rel."<<r.id<<":\n  %isUnlink."<<r.id<<" = icmp eq i32 %kind, 2\n  br i1 %isUnlink."<<r.id<<", label %rel."<<r.id<<".unlink, label %rel."<<r.id<<".link\nrel."<<r.id<<".unlink:\n  %removed."<<r.id<<" = call i1 @staze_relation_unlink(ptr @.stz.rel."<<n<<".lock, ptr @.stz.rel."<<n<<".count, ptr @.stz.rel."<<n<<".used, ptr @.stz.rel."<<n<<".src, ptr @.stz.rel."<<n<<".tgt, i64 "<<r.capacity<<", i64 %src, i64 %tgt)\n  br label %done\nrel."<<r.id<<".link:\n  %linked."<<r.id<<" = call i32 @staze_relation_link(ptr @.stz.rel."<<n<<".lock, ptr @.stz.rel."<<n<<".count, ptr @.stz.rel."<<n<<".used, ptr @.stz.rel."<<n<<".src, ptr @.stz.rel."<<n<<".tgt, i64 "<<r.capacity<<", i64 %src, i64 %tgt, i1 "<<(r.source_many?"true":"false")<<", i1 "<<(r.target_many?"true":"false")<<", i1 "<<(r.unique_pair?"true":"false")<<")\n  br label %done\n";}
    o<<"done:\n  ret void\n}\n\n";
    o<<"define internal void @staze_shared_retain_if_nonnull(ptr %obj) {\nentry:\n  %isnull = icmp eq ptr %obj, null\n  br i1 %isnull, label %done, label %retain\nretain:\n  %base = getelementptr i8, ptr %obj, i64 -8\n  %old = atomicrmw add ptr %base, i64 1 monotonic\n  br label %done\ndone:\n  ret void\n}\n\n";
    o<<"define internal void @staze_shared_release_if_nonnull(ptr %obj) {\nentry:\n  %isnull = icmp eq ptr %obj, null\n  br i1 %isnull, label %done, label %release\nrelease:\n  %base = getelementptr i8, ptr %obj, i64 -8\n  %old = atomicrmw sub ptr %base, i64 1 acq_rel\n  %last = icmp eq i64 %old, 1\n  br i1 %last, label %free, label %done\nfree:\n  %heap = call ptr @GetProcessHeap()\n  %ok = call i32 @HeapFree(ptr %heap, i32 0, ptr %base)\n  br label %done\ndone:\n  ret void\n}\n\n";
    // Worker helpers are ordinary detached Staze functions extracted from task regions.
    // Their Win32 thunks only marshal the SIR-C 7 context ABI.
    for(const auto&fn:p.functions){
        const auto&cf=concrete_function(p,fn.name);
        for(const auto&t:cf.tasks){auto synth=make_task_synthetic(fn,cf,t);o<<FunctionEmitter(p,synth.fn,strings,&synth.concrete).emit();o<<emit_task_worker_thunk(fn,cf,t);}
    }
    for(const auto&fn:p.functions)o<<FunctionEmitter(p,fn,strings).emit();
    const SirFunction* main = nullptr;
    for (const auto& fn : p.functions) {
        if (fn.name == "main") { main = &fn; break; }
    }
    if (!main) throw CompileError({}, "LLVM backend: no main instruction in SIR-C");
    if (!main->parameters.empty()) throw CompileError({}, "LLVM backend: executable main must have no parameters");
    const std::string main_name = "main";
    const auto& cm = concrete_function(p, main_name);
    if (cm.result_storage != SirStorageClass::Register)
        throw CompileError({}, "LLVM backend: executable main must return an exact-One scalar/unit value");
    o<<"define void @staze_entry() {\nentry:\n";
    o<<"  %faultbuf = alloca ["<<cm.fault_payload_size<<" x i8], align "<<cm.fault_payload_align<<"\n";
    o<<"  %r = call { i32, i64 } @stz_main(ptr %faultbuf)\n  %status = extractvalue { i32, i64 } %r, 0\n  %payload = extractvalue { i32, i64 } %r, 1\n  %ok = icmp eq i32 %status, 0\n  br i1 %ok, label %success, label %failure\nsuccess:\n";
    if(main->result_type==SirType::Unit)o<<"  call void @ExitProcess(i32 0)\n";else o<<"  %exit = trunc i64 %payload to i32\n  call void @ExitProcess(i32 %exit)\n";
    o<<"  unreachable\nfailure:\n  call void @ExitProcess(i32 1)\n  unreachable\n}\n";return o.str();
}

} // namespace staze
