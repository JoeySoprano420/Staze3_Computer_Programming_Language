#include "staze/diagnostic.hpp"
#include "staze/definition.hpp"
#include "staze/lexer.hpp"
#include "staze/llvm_x64.hpp"
#include "staze/module_loader.hpp"
#include "staze/parser.hpp"
#include "staze/semantic.hpp"
#include "staze/sha256.hpp"
#include "staze/sir.hpp"
#include "staze/toolchain.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <atomic>
#include <cstdlib>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace fs = std::filesystem;

static std::string read_all(const fs::path& p) {
    std::error_code size_error;const auto bytes=fs::file_size(p,size_error);
    if(!size_error&&bytes>128ull*1024ull*1024ull)throw std::runtime_error("input exceeds the 128 MiB driver safety limit: "+p.string());
    std::ifstream f(p, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open input: " + p.string());
    std::ostringstream s;
    s << f.rdbuf();
    if(!f.eof()&&f.fail())throw std::runtime_error("failed while reading input: "+p.string());
    return s.str();
}

static void write_all(const fs::path& p, const std::string& s) {
    if (!p.parent_path().empty()) fs::create_directories(p.parent_path());
    static std::atomic<unsigned long long> sequence{0};
    const fs::path temporary=p.string()+".staze-tmp-"+std::to_string(++sequence);
    try {
        std::ofstream f(temporary, std::ios::binary|std::ios::trunc);
        if (!f) throw std::runtime_error("cannot create temporary output: " + temporary.string());
        f.write(s.data(),static_cast<std::streamsize>(s.size()));f.flush();
        if(!f)throw std::runtime_error("failed while writing temporary output: "+temporary.string());
        f.close();
#ifdef _WIN32
        if(!MoveFileExW(temporary.c_str(),p.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("cannot atomically publish output: "+p.string());
#else
        fs::rename(temporary,p);
#endif
    } catch (...) {std::error_code ec;fs::remove(temporary,ec);throw;}
}

static std::string json_escape(std::string_view value){std::string out;for(unsigned char c:value){switch(c){case '"':out+="\\\"";break;case '\\':out+="\\\\";break;case '\n':out+="\\n";break;case '\r':out+="\\r";break;case '\t':out+="\\t";break;default:if(c<0x20){const char* h="0123456789abcdef";out+="\\u00";out+=h[c>>4];out+=h[c&15];}else out+=static_cast<char>(c);}}return out;}

static std::optional<fs::path> locate_tool(const char* environment,const char* fallback){
    std::string name=fallback;if(const char* v=std::getenv(environment);v&&*v)name=v;
    fs::path direct=name;if(direct.has_parent_path())return fs::is_regular_file(direct)?std::optional<fs::path>(direct):std::nullopt;
    const char* raw=std::getenv("PATH");if(!raw)return std::nullopt;
#ifdef _WIN32
    constexpr char separator=';';const std::vector<std::string> suffixes{"",".exe",".cmd",".bat"};
#else
    constexpr char separator=':';const std::vector<std::string> suffixes{""};
#endif
    std::istringstream paths(raw);std::string dir;while(std::getline(paths,dir,separator))for(const auto& suffix:suffixes){auto candidate=fs::path(dir)/(name+suffix);if(fs::is_regular_file(candidate))return candidate;}
    return std::nullopt;
}

static int doctor(bool json){const auto clang=locate_tool("STAZE_CLANG","clang");const auto lld=locate_tool("STAZE_LLD_LINK","lld-link");const bool ready=clang&&lld;
    if(json)std::cout<<"{\"schema\":\"staze-doctor-1\",\"compiler\":\"1.0.5\",\"target\":\"x86_64-pc-windows-msvc\",\"clang\":{\"found\":"<<(clang?"true":"false")<<",\"path\":\""<<json_escape(clang?clang->string():"")<<"\"},\"lld_link\":{\"found\":"<<(lld?"true":"false")<<",\"path\":\""<<json_escape(lld?lld->string():"")<<"\"},\"ready\":"<<(ready?"true":"false")<<"}\n";
    else {std::cout<<"Staze 1.0.5 production toolchain check\n  clang    : "<<(clang?clang->string():"NOT FOUND")<<"\n  lld-link : "<<(lld?lld->string():"NOT FOUND")<<"\n  target   : x86_64-pc-windows-msvc\n  status   : "<<(ready?"READY":"NOT READY")<<"\n";if(!ready)std::cout<<"Set STAZE_CLANG and STAZE_LLD_LINK to explicit executable paths.\n";}
    return ready?0:1;}

static std::string manifest_path(const fs::path& source) {
    std::error_code ec;
    const auto absolute_source = fs::weakly_canonical(source, ec);
    if (ec) return source.filename().generic_string();
    ec.clear();
    const auto absolute_base = fs::weakly_canonical(fs::current_path(), ec);
    if (ec) return source.filename().generic_string();
    const auto relative = absolute_source.lexically_relative(absolute_base);
    if (relative.empty() || *relative.begin() == "..")
        return source.filename().generic_string();
    return relative.generic_string();
}

static void usage() {
    std::cout <<
R"(Staze C++23 Compiler 1.0.5 — Dynamic Transactions, Native Relations, Workers & Systems Runtime

Stable commands:
  stazec build <root.stz3> [options]
  stazec check <root.stz3> [options]
  stazec inspect <root.stz3|file.sirs|file.sirc> [options]
  stazec version
  stazec version --json
  stazec doctor [--json]
  stazec definitions check <module.sdef|pack-directory>
  stazec definitions inspect <module.sdef|pack-directory>
  stazec definitions lock <module.sdef|pack-directory> <pack.lock>
  stazec definitions verify <module.sdef|pack-directory> <pack.lock>

Source compilation:
  stazec <root.stz3> [additional.stz3 ...] [-o program.exe] [--check]
                     [--emit-sir-s file.sirs]
                     [--emit-sir-c file.sirc]
                     [--emit-sir file.sir]
                     [--emit-llvm file.ll]
                     [--emit-deps graph.txt]
                     [--emit-build-manifest file.txt]
                     [--verify-build-manifest file.txt]
                     [--definition-pack directory]
                     [--module-path directory]
                     [--diagnostic-format text|json]
                     [--keep-intermediates]

Detached semantic compilation from canonical SIR-S 6.x:
  stazec --from-sir-s <file.sirs> [-o program.exe] [--check]
                                  [--emit-sir-c file.sirc]
                                  [--emit-llvm file.ll]
                                  [--keep-intermediates]

Backend-only compilation from canonical SIR-C 7.0:
  stazec --from-sir-c <file.sirc> [-o program.exe] [--check]
                                  [--emit-llvm file.ll]
                                  [--keep-intermediates]

Canonical compilation path:
  .stz3 / module graph
       -> AST -> SSL -> DLE -> SIR-S 6.x
       -> serialize -> deserialize -> independent SIR-S verifier
       -> SIR-C 7.0 -> serialize -> deserialize -> independent SIR-C verifier
       -> LLVM IR -> x86-64 COFF -> PE32+ .exe

Compiler 1.0.5 reference profile includes:
  * strict SDEF 1.1 definition packs with dependency, trust-boundary, canonical
    hashing, inspection, and reproducible-manifest verification;
  * bounded dynamic transaction occurrence logs, loop-safe rollback, and nested savepoints;
  * native lock-protected relation tables with uniqueness/cardinality/capacity checks;
  * real Win32 worker execution with CreateThread/WaitForSingleObject, task joins,
    typed results, deterministic fault aggregation, and mutable/shared/send capture checks;
  * dynamic text, byte slices, bounded scalar maps, file I/O, process execution,
    lifetime-tracked heap bytes, startup/runtime glue, modules/imports, multi-file
    compilation, and dependency-graph emission.

SIR-S remains semantic meaning. SIR-C remains the concrete target proof. LLVM
consumes only a freshly deserialized, independently verified SIR-C graph and does
not receive source, AST, SSL, DLE, or target-neutral compiler state.

Windows native programs are standalone /NODEFAULTLIB PE32+ images. Runtime glue
uses explicit KERNEL32 imports; no C++ exceptions, STL containers, GC, CRT startup,
or hidden C++ ownership model defines Staze semantics.

Environment overrides:
  STAZE_CLANG      path/name of clang
  STAZE_LLD_LINK   path/name of lld-link
)";
}


int main(int argc, char** argv) {
    if (argc < 2) { usage(); return 2; }
    if ((argc == 2 || argc == 3) && (std::string(argv[1]) == "version" || std::string(argv[1]) == "--version")) {
        if(argc==3){if(std::string(argv[2])!="--json"){std::cerr<<"stazec: error: version accepts only --json\n";return 2;}std::cout<<"{\"compiler\":\"stazec\",\"version\":\"1.0.5\",\"language\":\"staze-3\",\"sir_s\":\"6.x\",\"sir_c\":\"7.0\",\"sabi\":\"1\",\"sdef\":\"1.1\"}\n";return 0;}
        std::cout << "stazec 1.0.5\nSIR-S 6.x\nSIR-C 7.0\nSABI 1\nSDEF 1.1\n";
        return 0;
    }
    if(std::string(argv[1])=="doctor"){if(argc>3||(argc==3&&std::string(argv[2])!="--json")){std::cerr<<"stazec: error: usage: stazec doctor [--json]\n";return 2;}return doctor(argc==3);}
    fs::path input;
    bool json_diagnostics=false;
    for(int i=1;i<argc;++i){const std::string a=argv[i];if(a=="--diagnostic-format=json")json_diagnostics=true;else if(a=="--diagnostic-format"&&i+1<argc&&std::string(argv[i+1])=="json")json_diagnostics=true;}
    try {
        if (std::string(argv[1]) == "definitions") {
            if (argc < 4 || argc > 5) throw std::runtime_error("usage: stazec definitions <check|inspect|lock|verify> <module.sdef|pack-directory> [pack.lock]");
            const std::string action=argv[2];
            if(action!="check"&&action!="inspect"&&action!="lock"&&action!="verify")throw std::runtime_error("definitions action must be check, inspect, lock, or verify");
            if((action=="lock"||action=="verify")!=(argc==5))throw std::runtime_error("definitions lock/verify require a lockfile path; check/inspect do not accept one");
            const auto pack=staze::load_definition_pack(argv[3]);
            if(action=="inspect")std::cout<<staze::inspect_definition_pack(pack);
            else if(action=="lock"){write_all(argv[4],pack.canonical);std::cout<<"SDEF lock written: "<<argv[4]<<"\n  pack sha256  : "<<pack.sha256<<"\n";}
            else if(action=="verify"){if(read_all(argv[4])!=pack.canonical)throw std::runtime_error("SDEF lock verification failed: "+std::string(argv[4]));std::cout<<"SDEF lock verification passed: "<<argv[4]<<"\n  pack sha256  : "<<pack.sha256<<"\n";}
            else std::cout<<"SDEF 1.1 definition check passed: "<<argv[3]<<"\n  modules      : "<<pack.modules.size()<<"\n  pack sha256  : "<<pack.sha256<<"\n";
            return 0;
        }
        fs::path output;
        fs::path sirs_out;
        fs::path sirc_out;
        fs::path combined_sir_out;
        fs::path llvm_out;
        fs::path deps_out;
        fs::path build_manifest_out;
        fs::path verify_build_manifest;
        fs::path definition_pack_path;
        std::vector<fs::path> source_inputs;
        std::vector<fs::path> resolved_inputs;
        std::vector<fs::path> module_paths;
        bool check_only = false;
        bool keep = false;
        bool from_sirc = false;
        bool from_sirs = false;
        bool inspect_mode = false;

        int first_argument = 1;
        const std::string command = argv[1];
        if (command == "build" || command == "check" || command == "inspect") {
            first_argument = 2;
            check_only = command != "build";
            inspect_mode = command == "inspect";
        }

        for (int i = first_argument; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "-h" || a == "--help") { usage(); return 0; }
            if (a == "-o") { if (++i >= argc) throw std::runtime_error("-o requires a path"); output = argv[i]; continue; }
            if (a == "--emit-sir-s") { if (++i >= argc) throw std::runtime_error("--emit-sir-s requires a path"); sirs_out = argv[i]; continue; }
            if (a == "--emit-sir-c") { if (++i >= argc) throw std::runtime_error("--emit-sir-c requires a path"); sirc_out = argv[i]; continue; }
            if (a == "--emit-sir") { if (++i >= argc) throw std::runtime_error("--emit-sir requires a path"); combined_sir_out = argv[i]; continue; }
            if (a == "--emit-llvm") { if (++i >= argc) throw std::runtime_error("--emit-llvm requires a path"); llvm_out = argv[i]; continue; }
            if (a == "--emit-deps") { if (++i >= argc) throw std::runtime_error("--emit-deps requires a path"); deps_out = argv[i]; continue; }
            if (a == "--emit-build-manifest") { if (++i >= argc) throw std::runtime_error("--emit-build-manifest requires a path"); build_manifest_out = argv[i]; continue; }
            if (a == "--verify-build-manifest") { if (++i >= argc) throw std::runtime_error("--verify-build-manifest requires a path"); verify_build_manifest = argv[i]; continue; }
            if (a == "--definition-pack") { if (++i >= argc) throw std::runtime_error("--definition-pack requires a path"); definition_pack_path = argv[i]; continue; }
            if (a == "--module-path") { if (++i >= argc) throw std::runtime_error("--module-path requires a directory"); module_paths.emplace_back(argv[i]); continue; }
            if (a == "--diagnostic-format" || a.rfind("--diagnostic-format=",0)==0) { std::string value; if(a=="--diagnostic-format"){if(++i>=argc)throw std::runtime_error("--diagnostic-format requires text or json");value=argv[i];}else value=a.substr(20);if(value!="text"&&value!="json")throw std::runtime_error("--diagnostic-format requires text or json");json_diagnostics=value=="json";continue; }
            if (a == "--check") { check_only = true; continue; }
            if (a == "--keep-intermediates") { keep = true; continue; }
            if (a == "--from-sir-s") {
                from_sirs = true;
                if (++i >= argc) throw std::runtime_error("--from-sir-s requires a path");
                if (!input.empty()) throw std::runtime_error("only one input artifact is accepted");
                input = argv[i];
                continue;
            }
            if (a == "--from-sir-c") {
                from_sirc = true;
                if (++i >= argc) throw std::runtime_error("--from-sir-c requires a path");
                if (!input.empty()) throw std::runtime_error("only one input artifact is accepted");
                input = argv[i];
                continue;
            }
            if (!a.empty() && a[0] == '-') throw std::runtime_error("unknown option: " + a);
            if (from_sirs || from_sirc) { if (!input.empty()) throw std::runtime_error("detached compilation accepts one artifact"); input = a; }
            else { if (input.empty()) input = a; source_inputs.emplace_back(a); }
        }

        if (input.empty()) throw std::runtime_error("missing .stz3, .sirs, or .sirc input");
        if (from_sirs && from_sirc) throw std::runtime_error("choose only one detached input mode");
        if (!from_sirs && !from_sirc && input.extension() == ".sirs") from_sirs = true;
        if (!from_sirs && !from_sirc && input.extension() == ".sirc") from_sirc = true;
        if (from_sirc && !sirs_out.empty()) throw std::runtime_error("--emit-sir-s is unavailable when SIR-S was intentionally skipped");
        if ((from_sirs || from_sirc) && !deps_out.empty()) throw std::runtime_error("--emit-deps is available only for source/module compilation");
        if (output.empty()) { output = input.filename(); output.replace_extension(".exe"); }

        staze::SirVerifier verifier;
        std::optional<staze::DefinitionPack> definition_pack;
        if(!definition_pack_path.empty())definition_pack=staze::load_definition_pack(definition_pack_path);
        staze::SirCProgram backend_sir_c;
        std::string canonical_sirs;
        std::string canonical_sirc;

        if (from_sirc) {
            // Backend-only process path. No Lexer, Parser, Program, SSLProgram,
            // DeductiveLowerer, or SIR-S object is required.
            backend_sir_c = staze::deserialize_sir_c(read_all(input));
            verifier.verify(backend_sir_c);
            canonical_sirc = staze::serialize_sir_c(backend_sir_c);
        } else {
            staze::SirSProgram detached_sir_s;
            if (from_sirs) {
                // Detached target-neutral path. Concretization starts from bytes;
                // source, tokens, AST, SSL, and DLE never exist in this process.
                detached_sir_s = staze::deserialize_sir_s(read_all(input));
                verifier.verify(detached_sir_s);
                canonical_sirs = staze::serialize_sir_s(detached_sir_s);
            } else {
                // FRONTEND LIFETIME ZONE. These objects deliberately die before
                // target concretization and LLVM emission.
                if (source_inputs.empty()) source_inputs.push_back(input);
                staze::ModuleLoader module_loader;
                auto loaded = module_loader.load(source_inputs, module_paths);
                for (const auto& node : loaded.graph) resolved_inputs.push_back(node.path);
                if (!deps_out.empty()) write_all(deps_out, staze::ModuleLoader::graph_text(loaded.graph));
                auto ast = std::move(loaded.program);
                staze::SemanticAnalyzer analyzer;
                auto ssl = analyzer.analyze(ast);
                staze::DeductiveLowerer dle;
                auto frontend_sir_s = dle.lower(ast, ssl);
                verifier.verify(frontend_sir_s);

                // The serialization boundary is architectural, not decorative.
                // The retained SIR-S is reconstructed from bytes, so it cannot
                // contain a hidden AST/SSL pointer even by accident.
                canonical_sirs = staze::serialize_sir_s(frontend_sir_s);
                detached_sir_s = staze::deserialize_sir_s(canonical_sirs);
                if (staze::serialize_sir_s(detached_sir_s) != canonical_sirs)
                    throw std::runtime_error("internal: SIR-S canonical serialization is not byte-stable after round-trip");
            }

            // At this line source/tokens/AST/SSL are absent regardless of whether
            // the input was source or a detached SIR-S artifact.
            verifier.verify(detached_sir_s);
            staze::TargetConcretizer concretizer;
            auto concrete = concretizer.concretize(detached_sir_s,
                                                   "windows-x86_64-bootstrap",
                                                   "x86_64-pc-windows-msvc");
            verifier.verify(concrete);

            // Repeat the detachment at the target boundary. LLVM consumes only
            // this freshly deserialized standalone SIR-C graph.
            canonical_sirc = staze::serialize_sir_c(concrete);
            backend_sir_c = staze::deserialize_sir_c(canonical_sirc);
            verifier.verify(backend_sir_c);
            if (staze::serialize_sir_c(backend_sir_c) != canonical_sirc)
                throw std::runtime_error("internal: SIR-C canonical serialization is not byte-stable after round-trip");
        }

        if (!sirs_out.empty()) write_all(sirs_out, canonical_sirs);
        if (!sirc_out.empty()) write_all(sirc_out, canonical_sirc);
        if (!build_manifest_out.empty() || !verify_build_manifest.empty()) {
            std::ostringstream manifest;
            manifest << "STAZE-BUILD-MANIFEST 1\n"
                     << "compiler 1.0.5\n"
                     << "language staze-3\n"
                     << "sabi 1\n"
                     << "sdef 1.1\n"
                     << "sir-s 6.x " << (canonical_sirs.empty() ? "absent" : staze::sha256_hex(canonical_sirs)) << "\n"
                     << "sir-c 7.0 " << staze::sha256_hex(canonical_sirc) << "\n"
                     << "target " << backend_sir_c.target_triple << "\n"
                     << "profile " << backend_sir_c.target_profile << "\n";
            if(definition_pack){
                manifest<<"definition-pack "<<definition_pack->sha256<<"\n";
                for(const auto& module:definition_pack->modules)manifest<<"definition "<<module.name<<' '<<module.version<<' '<<module.sha256<<"\n";
            }
            if (resolved_inputs.empty() && !from_sirs && !from_sirc) resolved_inputs = source_inputs;
            if ((from_sirs || from_sirc) && resolved_inputs.empty()) resolved_inputs.push_back(input);
            for (const auto& source : resolved_inputs)
                manifest << "input " << manifest_path(source) << ' ' << staze::sha256_hex(read_all(source)) << "\n";
            const auto manifest_text = manifest.str();
            if (!verify_build_manifest.empty() && read_all(verify_build_manifest) != manifest_text)
                throw std::runtime_error("reproducibility verification failed: build manifest differs from " + verify_build_manifest.string());
            if (!build_manifest_out.empty()) write_all(build_manifest_out, manifest_text);
        }
        if (!combined_sir_out.empty()) {
            if (from_sirc) write_all(combined_sir_out, canonical_sirc);
            else write_all(combined_sir_out, canonical_sirs + "\n" + canonical_sirc);
        }

        if (check_only) {
            std::cout << (inspect_mode ? "STZ-3 inspection passed: " : "STZ-3 detached-SIR check passed: ") << input.string() << "\n";
            std::cout << "  module            : " << backend_sir_c.module_name << "\n";
            std::cout << "  functions         : " << backend_sir_c.functions.size() << "\n";
            std::cout << "  semantic facts    : " << backend_sir_c.semantic_facts.size() << "\n";
            std::size_t blocks = 0, ops = 0, phis = 0, fault_edges = 0, effects = 0;
            std::size_t regions = 0, provenances = 0, values = 0, effect_tokens = 0;
            std::size_t one = 0, zero_or_one = 0, many = 0, fault_payload_fields = 0;
            for (const auto& f : backend_sir_c.faults) fault_payload_fields += f.payload.size();
            for (const auto& fn : backend_sir_c.functions) {
                regions += fn.regions.size(); provenances += fn.provenances.size(); values += fn.values.size();
                for (const auto& v : fn.values) {
                    if (v.cardinality == staze::SirCardinality::One) ++one;
                    else if (v.cardinality == staze::SirCardinality::ZeroOrOne) ++zero_or_one;
                    else ++many;
                }
                for (const auto& b : fn.blocks) {
                    ++blocks; ++effect_tokens;
                    for (const auto& op : b.instructions) {
                        ++ops;
                        if (op.opcode == staze::SirOpcode::Phi) ++phis;
                        fault_edges += op.fault_edges.size();
                        effects += op.effects.size();
                        if (op.effect_out) ++effect_tokens;
                    }
                }
            }
            std::cout << "  datasets/choices  : " << backend_sir_c.datasets.size() << "/" << backend_sir_c.choices.size() << "\n";
            std::cout << "  relations/pools   : " << backend_sir_c.relations.size() << "/" << backend_sir_c.pools.size() << "\n";
            std::cout << "  fault payload fields: " << fault_payload_fields << "\n";
            std::cout << "  CFG blocks        : " << blocks << "\n";
            std::cout << "  SSA operations    : " << ops << "\n";
            std::cout << "  phi operations    : " << phis << "\n";
            std::cout << "  value semantics   : " << values << " (One=" << one << ", ZeroOrOne=" << zero_or_one << ", Many=" << many << ")\n";
            std::cout << "  lifetime regions  : " << regions << "\n";
            std::cout << "  provenances       : " << provenances << "\n";
            std::cout << "  explicit fault edges: " << fault_edges << "\n";
            std::cout << "  effect annotations: " << effects << "\n";
            std::cout << "  effect SSA tokens : " << effect_tokens << "\n";
            std::size_t reg=0, stack=0, caller=0, arena=0, heap=0, alias=0, scalar_replaced=0;
            for (const auto& cf : backend_sir_c.concrete_functions) {
                for (const auto& cv : cf.values) {
                    switch (cv.storage) {
                        case staze::SirStorageClass::Register: ++reg; break;
                        case staze::SirStorageClass::Stack: ++stack; break;
                        case staze::SirStorageClass::Caller: ++caller; break;
                        case staze::SirStorageClass::PoolArena: ++arena; break;
                        case staze::SirStorageClass::Heap: ++heap; break;
                        case staze::SirStorageClass::Alias: ++alias; break;
                        case staze::SirStorageClass::Static: break;
                    }
                    if (cv.scalar_replaced) ++scalar_replaced;
                }
            }
            std::cout << "  concrete storage  : register=" << reg << ", stack=" << stack
                      << ", caller=" << caller << ", pool-arena=" << arena
                      << ", heap=" << heap << ", alias=" << alias << "\n";
            std::cout << "  scalar replacements: " << scalar_replaced << "\n";
            std::cout << "  SIR-C format      : " << backend_sir_c.format_major << '.' << backend_sir_c.format_minor << "\n";
            std::cout << "  frontend retained : NO\n";
            return 0;
        }

        staze::LlvmWindowsX64Emitter emitter;
        const auto llvm = emitter.emit(backend_sir_c);
        fs::path build_ir = llvm_out.empty()
            ? output.parent_path() / (output.stem().string() + ".staze.ll")
            : llvm_out;
        write_all(build_ir, llvm);

        staze::WindowsPeToolchain tools;
        tools.build(build_ir, output, {keep});
        if (llvm_out.empty() && !keep) { std::error_code ec; fs::remove(build_ir, ec); }

        std::cout << "Built Windows x86-64 Staze executable from standalone SIR-C\n";
        std::cout << "  input  : " << input.string() << "\n";
        std::cout << "  target : " << backend_sir_c.target_triple << "\n";
        std::cout << "  object : " << backend_sir_c.object_format << "\n";
        std::cout << "  output : " << output.string() << "\n";
        if (!sirs_out.empty()) std::cout << "  SIR-S  : " << sirs_out.string() << "\n";
        if (!sirc_out.empty()) std::cout << "  SIR-C  : " << sirc_out.string() << "\n";
        if (!combined_sir_out.empty()) std::cout << "  SIR    : " << combined_sir_out.string() << "\n";
        if (!llvm_out.empty()) std::cout << "  LLVM IR: " << llvm_out.string() << "\n";
        return 0;
    } catch (const staze::CompileError& e) {
        const auto& w = e.where();
        if(json_diagnostics){std::cerr<<"{\"schema\":\"staze-diagnostic-1\",\"severity\":\"error\",\"kind\":\"compile\",\"file\":\""<<json_escape(input.string())<<"\",\"line\":"<<w.line<<",\"column\":"<<w.column<<",\"message\":\""<<json_escape(e.what())<<"\"}\n";return 1;}
        if (!input.empty()) std::cerr << input.string() << ':' << w.line << ':' << w.column << ": error: ";
        else std::cerr << "stazec: error: ";
        std::cerr << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        if(json_diagnostics){std::cerr<<"{\"schema\":\"staze-diagnostic-1\",\"severity\":\"error\",\"kind\":\"driver\",\"file\":\""<<json_escape(input.string())<<"\",\"line\":0,\"column\":0,\"message\":\""<<json_escape(e.what())<<"\"}\n";return 1;}
        std::cerr << "stazec: error: " << e.what() << "\n";
        return 1;
    }
}
