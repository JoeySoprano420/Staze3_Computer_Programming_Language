#include "staze/definition.hpp"
#include "staze/sha256.hpp"

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>

namespace staze {
namespace {
void validate_utf8(std::string_view text, const std::filesystem::path& source) {
    for (std::size_t i=0;i<text.size();) {
        const auto c=static_cast<unsigned char>(text[i]);
        if(c==0 || (c<0x20 && c!='\n' && c!='\r' && c!='\t'))
            throw std::runtime_error("SDEF contains a forbidden control byte: "+source.string());
        if(c<0x80){++i;continue;}
        std::size_t n=0;std::uint32_t value=0;
        if((c&0xe0)==0xc0){n=2;value=c&0x1f;if(value<2)throw std::runtime_error("SDEF contains overlong UTF-8: "+source.string());}
        else if((c&0xf0)==0xe0){n=3;value=c&0x0f;}
        else if((c&0xf8)==0xf0){n=4;value=c&0x07;if(value>4)throw std::runtime_error("SDEF contains invalid UTF-8: "+source.string());}
        else throw std::runtime_error("SDEF contains invalid UTF-8: "+source.string());
        if(i+n>text.size())throw std::runtime_error("SDEF contains truncated UTF-8: "+source.string());
        for(std::size_t j=1;j<n;++j){const auto d=static_cast<unsigned char>(text[i+j]);if((d&0xc0)!=0x80)throw std::runtime_error("SDEF contains invalid UTF-8 continuation: "+source.string());value=(value<<6)|(d&0x3f);}
        if((n==3&&value<0x800)||(n==4&&value<0x10000)||value>0x10ffff||(value>=0xd800&&value<=0xdfff))throw std::runtime_error("SDEF contains non-canonical UTF-8: "+source.string());
        i+=n;
    }
}
std::string trim(std::string s) {
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) s.erase(s.begin());
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
    return s;
}
std::string unquote(const std::string& s, std::size_t line) {
    if (s.size() < 2 || s.front() != '"' || s.back() != '"')
        throw std::runtime_error("SDEF line " + std::to_string(line) + ": value must be a quoted UTF-8 string");
    std::string out;
    for (std::size_t i=1; i+1<s.size(); ++i) {
        if (s[i] == '\\') {
            if (++i + 1 >= s.size()) throw std::runtime_error("SDEF line " + std::to_string(line) + ": invalid escape");
            if (s[i] == 'n') out += '\n';
            else if (s[i] == 't') out += '\t';
            else if (s[i] == '"' || s[i] == '\\') out += s[i];
            else throw std::runtime_error("SDEF line " + std::to_string(line) + ": unsupported escape");
        } else out += s[i];
    }
    return out;
}
std::string quote(const std::string& s) {
    std::string out="\"";
    for (char c:s) { if(c=='\\'||c=='"') out+='\\'; if(c=='\n') out+="\\n"; else if(c=='\t') out+="\\t"; else out+=c; }
    return out+'"';
}
bool identifier(const std::string& s) {
    if (s.empty()) return false;
    for (char c:s) if (!(std::isalnum(static_cast<unsigned char>(c)) || c=='.' || c=='_' || c=='-')) return false;
    return true;
}
void safe_value(const std::string& value, std::size_t line) {
    std::string lower=value; std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    static const char* banned[]={"native_callback","dlopen","loadlibrary","machine_code","shell_exec","process_exec","network_access","filesystem_write","environment_read","absolute_path"};
    for(const auto* word:banned) if(lower.find(word)!=std::string::npos)
        throw std::runtime_error("SDEF line " + std::to_string(line) + ": forbidden executable capability '" + word + "'");
    if(value.size()>4096) throw std::runtime_error("SDEF line " + std::to_string(line) + ": record exceeds 4096 bytes");
}
std::string read_file(const std::filesystem::path& p) {
    std::ifstream f(p,std::ios::binary); if(!f) throw std::runtime_error("cannot open definition: "+p.string());
    std::ostringstream s;s<<f.rdbuf();return s.str();
}
void emit_list(std::ostringstream& out,const char* key,const std::vector<std::string>& xs){for(const auto& x:xs)out<<key<<' '<<quote(x)<<'\n';}
}

DefinitionModule parse_definition(std::string_view text, const std::filesystem::path& source) {
    if(text.size()>1024*1024) throw std::runtime_error("SDEF module exceeds 1 MiB: "+source.string());
    validate_utf8(text,source);
    DefinitionModule m;m.source=source;std::istringstream in{std::string(text)};std::string line;std::size_t number=0;bool header=false;
    std::set<std::pair<std::string,std::string>> unique;
    while(std::getline(in,line)){
        ++number;if(!line.empty()&&line.back()=='\r')line.pop_back();line=trim(line);
        if(line.empty()||line[0]=='#')continue;
        if(!header){if(line!="SDEF 1.1")throw std::runtime_error("SDEF line "+std::to_string(number)+": expected 'SDEF 1.1'");header=true;continue;}
        const auto space=line.find(' ');if(space==std::string::npos)throw std::runtime_error("SDEF line "+std::to_string(number)+": expected key and quoted value");
        const auto key=line.substr(0,space);const auto value=unquote(trim(line.substr(space+1)),number);safe_value(value,number);
        if(!unique.emplace(key,value).second)throw std::runtime_error("SDEF line "+std::to_string(number)+": duplicate record");
        if(key=="module")m.name=value;else if(key=="version")m.version=value;else if(key=="description")m.description=value;
        else if(key=="requires")m.dependencies.push_back(value);else if(key=="syntax")m.syntax.push_back(value);else if(key=="fact")m.facts.push_back(value);
        else if(key=="constraint")m.constraints.push_back(value);else if(key=="lowering")m.lowerings.push_back(value);else if(key=="target")m.targets.push_back(value);
        else if(key=="capability")m.capabilities.push_back(value);else if(key=="diagnostic")m.diagnostics.push_back(value);
        else throw std::runtime_error("SDEF line "+std::to_string(number)+": unknown record '"+key+"'");
    }
    if(!header)throw std::runtime_error("empty SDEF module: "+source.string());
    if(!identifier(m.name))throw std::runtime_error("SDEF module has missing or invalid module identity: "+source.string());
    if(!identifier(m.version))throw std::runtime_error("SDEF module has missing or invalid version: "+source.string());
    if(m.description.empty())throw std::runtime_error("SDEF module requires a description: "+m.name);
    std::sort(m.dependencies.begin(),m.dependencies.end());
    std::ostringstream out;out<<"SDEF 1.1\nmodule "<<quote(m.name)<<"\nversion "<<quote(m.version)<<"\ndescription "<<quote(m.description)<<"\n";
    emit_list(out,"requires",m.dependencies);emit_list(out,"syntax",m.syntax);emit_list(out,"fact",m.facts);emit_list(out,"constraint",m.constraints);emit_list(out,"lowering",m.lowerings);emit_list(out,"target",m.targets);emit_list(out,"capability",m.capabilities);emit_list(out,"diagnostic",m.diagnostics);
    m.canonical=out.str();m.sha256=sha256_hex(m.canonical);return m;
}

DefinitionPack load_definition_pack(const std::filesystem::path& path) {
    std::vector<std::filesystem::path> files;
    if(std::filesystem::is_directory(path)){for(const auto& e:std::filesystem::directory_iterator(path))if(e.path().extension()==".sdef"){
        if(e.is_symlink()||!e.is_regular_file())throw std::runtime_error("definition pack entry must be a regular non-symlink file: "+e.path().string());
        files.push_back(e.path());
    }} else {if(std::filesystem::is_symlink(path)||!std::filesystem::is_regular_file(path))throw std::runtime_error("definition path must be a regular non-symlink file: "+path.string());files.push_back(path);}
    if(files.size()>256)throw std::runtime_error("definition pack exceeds the 256-module safety limit: "+path.string());
    std::sort(files.begin(),files.end());if(files.empty())throw std::runtime_error("definition pack contains no .sdef modules: "+path.string());
    DefinitionPack pack;std::map<std::string,std::size_t> names;
    for(const auto& f:files){auto m=parse_definition(read_file(f),f);if(!names.emplace(m.name,pack.modules.size()).second)throw std::runtime_error("duplicate SDEF module identity: "+m.name);pack.modules.push_back(std::move(m));}
    for(const auto& m:pack.modules)for(const auto& dep:m.dependencies)if(!names.contains(dep))throw std::runtime_error("SDEF module "+m.name+" requires missing module "+dep);
    std::map<std::string,int> state;
    auto visit=[&](auto&& self,const std::string& name)->void{if(state[name]==1)throw std::runtime_error("SDEF dependency cycle at "+name);if(state[name]==2)return;state[name]=1;for(const auto& d:pack.modules[names.at(name)].dependencies)self(self,d);state[name]=2;};
    for(const auto& [name,index]:names){(void)index;visit(visit,name);}
    std::sort(pack.modules.begin(),pack.modules.end(),[](const auto&a,const auto&b){return a.name<b.name;});
    std::ostringstream canonical;canonical<<"SDEF-PACK 1.1\n";for(const auto& m:pack.modules)canonical<<"module "<<m.name<<' '<<m.version<<' '<<m.sha256<<'\n';
    pack.canonical=canonical.str();pack.sha256=sha256_hex(pack.canonical);return pack;
}

std::string inspect_definition_pack(const DefinitionPack& pack){
    std::ostringstream out;out<<"SDEF 1.1 definition pack\n  modules      : "<<pack.modules.size()<<"\n  pack sha256  : "<<pack.sha256<<"\n";
    for(const auto&m:pack.modules)out<<"  "<<m.name<<" @ "<<m.version<<"  facts="<<m.facts.size()<<" constraints="<<m.constraints.size()<<" lowerings="<<m.lowerings.size()<<"  "<<m.sha256<<"\n";
    return out.str();
}
} // namespace staze
