@echo off
setlocal EnableExtensions

for %%I in ("%~dp0.") do set "STAZE_ROOT=%%~fI"
set "STAZE_EXE=%STAZE_ROOT%\release\stazec.exe"
set "STAZE_STAGE=%TEMP%\StazeCpp23Compiler_1.0.5-package"
set "STAZE_STAGE_ROOT=%STAZE_STAGE%\StazeCpp23Compiler_1.0.5"
set "STAZE_ZIP=%STAZE_ROOT%\Staze-1.0.5-Windows-x64.zip"

call "%STAZE_ROOT%\build_windows_x64.bat"
if errorlevel 1 exit /b 1

if not exist "%STAZE_EXE%" (
    echo ERROR: Genuine release\stazec.exe is missing. No ZIP was created.
    exit /b 1
)

"%STAZE_EXE%" version --json | findstr /C:"1.0.5" >nul
if errorlevel 1 (
    echo ERROR: release\stazec.exe is not Compiler 1.0.5. No ZIP was created.
    exit /b 1
)

powershell -NoProfile -Command "Remove-Item -LiteralPath '%STAZE_STAGE%' -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType Directory -Path '%STAZE_STAGE_ROOT%' -Force | Out-Null"
if errorlevel 1 exit /b 1

robocopy "%STAZE_ROOT%" "%STAZE_STAGE_ROOT%" /E /XD build build-1.0.2 build-1.0.3 build-1.0.4 build-1.0.5 build-manual release .git /XF *.zip *.sha256 stazec.exe >nul
if errorlevel 8 (
    echo ERROR: Failed to construct the clean release staging tree.
    exit /b 1
)

mkdir "%STAZE_STAGE_ROOT%\release" 2>nul
copy /Y "%STAZE_EXE%" "%STAZE_STAGE_ROOT%\stazec.exe" >nul
if errorlevel 1 exit /b 1
copy /Y "%STAZE_EXE%" "%STAZE_STAGE_ROOT%\release\stazec.exe" >nul
if errorlevel 1 exit /b 1

"%STAZE_STAGE_ROOT%\stazec.exe" version --json | findstr /C:"1.0.5" >nul
if errorlevel 1 (
    echo ERROR: Staged compiler identity verification failed.
    exit /b 1
)

powershell -NoProfile -Command "$ErrorActionPreference='Stop'; if(Test-Path -LiteralPath '%STAZE_ZIP%'){Remove-Item -LiteralPath '%STAZE_ZIP%' -Force}; Compress-Archive -LiteralPath '%STAZE_STAGE_ROOT%' -DestinationPath '%STAZE_ZIP%' -CompressionLevel Optimal; $h=(Get-FileHash -Algorithm SHA256 -LiteralPath '%STAZE_ZIP%').Hash.ToLowerInvariant(); Set-Content -NoNewline -Encoding ascii -LiteralPath '%STAZE_ZIP%.sha256' -Value ($h+'  Staze-1.0.5-Windows-x64.zip')"
if errorlevel 1 exit /b 1

echo.
echo Genuine Staze Compiler 1.0.5 Windows package created:
echo   %STAZE_ZIP%
echo   %STAZE_ZIP%.sha256
endlocal
