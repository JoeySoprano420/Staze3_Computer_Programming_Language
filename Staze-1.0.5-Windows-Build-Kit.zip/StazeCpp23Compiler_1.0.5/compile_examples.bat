@echo off
setlocal
set STAZEC=build\bin\stazec.exe
if not exist "%STAZEC%" (
  echo stazec.exe not found. Run build_windows_x64.bat first.
  exit /b 1
)

for %%E in (
  hello
  arithmetic_control
  rich_cardinality
  rich_resources
  lifetime_cleanup
  dynamic_many
  owned_heap_transfer
  borrow_cross_boundary
  shared_scope
  partial_field_move
  transaction_field_undo
  transaction_observable_rollback
  transaction_resource_abort
  transaction_shared_abort
  parallel_tasks
  parallel_shared_task
  parallel_send_task
  transaction_loop_dynamic
  transaction_nested_savepoint
  transaction_relation_loop
  task_named_results
  task_fault_aggregation
  task_unique_mut
  systems_runtime
) do (
  echo Building %%E.exe...
  "%STAZEC%" "examples\%%E.stz3" -o "%%E.exe" || exit /b 1
)

echo Building module_app.exe...
"%STAZEC%" "examples\modules\App.stz3" --module-path "examples\modules" --emit-deps "module_app.deps.txt" -o "module_app.exe" || exit /b 1

echo.
echo All representative Compiler 1.0.5 examples built successfully.
endlocal
