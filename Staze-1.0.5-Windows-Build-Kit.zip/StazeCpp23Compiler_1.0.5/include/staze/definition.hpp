#pragma once

#include <filesystem>
#include <string>
#include <vector>

namespace staze {

struct DefinitionModule {
    std::string name;
    std::string version;
    std::string description;
    std::vector<std::string> dependencies;
    std::vector<std::string> syntax;
    std::vector<std::string> facts;
    std::vector<std::string> constraints;
    std::vector<std::string> lowerings;
    std::vector<std::string> targets;
    std::vector<std::string> capabilities;
    std::vector<std::string> diagnostics;
    std::string canonical;
    std::string sha256;
    std::filesystem::path source;
};

struct DefinitionPack {
    std::vector<DefinitionModule> modules;
    std::string canonical;
    std::string sha256;
};

DefinitionModule parse_definition(std::string_view text, const std::filesystem::path& source);
DefinitionPack load_definition_pack(const std::filesystem::path& path);
std::string inspect_definition_pack(const DefinitionPack& pack);

} // namespace staze
