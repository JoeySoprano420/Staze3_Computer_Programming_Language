#pragma once
#include "staze/ast.hpp"
#include <filesystem>
#include <string>
#include <vector>

namespace staze {

struct ModuleGraphNode {
    std::string name;
    std::filesystem::path path;
    std::vector<std::string> imports;
};

struct LoadedCompilation {
    Program program;
    std::vector<ModuleGraphNode> graph;
};

class ModuleLoader {
public:
    LoadedCompilation load(const std::vector<std::filesystem::path>& roots,
                           const std::vector<std::filesystem::path>& search_paths) const;
    static std::string graph_text(const std::vector<ModuleGraphNode>& graph);
};

} // namespace staze
