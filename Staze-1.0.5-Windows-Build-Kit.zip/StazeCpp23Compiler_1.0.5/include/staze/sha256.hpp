#pragma once
#include <string>
#include <string_view>

namespace staze {
std::string sha256_hex(std::string_view bytes);
}
