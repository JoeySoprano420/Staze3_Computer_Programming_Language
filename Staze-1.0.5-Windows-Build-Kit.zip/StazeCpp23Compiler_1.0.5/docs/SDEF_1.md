# Staze Definition Format 1.1

SDEF 1.1 is the strict, deterministic definition-module format shipped by
Compiler 1.0.5. It turns the attachment's definition-driven design into a
validated trust boundary.

Each non-comment line is one record. The first record is exactly `SDEF 1.1`.
Subsequent records use a key followed by one quoted UTF-8 string:

```text
SDEF 1.1
module "example.range"
version "1"
description "Checked range semantics"
requires "staze.core"
syntax "range := lower to upper"
fact "to includes the upper bound"
constraint "step is nonzero"
lowering "types.range.checked"
target "windows-x86_64"
capability "semantic:implemented"
diagnostic "E2002 range step cannot be zero"
```

Required records are `module`, `version`, and `description`. Module names are
unique in a pack. Dependencies must exist and be acyclic. Pack files are sorted,
canonicalized, and SHA-256 fingerprinted. Duplicate records are rejected.

The format is declarative. Executable callbacks, dynamic-library loading,
machine-code injection, shell/process execution, network access, filesystem
writes, environment reads, and absolute-path escape declarations are rejected.
Definitions never receive implicit permission to execute host code.

Compiler 1.0.5 also rejects malformed/non-canonical UTF-8, forbidden control
bytes, symlinked modules, non-regular files, modules larger than 1 MiB, and packs
larger than 256 modules.

```bat
stazec.exe definitions check definitions
stazec.exe definitions inspect definitions
stazec.exe definitions lock definitions definitions.lock
stazec.exe definitions verify definitions definitions.lock
stazec.exe check program.stz3 --definition-pack definitions
```

Participating pack and module hashes are recorded in the reproducible build
manifest. Definition recognition does not invent a backend: every module uses
capability records to distinguish implemented, partial, and definition-only work.
