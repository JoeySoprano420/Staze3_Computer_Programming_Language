# STZ-3 Compiler 1.0.5 — Implementation Status

## 1.0 stabilization layer

| Capability | Status |
|---|---|
| Stable `build`, `check`, `inspect`, `version` commands | Implemented + tested |
| SABI 1 identity and compatibility contract | Frozen + documented |
| SDEF 1 definition/build identity | Frozen + documented |
| SHA-256 reproducible build manifest | Implemented + independently cross-checked |
| Source and transitive module fingerprints | Implemented + tested |
| Canonical SIR-S/SIR-C content fingerprints | Implemented + tested |
| Legacy option-first CLI compatibility | Retained |
| Attachment memory profiler | Retained + tested |
| Location-independent manifest paths | Corrected in 1.0.5 + relocation-tested |
| `--verify-build-manifest` | Implemented + tamper-tested |

## Complete 0.9 execution profile carried into 1.0

| Capability | Status |
|---|---|
| Module/import loader | Implemented + tested |
| Multi-root / multi-file compilation | Implemented + tested |
| Dependency graph emission | Implemented + tested |
| Missing import rejection | Implemented + tested |
| Import cycle rejection | Implemented + tested |
| Module identity validation | Implemented + tested |
| Duplicate top-level rejection | Implemented + tested |
| Canonical SIR-S 6.x | Implemented + detached verification |
| Canonical SIR-C 7.0 | Implemented + detached verification |
| Bounded dynamic transaction occurrence log | Implemented + native PE tests |
| Transaction loop rollback | Implemented + native PE test |
| Nested transaction savepoints | Implemented + native PE test |
| Transaction capacity fault/proof | Implemented + malicious SIR-C test |
| Native relation table storage | Implemented + native PE test |
| Relation uniqueness/cardinality/capacity | Implemented + verifier/native provider |
| Relation synchronization | Implemented (`cmpxchg` lock) |
| Reversible relation link/unlink | Implemented + transaction test |
| Real Win32 workers | Implemented (`CreateThread`) |
| Worker join | Implemented (`WaitForSingleObject`) |
| Named task results / `join` | Implemented + native PE test |
| Task fault aggregation | Implemented + native PE test |
| Mutable/shared/send capture checking | Implemented + negative race test |
| Dynamic text | Implemented |
| Byte slices | Implemented |
| Bounded scalar maps | Implemented |
| File read/write | Implemented (Win32) |
| Process execution | Implemented (Win32) |
| Raw owned bytes / memory allocation | Implemented |
| Startup code (`staze_entry`) | Implemented |
| Runtime glue without CRT startup | Implemented |
| LLVM -> COFF -> PE32+ | Implemented + tested |
| Detached SIR-C -> native PE | Implemented + tested |
| Fake `__chkstk` runtime shim | Removed; negative evidence test passes |

## Retained from earlier milestones

1.0 continues to regression-test typed bindings/parameters, checked arithmetic, `if`/loops, `set`/`revise`, fault payloads, `bypass`/`delete`, cardinality, aggregates/choices, pools, effect-token SSA, concrete storage placement, optional/Many lowering, dynamic Many growth, path-sensitive cleanup, proven HeapFree, lifetime/provenance/authority, addressable fields, subobject borrows, owned/shared transfer, atomic shared retain/release, cross-boundary borrow contracts, partial moves, resource composition, and transaction/task verification from 0.2-0.9.

## Exact reference-profile boundaries

- native map keys/values in 0.9 are scalar POD: `bool`, `i32`, `i64`, `u32`, `u64`;
- native slices in 0.9 are byte slices (`slice<u8>` / byte views);
- relation storage is fixed-capacity according to the concrete SIR-C plan;
- transaction undo logs are bounded by the verified SIR-C transaction plan and expose `TransactionCapacityExceeded` when repeated execution can exceed that bound;
- task scheduling uses Win32 worker threads and structured joins; this is not yet a general work-stealing pool;
- the compiler targets the Windows x86-64 reference profile only;
- this milestone freezes the supported 1.0 reference profile; it does not claim universal STZ-3 standard-library, self-hosting, or cross-target conformance.
