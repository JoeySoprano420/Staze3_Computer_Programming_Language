# Roadmap after Compiler 1.0.0

Compiler 0.9 closes the first integrated native systems/runtime milestone: dynamic transaction logs, nested savepoints, real synchronized relation storage, Win32 worker tasks, text/slices/maps/file/process/memory primitives, and a recursive module/import graph all survive detached SIR and reach PE32+.

A completed **Compiler 1.0** hardening release freezes the language/toolchain foundations rather than adding an unrelated feature burst:

- frozen formal SIR-S/SIR-C schemas and version-compatibility rules;
- move the generated runtime helpers into a separately versioned SDEF/SABI runtime profile while retaining verifier ownership;
- broaden maps and slices to rich generic element/key/value representations;
- add robust Unicode text/UTF validation and path encodings;
- add richer file handles, directories, environment and process pipes;
- add persistent/dynamic relation providers and indexes beyond the fixed-capacity reference table;
- add scalable worker pools/work stealing while preserving structured task/fault semantics;
- add dynamic transaction log storage with allocation-failure policy for very large transactions;
- formalize package/module resolution, lock files, package identities and dependency hashes;
- stable public SABI calling conventions for all supported rich values;
- implement optimizer passes directly over canonical SIR with proof-preserving validation;
- add Windows runtime execution CI in addition to structural PE validation;
- add debugger/LSP/package-manager interfaces against the frozen compiler metadata;
- begin self-hosting/Seed convergence work without enlarging the permanent Seed trust root.

The governing law remains: source semantics become SSL facts; DLE produces canonical SIR-S meaning; SIR-C independently proves a target realization; the verifier guards both boundaries; LLVM implements rather than interprets the language.
