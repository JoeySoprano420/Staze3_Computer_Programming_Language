# Staze ABI 1 (SABI 1)

SABI 1 is the stable Windows x86-64 boundary for Compiler 1.0.0. It freezes the
calling, layout, ownership, task, and startup contracts already proven by the
0.9 implementation.

## Frozen target identity

- target triple: `x86_64-pc-windows-msvc`
- object format: COFF
- executable format: PE32+
- startup symbol: `staze_entry`
- system import provider: `KERNEL32.dll`
- ordinary C/C++ runtime startup: absent (`/NODEFAULTLIB`)

## Compatibility law

A producer and consumer are SABI-1 compatible only when their serialized
function signature, value layouts, ownership-transfer rules, fault-result
layout, task-context layout, and target identity agree. Layout disagreement is
an incompatibility, never an implicit conversion.

Owned values cross a boundary exactly once. Shared values carry their verified
retain/release contract. Borrowed values retain lifetime and provenance
requirements. Task results and fault slots use the concrete layouts recorded in
SIR-C 7.0.

SABI 1 never permits a backend to infer a weaker contract than the independently
verified SIR-C plan.
