# SIR-C 7.0 — Concrete Target Proof Format

SIR-C 7.0 is the Windows x86-64 concrete representation format emitted by Compiler 0.9.0. It is serializable, reloadable in a fresh compiler invocation, and independently verified before LLVM emission.

## Target contract

The top-level concrete program records:

- target profile and triple;
- pointer width;
- object/executable formats;
- calling convention;
- aggregate/cardinality/fault-payload representation contracts;
- concrete nominal layouts;
- concrete function plans;
- semantic schemas/facts and the detached SIR function graph needed for independent correspondence checks.

## Concrete value/storage records

Each SSA value receives a plan describing storage class, concrete kind, size/alignment, payload or field offsets, capacity/element size where applicable, alias source, escape status, and scalar-replacement status.

Storage classes include register, stack, caller, pool/arena, heap, static and alias. Concrete kinds include scalar, text view, slice view, dynamic map, optional, inline/dynamic Many, aggregate, choice and borrow reference.

## Resource and cleanup records

SIR-C carries explicit resources, component resources, cleanup edges, transfer discharges and result-transfer ABI kinds. Dynamic text/map/bytes/Many and heap/shared values therefore retain lifetime obligations after representation lowering.

## Transaction records

Compiler 0.9 adds `transaction` plans with:

- concrete transaction identity and semantic region;
- parent transaction/savepoint relation;
- exact begin/commit operation identities;
- bounded undo-log capacity;
- per-entry payload byte capacity;
- concrete undo actions corresponding to semantic rollback obligations.

The native backend uses the plan to allocate one occurrence log per function execution and savepoint counters per transaction region. Every executed reversible effect pushes an occurrence. Abort replays from the current log count down to the relevant savepoint.

## Native relation records

`concrete relation` records define:

- concrete relation ID/name;
- table capacity;
- source and target identity policy;
- source/target cardinality modes;
- unique-pair policy;
- reverse-index intent;
- synchronization requirement.

The verifier requires these records to agree with SIR-S relation schemas before the backend can emit a table.

## Worker/task records

SIR-C 7.0 task plans include:

- parallel and task region identities;
- TaskBegin/TaskEnd operation IDs;
- stable task name;
- result type/cardinality/nominal type;
- worker context size/alignment;
- result/status/cause offsets;
- concrete capture records containing semantic value/provenance/mode and byte offset/size/alignment.

The verifier rejects context overflows, capture layout overflows, contract mismatches and task-plan identity corruption before native worker generation.

## Detached invariant

The backend path is deliberately:

```text
serialize SIR-C 7.0
        -> destroy producer-side concrete graph
        -> deserialize bytes
        -> independent verify
        -> LLVM
```

LLVM therefore cannot rely on AST/SSL/DLE or in-memory target-concretizer pointers.
