# Compiler 0.9 — Dynamic Transactions, Native Relations & Workers

## Dynamic transaction occurrence log

0.8 had statically allocated undo state associated with source operations. 0.9 records **executed occurrences** instead. The native function frame contains a bounded log with arrays for undo kind, relation identity, target pointer, auxiliary words and fixed-size payload bytes, plus a log count and transaction savepoints.

`staze_tx_push` checks capacity before inserting a record. Repeated operations in loops therefore create separate entries. Nested `transaction` begins save the current log count; inner abort unwinds to its savepoint; inner commit leaves records available to the parent; a root commit discharges the committed range.

Abort applies inverse actions in reverse execution order. Current native inverse classes cover field byte restore and relation inverse mutation, while retained resource/ownership undo plans from earlier milestones remain verifier-visible.

## Relation provider

The Windows reference target materializes each concrete relation as synchronized module storage. Endpoint identities are derived from declared dataset keys when available or from address identity for addressable resource endpoints. Link validates capacity, uniqueness and endpoint cardinality. `contains`, `count`, `link`, and `unlink` all operate on the same table.

The provider is synchronized using an atomic compare/exchange lock. Transaction rollback invokes the same relation implementation through inverse actions, preventing a second inconsistent relation model from existing solely for rollback.

## Worker scheduler

Every concrete task gets a context layout containing captures, result storage, status and fault cause. `TaskBegin` initializes the context and launches a Windows worker with `CreateThread`. The worker executes the task subgraph and records result/status/cause. `TaskJoin` waits using `WaitForSingleObject`, closes the handle and transports the typed result or aggregated task fault into the parent graph.

The compiler rejects conflicting task captures before any worker can be launched. Mutable (`unique-mut`) access must remain unique across sibling workers; shared-read requires shared authority; `send` transfers ownership into the task context.

Task faults are collected deterministically according to the structured task contract rather than being allowed to race into process-global exception state.
