# Staze C++23 Compiler 0.9.0 — Final Validation Report

## Exact-tree build

The final source tree was configured in a fresh external build directory with Clang C++23 Release configuration (`-O1 -DNDEBUG`) and the project warning policy `-Wall -Wextra -Wpedantic`.

```text
configuration  PASS
compile/link   PASS
warnings       0
errors         0
```

The lower optimization level applies only to the host compiler executable used for validation. Generated Staze Windows programs are independently compiled from LLVM with the backend's `-O2` target command.

## Conformance suite

```text
CTest: 249 / 249 PASS
failed: 0
```

The suite retains the legacy 0.2-0.8 regression set and adds 0.9 coverage for:

- loop/repeated dynamic transaction rollback;
- nested transaction savepoint plans;
- transaction+relation inverse operations;
- transaction plan capacity/parent corruption rejection;
- named worker task results;
- task fault aggregation;
- unique mutable task capture;
- conflicting task capture rejection;
- worker context/capture corruption rejection;
- `CreateThread` and `WaitForSingleObject` native evidence;
- native relation table and atomic lock evidence;
- dynamic transaction push and relation-undo native evidence;
- text/slices/map/raw-memory/file/process integrated system program;
- source -> SIR-C and detached SIR-C -> LLVM equality for the systems program;
- absence of the temporary fake `__chkstk` definition;
- recursive module graph loading and dependency emission;
- multi-root compilation;
- cyclic/missing/mismatched/duplicate module rejection;
- source-module and detached-SIR-C LLVM equality.

## Canonical evidence set

`dist/0.9/` contains source-built and detached-SIR-C artifacts for:

- `transaction_loop_dynamic`
- `transaction_nested_savepoint`
- `transaction_relation_loop`
- `task_named_results`
- `task_fault_aggregation`
- `task_unique_mut`
- `systems_runtime`
- `modules_app`

For all eight programs, source-driven and detached-SIR-C LLVM files are byte-identical.

PE files were structurally identified as Windows x86-64 PE32+ console executables. This Linux environment has no Wine/Windows loader, so the report does not claim execution under Windows here; it validates compiler construction, detached IR equivalence, native object/link success, PE format/imports and machine-code artifacts.
