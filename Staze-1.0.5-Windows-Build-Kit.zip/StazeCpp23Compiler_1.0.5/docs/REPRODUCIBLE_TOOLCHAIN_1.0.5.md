# Reproducible toolchain contract

Compiler 1.0.5 preserves two explicit detachment boundaries:

1. source/module graph -> canonical SIR-S 6.x -> serialize/reload/verify;
2. SIR-S -> canonical SIR-C 7.0 -> serialize/reload/verify -> LLVM.

Canonical serialization must be byte-stable after a fresh deserialize/serialize
round trip. `--emit-build-manifest` records SHA-256 fingerprints for source
roots, SIR-S, and SIR-C, plus compiler, SDEF, SABI, target, and profile identity.

Example:

```bat
stazec.exe build examples\systems_runtime.stz3 ^
  --emit-sir-s build\systems_runtime.sirs ^
  --emit-sir-c build\systems_runtime.sirc ^
  --emit-build-manifest build\systems_runtime.manifest ^
  -o build\systems_runtime.exe
```

Repetition with identical inputs and toolchain identity must reproduce identical
canonical SIR and manifest fingerprints. A mismatch is a failed reproducibility
gate and must be investigated before release.

Verify a recorded build without overwriting it:

```bat
stazec.exe check examples\systems_runtime.stz3 ^
  --verify-build-manifest build\systems_runtime.manifest
```

Compiler 1.0.5 removes checkout-location dependence from manifest input names.
This corrects the 1.0.0 behavior that could embed absolute module paths and make
otherwise identical source trees produce different manifest bytes.
