# `--emit-deps` module-graph format

`--emit-deps <path>` writes the exact module graph resolved for a source build.
The output is deterministic and begins with a versioned header:

```text
STAZE-MODULE-GRAPH 1
module App examples/modules/App.stz3
  use Math
  use Extra
module Extra examples/modules/Extra.stz3
module Math examples/modules/Math.stz3
  use Extra
```

Each `module` record contains the declared or derived module identity followed
by its normalized source path. Indented `use` records list that module's direct
imports. The compiler rejects missing imports, duplicate identities, identity
mismatches, and cycles before writing a successful graph.

```bat
stazec.exe examples\modules\App.stz3 ^
  --module-path examples\modules ^
  --emit-deps modules.deps ^
  --check
```
