# Compiler 0.9 — Systems Runtime, Startup & Modules

## Text and slices

Native dynamic text uses a two-word descriptor: data pointer and `u64` byte length. Owned text buffers are tracked by provenance/resource obligations. Literal and dynamic text use the same semantic `text` type even though ownership differs.

Byte slices are `{ptr,length}` borrowed views. Slice creation preserves provenance and checks range bounds; checked element access routes `BoundsFailure` before the backend performs a byte load.

## Maps

The 0.9 native map profile supports scalar POD key/value types (`bool`, `i32`, `i64`, `u32`, `u64`). A map is an owned descriptor pointing to dynamically allocated fixed-capacity slots. The runtime implements new/insert/get/contains/remove/length and returns `MapCapacityExceeded` rather than overwriting full storage.

## File I/O

`file.write_text` and `file.read_text` use explicit Win32 handles. Paths are converted from Staze text descriptors to temporary NUL-terminated buffers only at the OS boundary. File reads allocate an owned text result and route `IoFailure`/`AllocationFailure` explicitly.

## Process execution

`process.run(text)` creates a mutable command-line buffer, calls `CreateProcessA`, joins the child process, retrieves its exit code and closes both process/thread handles. Failures remain Staze `ProcessFailure`/allocation faults rather than C++ exceptions.

## Raw memory

`memory.alloc(u64)` creates owned heap bytes using `GetProcessHeap`/`HeapAlloc`; its descriptor records data, length and capacity. Lifetime cleanup uses the same resource planner as other heap-backed values.

## Startup/runtime glue

Generated programs use a custom `staze_entry` PE entry point and link with `/NODEFAULTLIB`. Compiler-generated helpers provide the reference map/file/process/relation/transaction/worker services. Clang is invoked with `-mno-stack-arg-probe` and the 0.9 backend does not emit the earlier temporary `__chkstk` shim.

## Modules and dependency graph

The module loader parses roots, follows `use`, locates module files through root directories plus `--module-path`, rejects cycles/missing/mismatched modules, topologically orders dependencies, globally renumbers expression IDs and merges the declarations for semantic analysis. `--emit-deps` emits the resolved graph used by the compilation.
