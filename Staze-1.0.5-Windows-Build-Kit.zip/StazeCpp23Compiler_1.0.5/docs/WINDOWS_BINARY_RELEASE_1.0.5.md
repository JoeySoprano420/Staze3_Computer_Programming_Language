# Windows binary release procedure

Compiler 1.0.5 adds a fail-closed binary packaging command:

```bat
call package_windows_x64.bat
```

Run it from the x64 Native Tools Command Prompt for Visual Studio 2022. It:

1. builds the current C++23 source;
2. runs the complete CTest and definition release gate;
3. requires `release\stazec.exe`;
4. requires that executable to report version 1.0.5;
5. constructs a clean staging tree;
6. places the compiler at both `stazec.exe` and `release\stazec.exe`;
7. creates `Staze-1.0.5-Windows-x64.zip`;
8. creates a SHA-256 sidecar.

Any build, test, copy, identity, staging, compression, or hashing failure stops
the procedure. An older executable is never accepted merely because its name is
`stazec.exe`.
