# Staze C++23 Compiler 1.0.5

Compiler 1.0.5 preserves Staze 3, SABI 1, SDEF 1.1, SIR-S 6.x, and SIR-C 7.0.
Its release focus is trustworthy Windows binary delivery.

- adds `package_windows_x64.bat`;
- builds and runs the complete Windows release gate before packaging;
- rejects a missing or stale compiler executable;
- verifies that the staged executable reports exactly 1.0.5;
- includes `stazec.exe` at the package root and in `release`;
- produces a SHA-256 sidecar for the final Windows ZIP;
- retains 1.0.4 atomic outputs, PE validation, JSON diagnostics, resource limits,
  definition locking, CI gate, and security boundaries.

The packaging script never substitutes a Linux executable or an earlier Windows
compiler merely to satisfy the filename requirement.
