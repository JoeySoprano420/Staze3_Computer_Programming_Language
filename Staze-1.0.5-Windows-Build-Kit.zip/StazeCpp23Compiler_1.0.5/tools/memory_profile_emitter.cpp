#include "staze/llvm_x64.hpp"
#include "staze/sir.hpp"

#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <psapi.h>
#endif

namespace {
std::string read_all(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) throw std::runtime_error("cannot open SIR-C input: " + path.string());
    std::ostringstream bytes;
    bytes << input.rdbuf();
    return bytes.str();
}

void print_peak_memory() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS_EX counters{};
    counters.cb = sizeof(counters);
    if (GetProcessMemoryInfo(GetCurrentProcess(),
                             reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&counters),
                             sizeof(counters))) {
        std::cout << "PeakWorkingSetSize: "
                  << static_cast<std::uint64_t>(counters.PeakWorkingSetSize) << " bytes\n";
    } else {
        std::cout << "PeakWorkingSetSize: unavailable\n";
    }
#else
    std::ifstream status("/proc/self/status");
    std::string line;
    while (std::getline(status, line)) {
        if (line.rfind("VmHWM:", 0) == 0) {
            std::cout << line << '\n';
            return;
        }
    }
    std::cout << "VmHWM: unavailable\n";
#endif
}
} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: memory_profile_emitter <program.sirc>\n";
        return 2;
    }

    try {
        const auto program = staze::deserialize_sir_c(read_all(argv[1]));
        const auto begin = std::chrono::steady_clock::now();
        const auto llvm = staze::LlvmWindowsX64Emitter{}.emit(program);
        const auto end = std::chrono::steady_clock::now();
        const std::chrono::duration<double> elapsed = end - begin;
        std::cout << "Emission completed in " << elapsed.count() << "s\n";
        std::cout << "LLVM output size: " << llvm.size() << " bytes\n";
        print_peak_memory();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "memory_profile_emitter: " << error.what() << '\n';
        return 1;
    }
}
